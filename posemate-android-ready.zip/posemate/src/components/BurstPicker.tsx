import { useEffect, useMemo, useState } from 'react';
import Icon from './Icon';
import type { BurstFrame } from '../lib/burst';

/** Pick one frame from a burst. The highest-scoring frame starts selected and is marked "Best". */
export default function BurstPicker({
  frames,
  scores,
  best,
  onUse,
  onCancel,
}: {
  frames: BurstFrame[];
  scores: number[];
  best: number;
  onUse: (i: number) => void;
  onCancel: () => void;
}) {
  const [sel, setSel] = useState(Math.max(0, best));
  const urls = useMemo(() => frames.map((f) => URL.createObjectURL(f.blob)), [frames]);
  useEffect(() => () => urls.forEach((u) => URL.revokeObjectURL(u)), [urls]);

  return (
    <div className="fixed inset-0 z-20 flex flex-col bg-ink text-white">
      <div className="px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <p className="text-lg font-extrabold">Pick your best shot</p>
        <p className="text-sm text-white/65">{frames.length} frames. The sharpest one is marked Best; you decide.</p>
      </div>
      <div className="min-h-0 flex-1 bg-black">
        <img src={urls[sel]} alt={`Frame ${sel + 1} of ${frames.length}`} className="h-full w-full object-contain" />
      </div>
      <ul className="flex gap-2 overflow-x-auto px-4 py-3" aria-label="Burst frames">
        {frames.map((f, i) => (
          <li key={i} className="relative shrink-0">
            <button
              onClick={() => setSel(i)}
              aria-label={`Frame ${i + 1}${i === best ? ', best' : ''}`}
              aria-pressed={i === sel}
              className={`block overflow-hidden rounded-xl border-2 ${i === sel ? 'border-volt' : 'border-transparent opacity-70'}`}
            >
              <img src={urls[i]} alt="" className="h-20 w-auto" style={{ aspectRatio: `${f.width} / ${f.height}` }} />
            </button>
            {i === best && <span className="absolute left-1 top-1 rounded-full bg-volt px-1.5 text-[10px] font-black text-ink">Best</span>}
            <span className="sr-only">score {Math.round(scores[i] * 100)}</span>
          </li>
        ))}
      </ul>
      <div className="grid grid-cols-[auto_1fr] items-center gap-3 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-1">
        <button onClick={onCancel} className="btn bg-white/15 text-white">
          <Icon name="retake" className="h-5 w-5" /> Retake
        </button>
        <button onClick={() => onUse(sel)} className="btn bg-volt text-ink">
          <Icon name="check" className="h-5 w-5" /> Use this photo
        </button>
      </div>
    </div>
  );
}
