import { useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent, type PointerEvent } from 'react';
import { SCENES, type Pose } from '../data/poses';
import { drawOverlay, type GhostBitmap, type Person } from '../lib/draw';
import { computeFit } from '../lib/fit';
import { comparePercent, pctFromPointer, revealLeft, stepPct } from '../lib/compare';
import Icon from './Icon';

interface Props {
  url: string;
  width: number;
  height: number;
  pose: Pose;
  people: Person[]; // landmarks found when the photo was taken
  overlayValid: boolean; // photo has the same framing as the live view, so landmarks line up
  onClose: () => void;
}

/**
 * Before / after: the reference pose on the left, your photo on the right, with a divider you drag.
 * When we know where the person is, the reference is scaled onto them so the wipe shows the
 * difference in pose rather than in position. The photo itself is never changed.
 */
export default function CompareSlider({ url, width, height, pose, people, overlayValid, onClose }: Props) {
  const [pct, setPct] = useState(50); // how much of the width shows the reference
  const [touched, setTouched] = useState(false);
  const [bitmaps, setBitmaps] = useState<(GhostBitmap | null)[] | undefined>(undefined);
  const box = useRef<HTMLDivElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const dragging = useRef(false);

  const fit = useMemo(
    () => (overlayValid ? computeFit(people, pose.figures, width, height) : null),
    [overlayValid, people, pose.figures, width, height],
  );
  const score = overlayValid ? comparePercent(people, pose.figures, width, height) : null;
  const bg = SCENES.find((s) => s.id === pose.scenes[0])?.bg ?? 'bg-aqua';

  // photo ghost images (only exist if the pose was made with that option)
  const ghostSrc = pose.ghostPhotos;
  useEffect(() => {
    if (!ghostSrc?.some(Boolean)) {
      setBitmaps(undefined);
      return;
    }
    let alive = true;
    const made: ImageBitmap[] = [];
    void Promise.all(
      ghostSrc.map(async (g): Promise<GhostBitmap | null> => {
        if (!g) return null;
        try {
          const bitmap = await createImageBitmap(g.blob);
          made.push(bitmap);
          return { bitmap, box: g.box, mirrored: g.mirrored };
        } catch {
          return null;
        }
      }),
    ).then((list) => {
      if (alive) setBitmaps(list);
      else made.forEach((b) => b.close());
    });
    return () => {
      alive = false;
      setBitmaps(undefined);
      made.forEach((b) => b.close());
    };
  }, [ghostSrc]);

  const draw = useCallback(() => {
    const c = cv.current;
    if (!c) return;
    drawOverlay(c, {
      vw: width,
      vh: height,
      reference: pose.figures,
      outlines: pose.outlines,
      details: pose.details,
      ghost: 0.85, // strong, so the reference reads as a figure on its coloured panel
      ghostPhotos: bitmaps,
      fit,
    });
  }, [width, height, pose, bitmaps, fit]);

  useEffect(() => {
    draw();
    const el = box.current;
    if (!el) return;
    const ro = new ResizeObserver(draw);
    ro.observe(el);
    return () => ro.disconnect();
  }, [draw]);

  const move = (e: PointerEvent) => {
    const r = box.current?.getBoundingClientRect();
    if (r) setPct(pctFromPointer(e.clientX, r.left, r.width));
  };

  const onKey = (e: KeyboardEvent) => {
    const next = stepPct(pct, e.key, e.shiftKey);
    if (next === null) return;
    e.preventDefault();
    setTouched(true);
    setPct(next);
  };

  return (
    <div
      ref={box}
      className="relative h-full w-full select-none overflow-hidden"
      style={{ touchAction: 'none' }}
      onPointerDown={(e) => {
        dragging.current = true;
        setTouched(true);
        e.currentTarget.setPointerCapture(e.pointerId);
        move(e);
      }}
      onPointerMove={(e) => dragging.current && move(e)}
      onPointerUp={() => (dragging.current = false)}
      onPointerCancel={() => (dragging.current = false)}
    >
      <img src={url} alt="Your photo" draggable={false} className="absolute inset-0 h-full w-full object-contain" />

      <div className={`absolute inset-0 ${bg}`} style={{ clipPath: revealLeft(pct) }}>
        <canvas ref={cv} role="img" aria-label="Reference pose" className="absolute inset-0 h-full w-full" />
      </div>

      {pct > 14 && <p className="pointer-events-none absolute left-3 top-3 rounded-full bg-black/60 px-3 py-1.5 text-sm font-bold text-white">Reference</p>}
      {pct < 86 && <p className="pointer-events-none absolute right-3 top-3 rounded-full bg-black/60 px-3 py-1.5 text-sm font-bold text-white">Your photo</p>}
      {score !== null && (
        <p className="pointer-events-none absolute inset-x-0 top-14 flex justify-center" role="status">
          <span className={`rounded-full px-3 py-1.5 text-sm font-bold ${score >= 70 ? 'bg-volt text-ink' : 'bg-black/60 text-white'}`}>{score}% match</span>
        </p>
      )}

      {/* divider and handle */}
      <div className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow" style={{ left: `${pct}%` }} />
      <div
        role="slider"
        tabIndex={0}
        aria-label="Compare reference and photo"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(pct)}
        aria-valuetext={`${Math.round(pct)} percent reference`}
        onKeyDown={onKey}
        className="absolute top-1/2 grid h-11 w-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white text-ink shadow-lg"
        style={{ left: `${pct}%` }}
      >
        <Icon name="chevron" className="h-4 w-4 rotate-180" />
        <Icon name="chevron" className="-ml-2 h-4 w-4" />
      </div>
      {!touched && <p className="pointer-events-none absolute inset-x-0 bottom-16 text-center text-sm font-bold text-white [text-shadow:0_1px_3px_rgba(0,0,0,0.8)]">Drag the line to compare</p>}

      <button
        onClick={onClose}
        onPointerDown={(e) => e.stopPropagation()}
        className="absolute bottom-3 left-3 rounded-full bg-black/55 px-4 py-2 text-sm font-bold text-white backdrop-blur"
      >
        Close compare
      </button>
    </div>
  );
}
