import { levelState, pitchHint, showsLevel } from '../lib/tilt';

/**
 * A horizon line for the person holding the phone. The fixed ticks are the phone's own
 * horizontal; the line stays on the real horizon, so it tilts as the phone tilts and turns
 * green when the two meet.
 */
export default function LevelLine({ roll, pitch }: { roll: number | null; pitch: number }) {
  if (!showsLevel(roll)) return null; // flat, or turned too far for a level line to mean anything
  const state = levelState(roll);
  const hint = pitchHint(pitch);
  const tick = state === 'level' ? 'bg-volt' : 'bg-white/70';
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-[1] grid place-items-center">
      <div className="relative w-[78%]">
        {/* the phone's own horizontal (does not move) */}
        <div className="flex items-center justify-between">
          <span className={`h-0.5 w-7 rounded-full ${tick}`} />
          <span className={`h-0.5 w-7 rounded-full ${tick}`} />
        </div>
        {/* the real horizon (turns against the phone) */}
        <div
          className={`absolute inset-x-8 top-0 h-0.5 rounded-full transition-colors ${state === 'level' ? 'bg-volt' : state === 'near' ? 'bg-white' : 'bg-white/60'}`}
          style={{ transform: `rotate(${-roll}deg)` }}
        />
        {hint && <p className="absolute left-0 top-3 text-xs font-bold text-white/85 [text-shadow:0_1px_3px_rgba(0,0,0,0.7)]">{hint}</p>}
      </div>
    </div>
  );
}
