import { useState } from 'react';
import Icon from './Icon';
import PhotoWithOverlay from './PhotoWithOverlay';
import { getPose } from '../data/poses';
import type { Person } from '../lib/draw';
import { savePhoto } from '../lib/db';
import { canShareFile, downloadBlob, fileName, formatBytes, makeThumb, newId, shareBlob } from '../lib/files';
import { go } from '../lib/route';

export interface Shot {
  blob: Blob;
  url: string;
  width: number;
  height: number;
  method: string;
  people: Person[];
  overlayValid: boolean;
  poseId: string | null;
  mirrored: boolean;
  createdAt: number;
}

export default function Preview({ shot, onRetake }: { shot: Shot; onRetake: () => void }) {
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const pose = getPose(shot.poseId ?? undefined);
  const name = fileName(shot.createdAt);

  const save = async () => {
    setBusy(true);
    setErr(null);
    try {
      const thumb = await makeThumb(shot.blob);
      await savePhoto({
        id: newId(),
        createdAt: shot.createdAt,
        blob: shot.blob,
        thumb,
        width: shot.width,
        height: shot.height,
        poseId: shot.poseId,
        people: shot.people,
        overlayValid: shot.overlayValid,
        mirrored: shot.mirrored,
        method: shot.method,
      });
      setSaved(true);
    } catch {
      setErr('Could not save on this device. Storage may be full, or blocked in private browsing. You can still download the photo.');
    } finally {
      setBusy(false);
    }
  };

  const share = async () => {
    try {
      await shareBlob(shot.blob, name);
    } catch {
      /* user cancelled the share sheet */
    }
  };

  return (
    <div className="fixed inset-0 z-20 flex flex-col bg-ink text-white">
      <div className="px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <p className="text-lg font-extrabold">Preview</p>
        <p className="text-sm text-white/65">
          {shot.width} × {shot.height} px, {formatBytes(shot.blob.size)}, {shot.method.toLowerCase()}
        </p>
      </div>
      <div className="min-h-0 flex-1 bg-black">
        <PhotoWithOverlay url={shot.url} width={shot.width} height={shot.height} people={shot.people} figures={pose?.figures} outlines={pose?.outlines} details={pose?.details} overlayValid={shot.overlayValid} pose={pose} />
      </div>
      {err && <p role="alert" className="bg-rose-600 px-4 py-2 text-sm">{err}</p>}
      {saved && (
        <p role="status" className="bg-volt px-4 py-2 text-sm font-semibold text-ink">
          Saved on this device only. <button className="underline" onClick={() => go('gallery')}>Open My photos</button>
        </p>
      )}
      <div className="grid grid-cols-[auto_1fr_auto] items-center gap-3 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3">
        <button onClick={onRetake} className="btn bg-white/15 text-white">
          <Icon name="retake" className="h-5 w-5" /> Retake
        </button>
        <button onClick={save} disabled={busy || saved} className="btn bg-volt text-ink disabled:opacity-60">
          <Icon name={saved ? 'check' : 'download'} className="h-5 w-5" />
          {saved ? 'Saved' : busy ? 'Saving…' : 'Save photo'}
        </button>
        <div className="flex gap-2">
          <button onClick={() => downloadBlob(shot.blob, name)} aria-label="Download original" className="cam-btn h-12 w-12 bg-white/15">
            <Icon name="download" />
          </button>
          {canShareFile(shot.blob, name) && (
            <button onClick={share} aria-label="Share" className="cam-btn h-12 w-12 bg-white/15">
              <Icon name="share" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
