import { useState } from 'react';
import { MODES, MOODS, SCENES, getPoses, type Mode, type SceneId } from '../data/poses';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import Icon from '../components/Icon';
import PoseCard from '../components/PoseCard';
import { Segmented } from '../components/Controls';
import { go, replace } from '../lib/route';

type Filter = 'all' | 'yours' | (typeof MOODS)[number]['id'];

export default function Poses({ mode, scene }: { mode: Mode; scene: SceneId }) {
  const m = MODES.find((x) => x.id === mode)!;
  const s = SCENES.find((x) => x.id === scene)!;
  const poses = getPoses(mode, scene);

  // Filter chips: only moods that this list actually has, plus "Yours" for poses made from photos.
  const chips: { id: Filter; name: string }[] = [
    ...MOODS.filter((md) => poses.some((p) => p.moods?.includes(md.id))),
    ...(poses.some((p) => p.custom) ? [{ id: 'yours' as const, name: 'Yours' }] : []),
  ];
  const [picked, setPicked] = useState<Filter>('all');
  // If the chosen chip does not exist in this list (for example after switching places), show everything.
  const filter: Filter = chips.some((c) => c.id === picked) ? picked : 'all';
  const shown = poses.filter((p) =>
    filter === 'all' ? true : filter === 'yours' ? !!p.custom : p.moods?.includes(filter),
  );

  return (
    <>
      <div className="mx-auto w-full max-w-3xl pb-28">
        <Header title={s.name} sub={`${m.name} poses`} />
        <div className="px-4 pb-3 pt-1">
          <Segmented
            label="Who is in the photo"
            value={mode}
            onChange={(next) => {
              replace(`poses/${next}/${scene}`); // replaces this page, so Back still goes to the places list
              window.scrollTo(0, 0);
            }}
            options={MODES.map((x) => [x.name, x.id] as const)}
          />
        </div>
        {chips.length > 1 && (
          <div role="group" aria-label="Filter poses" className="flex gap-2 overflow-x-auto px-4 pb-3 pt-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {[{ id: 'all' as const, name: 'All' }, ...chips].map((c) => (
              <button
                key={c.id}
                onClick={() => setPicked(c.id)}
                aria-pressed={filter === c.id}
                className={`shrink-0 rounded-full px-4 py-2 text-sm font-bold transition active:scale-95 ${filter === c.id ? 'bg-ink text-white' : 'bg-ink/10'}`}
              >
                {c.name}
              </button>
            ))}
          </div>
        )}
        {poses.length === 0 && (
          <div className="px-5 pt-8">
            <p className="text-xl font-black tracking-tight">No poses here yet</p>
            <p className="mt-1 text-ink/70">Pick another place, or make your own from a photo.</p>
            <button onClick={() => go('create')} className="btn-quiet mt-4">
              <Icon name="plus" className="h-5 w-5" /> Make a pose
            </button>
          </div>
        )}
        <ul className="grid gap-9 px-4 pt-2 md:grid-cols-2">
          {shown.map((p) => (
            <li key={p.id}>
              <PoseCard pose={p} bg={s.bg} />
            </li>
          ))}
        </ul>
      </div>
      <BottomNav active="home" />
    </>
  );
}
