// On-device body detection with MediaPipe Pose Landmarker.
// The runtime and models are served from this site (see scripts/setup-assets.mjs)
// and frames/photos never leave the browser. The library is loaded on demand so
// the home screen stays light.
import type { PoseLandmarker } from '@mediapipe/tasks-vision';
import { toPerson, type Person } from './draw';
import { ACCURACY_INFO, modelPath, type Accuracy } from './accuracy';

const WASM_PATH = 'mediapipe/wasm';

const abs = (p: string) => new URL(import.meta.env.BASE_URL + p, document.baseURI).href;

type Mod = typeof import('@mediapipe/tasks-vision');
interface Runtime {
  mod: Mod;
  fileset: Awaited<ReturnType<Mod['FilesetResolver']['forVisionTasks']>>;
}

// The MediaPipe library and WASM are shared by every model.
let runtime: Promise<Runtime> | null = null;
function prepare(): Promise<Runtime> {
  if (!runtime) {
    runtime = (async () => {
      const mod = await import('@mediapipe/tasks-vision');
      const fileset = await mod.FilesetResolver.forVisionTasks(abs(WASM_PATH));
      return { mod, fileset };
    })().catch((e) => {
      runtime = null; // allow a retry
      throw e;
    });
  }
  return runtime;
}

/** Confirms the model file exists on this site and returns its URL. */
async function modelUrlFor(a: Accuracy): Promise<string> {
  const url = abs(modelPath(a));
  const name = ACCURACY_INFO[a].label;
  let res: Response;
  try {
    res = await fetch(url, { method: 'HEAD' });
  } catch {
    throw new Error(
      a === 'lite'
        ? 'The pose model could not be loaded. Check your connection and reload.'
        : `The ${name} model needs a connection the first time. It could not be loaded.`,
    );
  }
  const type = res.headers.get('content-type') || '';
  if (!res.ok || type.includes('text/html')) {
    throw new Error(
      a === 'lite'
        ? 'The pose model file is missing. Run "npm run setup:assets" and rebuild.'
        : `The ${name} model is not part of this build.`,
    );
  }
  return url;
}

// ---------- live video detection ----------

export interface Detector {
  accuracy: Accuracy;
  delegate: 'GPU' | 'CPU';
  detect(source: HTMLCanvasElement): Person[];
  setMaxPeople(n: number): void;
  close(): void;
}

const live = new Map<Accuracy, Promise<Detector>>();

export function loadDetector(accuracy: Accuracy = 'lite'): Promise<Detector> {
  let p = live.get(accuracy);
  if (!p) {
    p = createLive(accuracy).catch((e) => {
      live.delete(accuracy);
      throw e;
    });
    live.set(accuracy, p);
  }
  return p;
}

/** Frees a model that is no longer in use (the Heavy model holds a lot of memory). */
export function releaseDetector(accuracy: Accuracy) {
  const p = live.get(accuracy);
  live.delete(accuracy);
  void p?.then((d) => d.close()).catch(() => undefined);
}

async function createLive(accuracy: Accuracy): Promise<Detector> {
  const [{ mod, fileset }, modelUrl] = await Promise.all([prepare(), modelUrlFor(accuracy)]);
  const make = (delegate: 'GPU' | 'CPU') =>
    mod.PoseLandmarker.createFromOptions(fileset, {
      baseOptions: { modelAssetPath: modelUrl, delegate },
      runningMode: 'VIDEO',
      numPoses: 1,
      minPoseDetectionConfidence: 0.5,
      minPosePresenceConfidence: 0.5,
      minTrackingConfidence: 0.5,
    });

  let lm: PoseLandmarker;
  let delegate: 'GPU' | 'CPU' = 'GPU';
  try {
    lm = await make('GPU');
  } catch {
    try {
      lm = await make('CPU');
      delegate = 'CPU';
    } catch {
      throw new Error('Pose detection is not supported in this browser. Try a recent version of Chrome.');
    }
  }

  let lastTs = 0;
  let people = 1;
  return {
    accuracy,
    delegate,
    detect(source) {
      const ts = Math.max(performance.now(), lastTs + 1); // timestamps must increase
      lastTs = ts;
      return lm.detectForVideo(source, ts).landmarks.map(toPerson);
    },
    setMaxPeople(n) {
      if (n === people) return;
      people = n;
      void lm.setOptions({ numPoses: n });
    },
    close() {
      try {
        lm.close();
      } catch {
        /* already closed */
      }
    },
  };
}

// ---------- single still photo, with body masks (used by the pose creator) ----------

export interface BodyMask { data: Float32Array; width: number; height: number }
export interface StillResult { persons: Person[]; masks: (BodyMask | null)[] }
export interface StillDetector { accuracy: Accuracy; detect(source: HTMLCanvasElement): StillResult; close(): void }

// Only the most recently used model is kept for stills, so switching Accuracy does not pile up memory.
let still: { accuracy: Accuracy; promise: Promise<StillDetector> } | null = null;

export function loadStillDetector(accuracy: Accuracy = 'lite'): Promise<StillDetector> {
  if (still && still.accuracy === accuracy) return still.promise;
  const old = still;
  void old?.promise.then((d) => d.close()).catch(() => undefined);
  const promise = createStill(accuracy).catch((e) => {
    if (still?.promise === promise) still = null;
    throw e;
  });
  still = { accuracy, promise };
  return promise;
}

async function createStill(accuracy: Accuracy): Promise<StillDetector> {
  const [{ mod, fileset }, modelUrl] = await Promise.all([prepare(), modelUrlFor(accuracy)]);
  // CPU is plenty fast for one photo and avoids GPU quirks with segmentation masks.
  const lm = await mod.PoseLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: modelUrl, delegate: 'CPU' },
    runningMode: 'IMAGE',
    numPoses: 5,
    minPoseDetectionConfidence: 0.5,
    minPosePresenceConfidence: 0.5,
    outputSegmentationMasks: true,
  });
  return {
    accuracy,
    detect(source) {
      const r = lm.detect(source);
      const masks = r.landmarks.map((_, i): BodyMask | null => {
        const m = r.segmentationMasks?.[i];
        if (!m) return null;
        try {
          return { data: m.getAsFloat32Array().slice(), width: m.width, height: m.height };
        } finally {
          m.close();
        }
      });
      return { persons: r.landmarks.map(toPerson), masks };
    },
    close() {
      try {
        lm.close();
      } catch {
        /* already closed */
      }
    },
  };
}
