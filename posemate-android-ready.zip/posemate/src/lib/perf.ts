// Keeps the camera loop from overloading the phone.
//
// Detection normally runs up to 20 times a second. If a phone cannot keep up (slow chip, or a hot
// phone that has slowed itself down), the governor steps the rate down so the video stays smooth
// and the phone stops heating up, then steps it back up once there is room again.
// Battery saver lowers the ceiling. All numbers are first guesses to tune on real phones.

export const FPS_LEVELS = [20, 15, 10, 6] as const;
export const SAVER_LEVEL = 2; // battery saver never runs faster than FPS_LEVELS[2] = 10 per second
export const IDLE_FPS = 6; // nobody in the frame: just check now and then
export const IDLE_AFTER_MS = 3000;

const DOWN_RATIO = 0.75; // work takes more than 75% of the time between frames: too slow
const DOWN_FRAMES = 10; // ...for this many frames in a row
const UP_RATIO = 0.35; // work would use under 35% of the faster rate's frame time: room to speed up
const UP_HOLD_MS = 4000; // ...for this long
const COOLDOWN_MS = 3000; // minimum time between changes, so it does not flip-flop

export class FrameGovernor {
  private level = 0; // index into FPS_LEVELS; higher = slower
  private cap = 0; // slowest-allowed floor for speed, set by battery saver
  private ema = 0;
  private slow = 0;
  private roomSince: number | null = null;
  private changedAt = -Infinity;

  /** Battery saver on: never faster than SAVER_LEVEL. Call every frame; it is cheap. */
  setSaver(on: boolean) {
    this.cap = on ? SAVER_LEVEL : 0;
    if (this.level < this.cap) this.level = this.cap;
  }

  get fps(): number {
    return FPS_LEVELS[this.level];
  }
  /** Milliseconds to wait between detections at the current level. */
  get interval(): number {
    return 1000 / this.fps;
  }
  /** True when the governor had to slow down beyond what battery saver asks for. */
  get eased(): boolean {
    return this.level > this.cap;
  }

  /** Report how long one frame of work (detect + draw) took, in ms, at time `now` (ms). */
  record(workMs: number, now: number) {
    this.ema = this.ema === 0 ? workMs : this.ema * 0.8 + workMs * 0.2;
    const budget = this.interval;

    if (this.ema > budget * DOWN_RATIO) {
      this.slow++;
      this.roomSince = null;
      if (this.slow >= DOWN_FRAMES && this.level < FPS_LEVELS.length - 1 && now - this.changedAt > COOLDOWN_MS) {
        this.level++;
        this.slow = 0;
        this.changedAt = now;
      }
      return;
    }
    this.slow = 0;

    if (this.level > this.cap) {
      const fasterBudget = 1000 / FPS_LEVELS[this.level - 1];
      if (this.ema < fasterBudget * UP_RATIO) {
        this.roomSince ??= now;
        if (now - this.roomSince >= UP_HOLD_MS && now - this.changedAt > COOLDOWN_MS) {
          this.level--;
          this.roomSince = null;
          this.changedAt = now;
        }
      } else {
        this.roomSince = null;
      }
    } else {
      this.roomSince = null;
    }
  }
}
