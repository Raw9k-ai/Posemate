// Phone tilt for the level line. Pure maths, no browser APIs, so it can be tested on its own.
//
// Why not just read "gamma" as the left-right tilt? Because with the phone held upright (how you
// hold it to take a photo) the browser's beta/gamma angles mix together and gamma is NOT the
// roll. So we turn beta/gamma into the direction gravity pulls, in the phone's own axes, and
// measure everything from that. It works the same in portrait and landscape.

export interface Gravity { x: number; y: number; z: number } // unit vector, "down", in the phone's axes
// x: toward the phone's right edge, y: toward the top of the screen, z: out of the screen toward you

const rad = (d: number) => (d * Math.PI) / 180;
const deg = (r: number) => (r * 180) / Math.PI;

/** From DeviceOrientation beta and gamma (degrees). Alpha (the compass heading) does not matter for gravity. */
export function gravityFromOrientation(betaDeg: number, gammaDeg: number): Gravity {
  const b = rad(betaDeg);
  const g = rad(gammaDeg);
  return { x: Math.sin(g) * Math.cos(b), y: -Math.sin(b), z: -Math.cos(g) * Math.cos(b) };
}

/**
 * How far the phone is turned about the viewing axis, measured from the nearest way of holding it
 * (upright portrait, or landscape either way). Positive = turned clockwise as the person holding it
 * sees it. Range -45..45. Null when the phone is nearly flat, where roll means nothing.
 */
export function rollDeg(g: Gravity): number | null {
  if (Math.hypot(g.x, g.y) < 0.35) return null;
  const a = deg(Math.atan2(g.x, -g.y)); // 0 = upright, +90 = right edge down
  return ((((a + 45) % 90) + 90) % 90) - 45;
}

/** How far the camera's view points above (+) or below (-) the horizon. The rear camera looks out of the back. */
export function pitchDeg(g: Gravity, facing: 'user' | 'environment'): number {
  const el = deg(Math.asin(Math.max(-1, Math.min(1, g.z)))); // elevation of the rear camera's view
  return facing === 'environment' ? el : -el;
}

/** Smooths the gravity direction (not the angles, which jump where they wrap) so the line does not twitch. */
export class GravitySmoother {
  private cur: Gravity | null = null;
  constructor(private alpha = 0.3) {}
  push(g: Gravity): Gravity {
    if (!this.cur) {
      this.cur = { ...g };
      return this.cur;
    }
    const c = this.cur;
    c.x += this.alpha * (g.x - c.x);
    c.y += this.alpha * (g.y - c.y);
    c.z += this.alpha * (g.z - c.z);
    const n = Math.hypot(c.x, c.y, c.z) || 1;
    return { x: c.x / n, y: c.y / n, z: c.z / n };
  }
  reset() {
    this.cur = null;
  }
}

// Near 45 degrees the phone is as close to portrait as to landscape, so the reading has to flip there.
// Nobody is trying to be level at that angle, so the line is simply hidden beyond this.
export const LEVEL_MAX = 35;
export const showsLevel = (roll: number | null): roll is number => roll !== null && Math.abs(roll) <= LEVEL_MAX;

export type LevelState = 'level' | 'near' | 'off';
export function levelState(roll: number): LevelState {
  const a = Math.abs(roll);
  return a <= 1 ? 'level' : a <= 3 ? 'near' : 'off';
}

/** A short note when the camera is clearly pointing up or down (makes people look top-heavy or squashed). */
export function pitchHint(pitch: number): string | null {
  const n = Math.round(Math.abs(pitch));
  if (Math.abs(pitch) <= 5) return null;
  return `Tilted ${pitch > 0 ? 'up' : 'down'} ${n}°`;
}
