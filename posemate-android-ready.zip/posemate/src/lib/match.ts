import type { Figure, JointName } from '../data/poses';
import type { Person } from './draw';

const SEGS: [JointName, JointName][] = [
  ['lSh', 'lEl'], ['lEl', 'lWr'], ['rSh', 'rEl'], ['rEl', 'rWr'],
  ['lHip', 'lKn'], ['lKn', 'lAn'], ['rHip', 'rKn'], ['rKn', 'rAn'],
];

/**
 * Compares the direction of each visible limb segment with the reference pose.
 * 0 = every limb 60 degrees or more off, 1 = identical. Returns null when too
 * few limbs are visible to judge. This is a 2D approximation of the pose.
 */
export function matchScore(p: Person, ref: Figure, vw: number, vh: number): number | null {
  let sum = 0;
  let weight = 0;
  let used = 0;
  for (const [a, b] of SEGS) {
    if (p[a].v < 0.5 || p[b].v < 0.5) continue;
    const rdx = ref[b][0] - ref[a][0];
    const rdy = ref[b][1] - ref[a][1];
    const rl = Math.hypot(rdx, rdy);
    if (rl < 0.06) continue; // too foreshortened to judge
    const dx = (p[b].x - p[a].x) * vw; // normalised -> pixels so angles are true
    const dy = (p[b].y - p[a].y) * vh;
    if (Math.hypot(dx, dy) < 1e-3) continue;
    let d = Math.abs(Math.atan2(dy, dx) - Math.atan2(rdy, rdx));
    if (d > Math.PI) d = 2 * Math.PI - d;
    sum += Math.max(0, 1 - d / (Math.PI / 3)) * rl;
    weight += rl;
    used++;
  }
  return used < 4 ? null : sum / weight;
}

export function matchLabel(score: number): string {
  if (score >= 0.85) return 'Nailed it';
  if (score >= 0.7) return 'Very close';
  if (score >= 0.5) return 'Getting there';
  return 'Adjust your pose';
}

// ---------- on-camera advice ----------

const LIMB_NAMES: Record<string, string> = {
  'lSh-lEl': 'left arm', 'lEl-lWr': 'left forearm', 'rSh-rEl': 'right arm', 'rEl-rWr': 'right forearm',
  'lHip-lKn': 'left leg', 'lKn-lAn': 'left lower leg', 'rHip-rKn': 'right leg', 'rKn-rAn': 'right lower leg',
};
// forearm -> upper arm, lower leg -> thigh
const PROXIMAL: Record<string, string> = { 'lEl-lWr': 'lSh-lEl', 'rEl-rWr': 'rSh-rEl', 'lKn-lAn': 'lHip-lKn', 'rKn-rAn': 'rHip-rKn' };
const HINT_MIN_ERROR = (35 * Math.PI) / 180; // only advise when a limb is at least 35 degrees off

/**
 * One short instruction for the limb that is furthest from the reference pose, for example
 * "Lift your left forearm". Left and right mean the person's own left and right. Returns null
 * when no limb is clearly off or too few limbs are visible.
 */
export function matchHint(p: Person, ref: Figure, vw: number, vh: number): string | null {
  type Off = { key: string; d: number; err: number; vx: number; vy: number; side: 1 | -1 };
  const off: Record<string, Off> = {};
  for (const [a, b] of SEGS) {
    if (p[a].v < 0.5 || p[b].v < 0.5) continue;
    const rdx = ref[b][0] - ref[a][0];
    const rdy = ref[b][1] - ref[a][1];
    const rl = Math.hypot(rdx, rdy);
    if (rl < 0.06) continue;
    const dx = (p[b].x - p[a].x) * vw;
    const dy = (p[b].y - p[a].y) * vh;
    const cl = Math.hypot(dx, dy);
    if (cl < 1e-3) continue;
    let d = Math.abs(Math.atan2(dy, dx) - Math.atan2(rdy, rdx));
    if (d > Math.PI) d = 2 * Math.PI - d;
    const key = `${a}-${b}`;
    off[key] = { key, d, err: d * (0.5 + rl), vx: rdx / rl - dx / cl, vy: rdy / rl - dy / cl, side: a.startsWith('l') ? 1 : -1 };
  }
  let worst: Off | null = null;
  for (const o of Object.values(off)) {
    if (o.d >= HINT_MIN_ERROR && (!worst || o.err > worst.err)) worst = o;
  }
  if (!worst) return null;
  // Coach from the shoulder or hip outward: if the upper arm or thigh is off too, mention that first.
  const upper = PROXIMAL[worst.key];
  if (upper && off[upper] && off[upper].d >= HINT_MIN_ERROR) worst = off[upper];

  const name = LIMB_NAMES[worst.key];
  if (Math.abs(worst.vy) >= Math.abs(worst.vx)) return worst.vy < 0 ? `Lift your ${name}` : `Lower your ${name}`;
  // A person's left side is on the right of the picture (+x), so outward is +x for left limbs, -x for right limbs.
  return worst.vx * worst.side > 0 ? `Move your ${name} out` : `Bring your ${name} in`;
}

/**
 * Keeps advice steady: a tip stays for at least 1.2 s before it can change to a different one,
 * and goes away only after the problem has been gone for 0.6 s.
 */
export class HintKeeper {
  private current: string | null = null;
  private since = 0;
  private lastSeen = 0;

  update(next: string | null, now: number): string | null {
    if (next === null) {
      if (this.current && now - this.lastSeen > 600) this.current = null;
    } else if (this.current === null) {
      this.current = next;
      this.since = this.lastSeen = now;
    } else if (next === this.current) {
      this.lastSeen = now;
    } else if (now - this.since >= 1200) {
      this.current = next;
      this.since = this.lastSeen = now;
    }
    return this.current;
  }

  reset() {
    this.current = null;
    this.since = this.lastSeen = 0;
  }
}
