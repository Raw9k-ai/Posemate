// The "Accuracy" setting: which MediaPipe Pose Landmarker model to run.
// Kept free of imports so it can be tested on its own.

export type Accuracy = 'lite' | 'full' | 'heavy';
export const ACCURACIES: readonly Accuracy[] = ['lite', 'full', 'heavy'];

export const ACCURACY_INFO: Record<Accuracy, { label: string; mb: number; blurb: string }> = {
  lite: { label: 'Lite', mb: 6, blurb: 'Fastest and gentlest on the battery' },
  full: { label: 'Full', mb: 9, blurb: 'Steadier joints, a little slower' },
  heavy: { label: 'Heavy', mb: 30, blurb: 'Most accurate, best on a fast phone' },
};

export const isAccuracy = (v: unknown): v is Accuracy => v === 'lite' || v === 'full' || v === 'heavy';
export const modelPath = (a: Accuracy) => `models/pose_landmarker_${a}.task`;

/**
 * Loads the model the user asked for; if Full or Heavy cannot be loaded (not on this site,
 * offline before it was ever saved, unsupported), quietly uses Lite and reports why.
 * Lite itself is not retried: if it fails there is nothing left to fall back to.
 */
export async function withFallback<T>(
  want: Accuracy,
  load: (a: Accuracy) => Promise<T>,
): Promise<{ value: T; used: Accuracy; failed?: { accuracy: Accuracy; message: string } }> {
  try {
    return { value: await load(want), used: want };
  } catch (e) {
    if (want === 'lite') throw e;
    const message = e instanceof Error ? e.message : 'It could not be loaded.';
    return { value: await load('lite'), used: 'lite', failed: { accuracy: want, message } };
  }
}
