// Candid burst: grab a short run of frames, score each one, and let the person pick.
// Frames come from the live video (not the full-sensor photo), so they match what was on screen
// and can be taken fast. The original frame is never edited; scoring works on a tiny copy.
import type { Person } from './draw';

export const BURST_COUNT = 6;
export const BURST_GAP_MS = 220;
const SCORE_W = 160; // width of the copy used for the sharpness check

export interface BurstFrame {
  blob: Blob;
  width: number;
  height: number;
  people: Person[];
  match: number | null; // 0..1, solo poses only
  sharp: number; // variance of the Laplacian of a small grey copy; bigger is sharper
}

/** Variance of the 4-neighbour Laplacian over the inner pixels. Blurry frames score low. */
export function sharpness(gray: ArrayLike<number>, w: number, h: number): number {
  if (w < 3 || h < 3) return 0;
  let sum = 0;
  let sum2 = 0;
  let n = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const l = 4 * gray[i] - gray[i - 1] - gray[i + 1] - gray[i - w] - gray[i + w];
      sum += l;
      sum2 += l * l;
      n++;
    }
  }
  const mean = sum / n;
  return sum2 / n - mean * mean;
}

/** Luma (0..255) from RGBA pixels. */
export function toGray(rgba: ArrayLike<number>, w: number, h: number): Float32Array {
  const out = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) out[i] = 0.299 * rgba[i * 4] + 0.587 * rgba[i * 4 + 1] + 0.114 * rgba[i * 4 + 2];
  return out;
}

export interface FrameStats {
  sharp: number;
  match: number | null;
  people: number;
}

/**
 * One score per frame, 0..1. Weights: sharpness (relative to the sharpest frame in this burst)
 * and having the usual number of people in view; solo poses also count the match score.
 * The usual number is `wantPeople` (the pose's figure count) or the most common count in the burst.
 */
export function scoreFrames(stats: FrameStats[], wantPeople?: number | null): number[] {
  if (stats.length === 0) return [];
  const maxSharp = Math.max(...stats.map((s) => s.sharp));
  let target = wantPeople ?? 0;
  if (!wantPeople) {
    const counts = new Map<number, number>();
    for (const s of stats) counts.set(s.people, (counts.get(s.people) ?? 0) + 1);
    let best = -1;
    for (const [k, c] of counts) if (c > best || (c === best && k > target)) { best = c; target = k; }
  }
  return stats.map((s) => {
    const sharpRel = maxSharp > 0 ? s.sharp / maxSharp : 1;
    const ok = s.people === 0 ? 0 : s.people === target ? 1 : 0.5;
    return s.match === null ? 0.7 * sharpRel + 0.3 * ok : 0.5 * sharpRel + 0.3 * s.match + 0.2 * ok;
  });
}

/** Index of the highest score; the earliest frame wins ties. -1 for an empty list. */
export function bestIndex(scores: number[]): number {
  let b = -1;
  scores.forEach((s, i) => { if (b < 0 || s > scores[b] + 1e-9) b = i; });
  return b;
}

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/**
 * Takes `count` frames from the video, `gap` ms apart. `snapshot` returns what the tracker sees
 * right now (people and match). `onProgress` is called after each frame.
 */
export async function captureBurst(
  video: HTMLVideoElement,
  snapshot: () => { people: Person[]; match: number | null },
  onProgress?: (done: number) => void,
  count = BURST_COUNT,
  gap = BURST_GAP_MS,
): Promise<BurstFrame[]> {
  const w = video.videoWidth;
  const h = video.videoHeight;
  if (!w || !h) throw new Error('The camera is not ready yet.');
  const sw = SCORE_W;
  const sh = Math.max(3, Math.round((SCORE_W * h) / w));
  const small = document.createElement('canvas');
  small.width = sw;
  small.height = sh;
  const sctx = small.getContext('2d', { willReadFrequently: true });
  if (!sctx) throw new Error('Could not read the camera frame.');

  const pending: { blob: Promise<Blob | null>; stats: FrameStats; people: Person[]; match: number | null }[] = [];
  for (let i = 0; i < count; i++) {
    const t0 = performance.now();
    const full = document.createElement('canvas'); // a canvas per frame: toBlob snapshots at call time
    full.width = w;
    full.height = h;
    const ctx = full.getContext('2d');
    if (!ctx) throw new Error('Could not read the camera frame.');
    ctx.drawImage(video, 0, 0, w, h);
    sctx.drawImage(video, 0, 0, sw, sh);
    const sharp = sharpness(toGray(sctx.getImageData(0, 0, sw, sh).data, sw, sh), sw, sh);
    const snap = snapshot();
    pending.push({
      blob: new Promise<Blob | null>((res) => full.toBlob(res, 'image/jpeg', 0.92)),
      stats: { sharp, match: snap.match, people: snap.people.length },
      people: snap.people,
      match: snap.match,
    });
    onProgress?.(i + 1);
    if (i < count - 1) await wait(Math.max(0, gap - (performance.now() - t0)));
  }
  const frames: BurstFrame[] = [];
  for (const p of pending) {
    const blob = await p.blob;
    if (blob) frames.push({ blob, width: w, height: h, people: p.people, match: p.match, sharp: p.stats.sharp });
  }
  if (frames.length === 0) throw new Error('Could not encode the photos.');
  return frames;
}
