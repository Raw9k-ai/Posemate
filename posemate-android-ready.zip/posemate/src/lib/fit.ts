import type { Figure, JointName } from '../data/poses';
import type { Person } from './draw';

// Lines the reference guide up with a real person: scale and shift it to the person's size and
// position in the frame. Numbers are in frame (or photo) pixels, vw x vh. Used by the
// before/after slider so the wipe compares two poses, not two positions.

export interface Fit {
  s: number; // scale
  cu: { x: number; y: number }; // where the guide's anchor should land (the person)
  cr: { x: number; y: number }; // the guide's anchor in its default placement
}
export type FitMode = 'body' | 'torso';

const ALL: JointName[] = ['nose', 'lSh', 'rSh', 'lEl', 'rEl', 'lWr', 'rWr', 'lHip', 'rHip', 'lKn', 'rKn', 'lAn', 'rAn'];
const TORSO: JointName[] = ['lSh', 'rSh', 'lHip', 'rHip'];
const vis = (p: Person, j: JointName) => p[j].v >= 0.5;

interface Box { x0: number; y0: number; x1: number; y1: number }
const empty = (): Box => ({ x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity });
const grow = (b: Box, x: number, y: number) => {
  b.x0 = Math.min(b.x0, x); b.x1 = Math.max(b.x1, x);
  b.y0 = Math.min(b.y0, y); b.y1 = Math.max(b.y1, y);
};
const centre = (b: Box) => ({ x: (b.x0 + b.x1) / 2, y: (b.y0 + b.y1) / 2 });

/** The square the guide is drawn into by default (same rule as drawOverlay): centred across, a little low. */
export function guideSquare(vw: number, vh: number) {
  const side = Math.min(vw, vh);
  return { side, bx: (vw - side) / 2, by: (vh - side) * 0.55 };
}

/**
 * Full-body fit when everyone's head and a foot are visible, otherwise a torso fit, otherwise null
 * (the guide then stays in its default place). Needs one detected person per reference figure.
 */
export function computeFit(persons: Person[], figures: Figure[], vw: number, vh: number): (Fit & { mode: FitMode }) | null {
  if (!persons.length || persons.length !== figures.length) return null;
  const { side, bx, by } = guideSquare(vw, vh);

  const build = (joints: JointName[], mode: FitMode, need: (p: Person) => boolean) => {
    if (!persons.every(need)) return null;
    const u = empty();
    const r = empty();
    for (const p of persons) for (const j of joints) if (vis(p, j)) grow(u, p[j].x * vw, p[j].y * vh);
    for (const f of figures) for (const j of joints) grow(r, bx + f[j][0] * side, by + f[j][1] * side);
    const hu = u.y1 - u.y0;
    const hr = r.y1 - r.y0;
    if (!(hu > 8) || !(hr > 1e-6)) return null;
    return { s: Math.min(3, Math.max(0.35, hu / hr)), cu: centre(u), cr: centre(r), mode };
  };

  return (
    build(ALL, 'body', (p) => vis(p, 'nose') && (vis(p, 'lAn') || vis(p, 'rAn'))) ??
    build(TORSO, 'torso', (p) => TORSO.every((j) => vis(p, j)))
  );
}
