import type { Figure } from '../data/poses';
import type { Person } from './draw';
import { matchScore } from './match';

// Small pure helpers for the before/after slider.

export const clampPct = (v: number) => Math.min(100, Math.max(0, v));

/** Where the divider should sit (0..100) for a pointer at clientX over a box starting at `left`. */
export function pctFromPointer(clientX: number, left: number, width: number): number {
  if (!(width > 0)) return 50;
  return clampPct(((clientX - left) / width) * 100);
}

/** CSS clip that shows only the left `pct` percent of a layer. */
export const revealLeft = (pct: number) => `inset(0 ${100 - clampPct(pct)}% 0 0)`;

/** Keyboard control for the slider. Returns the new position, or null if the key is not ours. */
export function stepPct(pct: number, key: string, shift = false): number | null {
  const step = shift ? 20 : 5;
  switch (key) {
    case 'ArrowLeft':
    case 'ArrowDown':
      return clampPct(pct - step);
    case 'ArrowRight':
    case 'ArrowUp':
      return clampPct(pct + step);
    case 'Home':
      return 0;
    case 'End':
      return 100;
    default:
      return null;
  }
}

/** Whole-number match percentage for a solo pose, or null when it cannot be judged. */
export function comparePercent(people: Person[], figures: Figure[], vw: number, vh: number): number | null {
  if (people.length !== 1 || figures.length !== 1) return null;
  const s = matchScore(people[0], figures[0], vw, vh);
  return s === null ? null : Math.round(s * 100);
}
