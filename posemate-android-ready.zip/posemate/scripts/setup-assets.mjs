// Copies the MediaPipe WASM runtime out of node_modules and downloads the pose models,
// so the deployed site serves everything from its own origin.
// Result: no third-party requests when a visitor uses the app.
//
// Runs on `npm install` and before `npm run build`. Safe to re-run.
//
// Models (the "Accuracy" setting in the app): lite ~6 MB (required), full ~9 MB, heavy ~30 MB.
// To keep a slimmer build set POSEMATE_MODELS, for example:  POSEMATE_MODELS=lite npm run build
import { cpSync, existsSync, mkdirSync, writeFileSync, statSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const wasmSrc = resolve(root, 'node_modules/@mediapipe/tasks-vision/wasm');
const wasmDest = resolve(root, 'public/mediapipe/wasm');

const VARIANTS = ['lite', 'full', 'heavy'];
const wanted = (process.env.POSEMATE_MODELS ?? 'lite,full,heavy')
  .split(',')
  .map((s) => s.trim())
  .filter((s) => VARIANTS.includes(s));
if (!wanted.includes('lite')) wanted.unshift('lite'); // the app always needs Lite

const urlFor = (v) =>
  `https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_${v}/float16/latest/pose_landmarker_${v}.task`;
const destFor = (v) => resolve(root, `public/models/pose_landmarker_${v}.task`);

// 1) WASM runtime
if (existsSync(wasmSrc)) {
  mkdirSync(wasmDest, { recursive: true });
  cpSync(wasmSrc, wasmDest, { recursive: true });
  console.log('[posemate] MediaPipe WASM copied to public/mediapipe/wasm');
} else {
  console.warn('[posemate] @mediapipe/tasks-vision not installed yet; skipping WASM copy.');
}

// 2) Model files (downloaded once each)
for (const v of wanted) {
  const dest = destFor(v);
  if (existsSync(dest) && statSync(dest).size > 1_000_000) {
    console.log(`[posemate] ${v} model already present.`);
    continue;
  }
  try {
    mkdirSync(dirname(dest), { recursive: true });
    const res = await fetch(urlFor(v));
    if (!res.ok) throw new Error('HTTP ' + res.status);
    writeFileSync(dest, Buffer.from(await res.arrayBuffer()));
    console.log(`[posemate] ${v} model downloaded to public/models/`);
  } catch (err) {
    console.warn(
      `[posemate] Could not download the ${v} model (${err.message}).\n` +
        (v === 'lite'
          ? '           The app still runs, but skeleton detection will be unavailable.\n'
          : `           The app still runs; choosing "${v}" in Accuracy will fall back to Lite.\n`) +
        `           Download it manually from:\n           ${urlFor(v)}\n` +
        `           and save it as public/models/pose_landmarker_${v}.task`,
    );
  }
}
