// Runs after `vite build`: lists every file in dist/ and writes dist/sw.js from the template.
// Dependency-free so the build needs nothing extra.
import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, statSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = join(root, 'dist');
if (!existsSync(dist)) {
  console.error('[posemate] dist/ not found: run vite build first.');
  process.exit(1);
}

const walk = (dir) =>
  readdirSync(dir).flatMap((n) => {
    const p = join(dir, n);
    return statSync(p).isDirectory() ? walk(p) : [p];
  });

const files = walk(dist)
  .map((p) => relative(dist, p).split('\\').join('/'))
  .filter((f) => f !== 'sw.js' && !f.endsWith('.map') && f !== '.DS_Store')
  .sort();

// Full and Heavy pose models are optional (Accuracy setting). They are NOT downloaded on install;
// the service worker saves each one the first time it is used.
const isOptionalModel = (f) => /^models\/pose_landmarker_(full|heavy)\.task$/.test(f);
const isHeavy = (f) => f.startsWith('mediapipe/') || (f.startsWith('models/') && !isOptionalModel(f));
const heavy = files.filter(isHeavy);
const optional = files.filter(isOptionalModel);
const isCore = (f) => !isHeavy(f) && !isOptionalModel(f);
const core = ['./', ...files.filter(isCore)];

const hash = (parts) => createHash('sha1').update(parts).digest('hex').slice(0, 10);
const coreVer = hash(files.filter(isCore).map((f) => f + readFileSync(join(dist, f)).length + hash(readFileSync(join(dist, f)))).join('|'));
const heavyVer = hash(heavy.map((f) => f + statSync(join(dist, f)).size).join('|'));
const modelsVer = optional.length ? hash(optional.map((f) => f + statSync(join(dist, f)).size).join('|')) : 'none';

const out = readFileSync(join(root, 'scripts/sw-template.js'), 'utf8')
  .replace('__CORE_VER__', coreVer)
  .replace('__HEAVY_VER__', heavyVer)
  .replace('__MODELS_VER__', modelsVer)
  .replace('__CORE__', JSON.stringify(core, null, 2))
  .replace('__HEAVY__', JSON.stringify(heavy, null, 2));
writeFileSync(join(dist, 'sw.js'), out);

const mb = (list) => (list.reduce((s, f) => s + statSync(join(dist, f)).size, 0) / 1048576).toFixed(1);
console.log(`[posemate] sw.js written: ${core.length} app files (${mb(core.filter((f) => f !== './'))} MB), ${heavy.length} model/WASM files (${mb(heavy)} MB) saved on install, ${optional.length} optional model(s) (${mb(optional)} MB) saved on first use.`);
if (heavy.length === 0) console.warn('[posemate] No model/WASM files in dist/: offline pose detection will not work. Run npm run setup:assets and rebuild.');
