import { readFileSync, writeFileSync } from 'node:fs';

const path = 'android/app/src/main/AndroidManifest.xml';
let manifest = readFileSync(path, 'utf8');
const permission = '<uses-permission android:name="android.permission.CAMERA" />';
if (!manifest.includes(permission)) {
  manifest = manifest.replace('<application', `${permission}\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application`);
  writeFileSync(path, manifest);
  console.log('Added camera permission to AndroidManifest.xml');
} else {
  console.log('Camera permission already present');
}
