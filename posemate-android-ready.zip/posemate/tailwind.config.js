/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#12142B',
        paper: '#F3F4FA',
        volt: '#D9F24B',
        cobalt: '#3D4DFF',
        bubble: '#FF8FC0',
        aqua: '#6FE3E1',
        lilac: '#B7A9FF',
        sun: '#FFC24B',
        mist: '#A9D4FF',
        mint: '#B8EBC0',
        coral: '#FF9E85',
      },
      fontFamily: {
        sans: ['system-ui', '-apple-system', 'Roboto', '"Segoe UI"', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
