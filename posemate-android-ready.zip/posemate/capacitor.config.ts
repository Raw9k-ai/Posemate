import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.raw9kai.posemate',
  appName: 'PoseMate',
  webDir: 'dist',
  // Keep app assets local. Do not point this at the hosted website.
  android: {
    allowMixedContent: false,
  },
};

export default config;
