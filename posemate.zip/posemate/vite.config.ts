import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' makes the build work from any URL path (root domain, GitHub Pages
// sub-folder, or opened from a plain static file host).
export default defineConfig({
  base: './',
  plugins: [react()],
  build: { target: 'es2020', chunkSizeWarningLimit: 700 },
});
