import { useCallback, useEffect, useRef, useState } from 'react';
import type { Figure, Outline, Stroke } from '../data/poses';
import { drawOverlay, type Person } from '../lib/draw';

interface Props {
  url: string;
  width: number;
  height: number;
  people: Person[];
  figures?: Figure[];
  outlines?: (Outline | null)[];
  details?: (Stroke[] | null)[];
  overlayValid: boolean;
}

/**
 * Shows the untouched original photo, with the pose overlay on a separate
 * canvas that can be switched on and off.
 */
export default function PhotoWithOverlay({ url, width, height, people, figures, outlines, details, overlayValid }: Props) {
  const [on, setOn] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const hasOverlay = overlayValid && (people.length > 0 || (figures?.length ?? 0) > 0);

  const draw = useCallback(() => {
    const c = cv.current;
    if (!c) return;
    if (!on || !hasOverlay) {
      c.getContext('2d')?.clearRect(0, 0, c.width, c.height);
      return;
    }
    drawOverlay(c, { vw: width, vh: height, persons: people, reference: figures, outlines, details });
  }, [on, hasOverlay, width, height, people, figures, outlines, details]);

  useEffect(() => {
    draw();
    const el = box.current;
    if (!el) return;
    const ro = new ResizeObserver(draw);
    ro.observe(el);
    return () => ro.disconnect();
  }, [draw]);

  return (
    <div ref={box} className="relative h-full w-full">
      <img src={url} alt="Captured photo" className="h-full w-full object-contain" />
      <canvas ref={cv} className="pointer-events-none absolute inset-0 h-full w-full" />
      {hasOverlay && (
        <button
          onClick={() => setOn((v) => !v)}
          aria-pressed={on}
          className={`absolute bottom-3 left-3 rounded-full px-4 py-2 text-sm font-bold backdrop-blur ${on ? 'bg-volt text-ink' : 'bg-black/55 text-white'}`}
        >
          {on ? 'Hide pose overlay' : 'Show pose overlay'}
        </button>
      )}
    </div>
  );
}
