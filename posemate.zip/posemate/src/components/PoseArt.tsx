import { BONES, type Figure, type JointName, type Outline, type Stroke } from '../data/poses';
import { bodyShapes } from '../lib/silhouette';

const INK = ['#12142B', '#3D4DFF', '#12142B', '#3D4DFF', '#12142B'];

/** Body-silhouette illustration drawn from the same data the live guide uses. */
export default function PoseArt({
  figures,
  outlines,
  details,
  detail = true,
  className = '',
}: {
  figures: Figure[];
  outlines?: (Outline | null)[];
  details?: (Stroke[] | null)[];
  /** Draw inner lines and skeleton on traced figures (turn off for tiny thumbnails). */
  detail?: boolean;
  className?: string;
}) {
  return (
    <svg viewBox="0 0 100 100" className={className} role="img" aria-label="Pose reference illustration">
      {figures.map((f, i) => {
        const color = INK[i % INK.length];
        const traced = outlines?.[i];
        if (traced) {
          const strokes = detail ? details?.[i] : null;
          const J = (j: JointName) => ({ x: f[j][0] * 100, y: f[j][1] * 100 });
          const sw = Math.hypot(f.lSh[0] - f.rSh[0], f.lSh[1] - f.rSh[1]) * 100;
          return (
            <g key={i}>
              <polygon
                points={traced.map(([x, y]) => `${x * 100},${y * 100}`).join(' ')}
                fill={color}
                stroke={color}
                strokeWidth={0.6}
                strokeLinejoin="round"
              />
              {strokes && (
                <g fill="none" stroke="#C8F7FF" strokeOpacity={0.55} strokeWidth={0.35} strokeLinecap="round" strokeLinejoin="round">
                  {strokes.map((line, k) => (
                    <polyline key={k} points={line.map(([x, y]) => `${x * 100},${y * 100}`).join(' ')} />
                  ))}
                </g>
              )}
              {detail && (
                <g stroke="#FF5CF4" strokeOpacity={0.65} strokeWidth={0.9} strokeLinecap="round" fill="none">
                  {BONES.map(([a, b]) => (
                    <line key={a + b} x1={J(a).x} y1={J(a).y} x2={J(b).x} y2={J(b).y} />
                  ))}
                  <circle cx={J('nose').x} cy={J('nose').y} r={Math.max(1.5, sw * 0.3)} />
                </g>
              )}
            </g>
          );
        }
        const pts = {} as Record<JointName, { x: number; y: number }>;
        (Object.keys(f) as JointName[]).forEach((j) => {
          pts[j] = { x: f[j][0] * 100, y: f[j][1] * 100 };
        });
        return (
          <g key={i} fill={color} stroke={color} strokeLinecap="round" strokeLinejoin="round">
            {bodyShapes(pts).map((s, k) =>
              s.t === 'cap' ? (
                <line key={k} x1={s.a.x} y1={s.a.y} x2={s.b.x} y2={s.b.y} strokeWidth={s.r * 2} fill="none" />
              ) : s.t === 'ell' ? (
                <ellipse key={k} cx={s.c.x} cy={s.c.y} rx={s.rx} ry={s.ry} stroke="none" transform={`rotate(${(s.rot * 180) / Math.PI} ${s.c.x} ${s.c.y})`} />
              ) : s.t === 'poly' ? (
                <polygon key={k} points={s.pts.map((q) => `${q.x},${q.y}`).join(' ')} strokeWidth={s.r * 2} />
              ) : null,
            )}
          </g>
        );
      })}
    </svg>
  );
}
