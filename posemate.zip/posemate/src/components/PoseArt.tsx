import { BONES, type Figure, type JointName, type Outline, type Stroke } from '../data/poses';
import { bodyShapes } from '../lib/silhouette';

const INK = ['#12142B', '#3D4DFF', '#12142B', '#3D4DFF', '#12142B'];

const LIMBS: [JointName, JointName][] = [
  ['lSh', 'rSh'], ['lSh', 'lEl'], ['lEl', 'lWr'], ['rSh', 'rEl'], ['rEl', 'rWr'],
  ['lHip', 'lKn'], ['lKn', 'lAn'], ['rHip', 'rKn'], ['rKn', 'rAn'],
];

/** Body-silhouette illustration drawn from the same data the live guide uses. */
export default function PoseArt({
  figures,
  outlines,
  details,
  detail = true,
  className = '',
}: {
  figures: Figure[];
  outlines?: (Outline | null)[];
  details?: (Stroke[] | null)[];
  /** Draw inner lines and skeleton on traced figures (turn off for tiny thumbnails). */
  detail?: boolean;
  className?: string;
}) {
  return (
    <svg viewBox="0 0 100 100" className={className} role="img" aria-label="Pose reference illustration">
      {figures.map((f, i) => {
        const color = INK[i % INK.length];
        const traced = outlines?.[i];
        if (traced) {
          const strokes = detail ? details?.[i] : null;
          const J = (j: JointName) => ({ x: f[j][0] * 100, y: f[j][1] * 100 });
          const sw = Math.hypot(f.lSh[0] - f.rSh[0], f.lSh[1] - f.rSh[1]) * 100;
          return (
            <g key={i}>
              <polygon
                points={traced.map(([x, y]) => `${x * 100},${y * 100}`).join(' ')}
                fill={color}
                stroke={color}
                strokeWidth={0.6}
                strokeLinejoin="round"
              />
              {strokes && (
                <g fill="none" stroke="#C8F7FF" strokeOpacity={0.55} strokeWidth={0.35} strokeLinecap="round" strokeLinejoin="round">
                  {strokes.map((line, k) => (
                    <polyline key={k} points={line.map(([x, y]) => `${x * 100},${y * 100}`).join(' ')} />
                  ))}
                </g>
              )}
              {detail && (
                <g stroke="#FF5CF4" strokeOpacity={0.65} strokeWidth={0.9} strokeLinecap="round" fill="none">
                  {BONES.map(([a, b]) => (
                    <line key={a + b} x1={J(a).x} y1={J(a).y} x2={J(b).x} y2={J(b).y} />
                  ))}
                  <circle cx={J('nose').x} cy={J('nose').y} r={Math.max(1.5, sw * 0.3)} />
                </g>
              )}
            </g>
          );
        }
        const pts = {} as Record<JointName, { x: number; y: number }>;
        (Object.keys(f) as JointName[]).forEach((j) => {
          pts[j] = { x: f[j][0] * 100, y: f[j][1] * 100 };
        });
        const shapes = bodyShapes(pts);
        const torso = Math.hypot((f.lSh[0] + f.rSh[0] - f.lHip[0] - f.rHip[0]) / 2, (f.lSh[1] + f.rSh[1] - f.lHip[1] - f.rHip[1]) / 2);
        const scale = Math.max(0.5, Math.min(1.3, torso / 0.3));
        // grow = extra radius in drawing units; 0 for the body, > 0 for the halo behind it
        const draw = (grow: number) =>
          shapes.map((sh, n) =>
            sh.t === 'cap' ? (
              <line key={n} x1={sh.a.x} y1={sh.a.y} x2={sh.b.x} y2={sh.b.y} strokeWidth={(sh.r + grow) * 2} fill="none" />
            ) : sh.t === 'ell' ? (
              <ellipse key={n} cx={sh.c.x} cy={sh.c.y} rx={sh.rx + grow} ry={sh.ry + grow} stroke="none" transform={`rotate(${(sh.rot * 180) / Math.PI} ${sh.c.x} ${sh.c.y})`} />
            ) : sh.t === 'poly' ? (
              <polygon key={n} points={sh.pts.map((q) => `${q.x},${q.y}`).join(' ')} strokeWidth={(sh.r + grow) * 2} />
            ) : null,
          );
        const J = (j: JointName) => pts[j];
        return (
          <g key={i}>
            {/* white outline behind each person so overlapping people stay separate */}
            {figures.length > 1 && (
              <g fill="#fff" stroke="#fff" strokeLinecap="round" strokeLinejoin="round">{draw(1.1 * scale)}</g>
            )}
            <g fill={color} stroke={color} strokeLinecap="round" strokeLinejoin="round">{draw(0)}</g>
            {/* light limb lines so arms and legs stay readable when they overlap the body */}
            {detail && (
              <g stroke="#fff" strokeOpacity={0.6} strokeWidth={0.9 * scale} strokeLinecap="round" fill="none">
                {LIMBS.map(([a1, b1]) => (
                  <line key={a1 + b1} x1={J(a1).x} y1={J(a1).y} x2={J(b1).x} y2={J(b1).y} />
                ))}
              </g>
            )}
          </g>
        );
      })}
    </svg>
  );
}
