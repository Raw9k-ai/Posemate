import type { Figure, JointName } from '../data/poses';
import { bodyShapes } from '../lib/silhouette';

const INK = ['#12142B', '#3D4DFF', '#12142B', '#3D4DFF', '#12142B'];

/** Body-silhouette illustration drawn from the same joint data the live guide uses. */
export default function PoseArt({ figures, className = '' }: { figures: Figure[]; className?: string }) {
  return (
    <svg viewBox="0 0 100 100" className={className} role="img" aria-label="Pose reference illustration">
      {figures.map((f, i) => {
        const color = INK[i % INK.length];
        const pts = {} as Record<JointName, { x: number; y: number }>;
        (Object.keys(f) as JointName[]).forEach((j) => {
          pts[j] = { x: f[j][0] * 100, y: f[j][1] * 100 };
        });
        return (
          <g key={i} fill={color} stroke={color} strokeLinecap="round" strokeLinejoin="round">
            {bodyShapes(pts).map((s, k) =>
              s.t === 'cap' ? (
                <line key={k} x1={s.a.x} y1={s.a.y} x2={s.b.x} y2={s.b.y} strokeWidth={s.r * 2} fill="none" />
              ) : s.t === 'ell' ? (
                <ellipse key={k} cx={s.c.x} cy={s.c.y} rx={s.rx} ry={s.ry} stroke="none" transform={`rotate(${(s.rot * 180) / Math.PI} ${s.c.x} ${s.c.y})`} />
              ) : (
                <polygon key={k} points={s.pts.map((q) => `${q.x},${q.y}`).join(' ')} strokeWidth={s.r * 2} />
              ),
            )}
          </g>
        );
      })}
    </svg>
  );
}
