import Icon from './Icon';
import { toggleFavorite, usePrefs } from '../lib/prefs';

/** Saves a pose to Favorites (kept on this device). */
export default function HeartButton({ poseId, title, className = 'h-11 w-11' }: { poseId: string; title: string; className?: string }) {
  const on = usePrefs().favorites.includes(poseId);
  return (
    <button
      type="button"
      onClick={() => toggleFavorite(poseId)}
      aria-pressed={on}
      aria-label={on ? `Remove ${title} from favorites` : `Add ${title} to favorites`}
      className={`grid shrink-0 place-items-center rounded-full transition active:scale-90 ${className} ${on ? 'bg-bubble text-ink' : 'bg-ink/10 text-ink/70'}`}
    >
      <Icon name="heart" className="h-5 w-5" filled={on} />
    </button>
  );
}
