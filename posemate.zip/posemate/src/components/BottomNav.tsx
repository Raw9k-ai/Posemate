import Icon, { type IconName } from './Icon';
import { go } from '../lib/route';

type Tab = 'home' | 'create' | 'gallery';

const ITEMS: { key: Tab | 'camera'; label: string; icon: IconName; to: string }[] = [
  { key: 'home', label: 'Home', icon: 'home', to: '' },
  { key: 'camera', label: 'Camera', icon: 'camera', to: 'camera' },
  { key: 'create', label: 'Make a pose', icon: 'plus', to: 'create' },
  { key: 'gallery', label: 'My photos', icon: 'gallery', to: 'gallery' },
];

/** Thumb-reach navigation for every screen except the camera. */
export default function BottomNav({ active }: { active: Tab }) {
  return (
    <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-20 border-t border-ink/10 bg-paper/95 pb-[env(safe-area-inset-bottom)] backdrop-blur">
      <ul className="mx-auto grid max-w-3xl grid-cols-4">
        {ITEMS.map((it) => {
          const on = it.key === active;
          return (
            <li key={it.key}>
              <button
                onClick={() => go(it.to)}
                aria-current={on ? 'page' : undefined}
                className={`flex w-full flex-col items-center gap-0.5 pb-2 pt-2 text-[11px] font-bold leading-tight ${on ? 'text-ink' : 'text-ink/55'}`}
              >
                <span className={`grid h-8 w-14 place-items-center rounded-full transition ${on ? 'bg-ink text-white' : ''}`}>
                  <Icon name={it.icon} className="h-5 w-5" />
                </span>
                {it.label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
