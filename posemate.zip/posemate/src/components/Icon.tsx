const PATHS = {
  back: 'M15 18l-6-6 6-6',
  close: 'M6 6l12 12M18 6L6 18',
  flip: 'M17 3l4 4-4 4M21 7H8a4 4 0 00-4 4M7 21l-4-4 4-4M3 17h13a4 4 0 004-4',
  skeleton: 'M12 3.5a2 2 0 110 4 2 2 0 010-4zM12 8v6M6.5 10.5h11M9 21l3-7 3 7',
  guide: 'M12 3v3M12 18v3M3 12h3M18 12h3M12 8a4 4 0 100 8 4 4 0 000-8z',
  timer: 'M12 8v5l3 2M12 4a8 8 0 100 16 8 8 0 000-16zM9 2h6',
  gallery: 'M4 5h16v14H4zM4 16l4-4 4 4 3-3 5 5M9 9.5h.01',
  download: 'M12 4v11M7 11l5 5 5-5M5 20h14',
  share: 'M12 15V4M8 8l4-4 4 4M5 13v6h14v-6',
  trash: 'M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13',
  info: 'M12 11v6M12 7.5h.01M12 3a9 9 0 100 18 9 9 0 000-18z',
  check: 'M5 12l5 5 9-10',
  retake: 'M3 12a9 9 0 109-9H8M8 3L5 6l3 3',
  poses: 'M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5',
  camera: 'M4 8h3l2-3h6l2 3h3v11H4zM12 10a3.5 3.5 0 100 7 3.5 3.5 0 000-7z',
  shield: 'M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6l7-3z',
  plus: 'M12 5v14M5 12h14',
  layers: 'M4 7h16M4 12h16M4 17h16',
} as const;

export type IconName = keyof typeof PATHS;

export default function Icon({ name, className = 'h-6 w-6' }: { name: IconName; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={PATHS[name]} />
    </svg>
  );
}
