import type { ReactNode } from 'react';
import Icon from './Icon';
import { back } from '../lib/route';

export default function Header({ title, sub, fallback = '', right }: { title: string; sub?: string; fallback?: string; right?: ReactNode }) {
  return (
    <header className="sticky top-0 z-10 flex items-center gap-3 bg-paper/90 px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))] backdrop-blur">
      <button onClick={() => back(fallback)} aria-label="Go back" className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-ink/10 transition active:scale-95">
        <Icon name="back" />
      </button>
      <div className="min-w-0 flex-1">
        <h1 className="truncate text-2xl font-black leading-tight tracking-tight">{title}</h1>
        {sub && <p className="truncate text-sm text-ink/60">{sub}</p>}
      </div>
      {right}
    </header>
  );
}
