import { removeCustomPose } from '../data/custom';
import type { Pose } from '../data/poses';
import { go } from '../lib/route';
import Corners from './Corners';
import HeartButton from './HeartButton';
import Icon from './Icon';
import PoseArt from './PoseArt';

/** One pose on a list screen: art, first step, favorite, and the way into the camera. */
export default function PoseCard({ pose: p, bg }: { pose: Pose; bg: string }) {
  return (
    <>
      <div className={`relative overflow-hidden rounded-[2rem] ${bg}`}>
        <Corners />
        <PoseArt figures={p.figures} outlines={p.outlines} details={p.details} className="mx-auto h-60 w-full max-w-[15rem] py-5" />
      </div>
      <div className="px-1 pt-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="text-xl font-black leading-tight tracking-tight">{p.title}</h2>
            <p className="mt-0.5 leading-snug text-ink/70">{p.steps[0]}</p>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {p.custom && <span className="rounded-full bg-volt px-2.5 py-0.5 text-xs font-bold">Yours</span>}
            <HeartButton poseId={p.id} title={p.title} />
          </div>
        </div>
        <button onClick={() => go('camera/' + p.id)} className="btn-primary mt-3 w-full">
          <Icon name="camera" className="h-5 w-5" /> Try this pose
        </button>
        <details className="group mt-1">
          <summary className="flex cursor-pointer items-center gap-1 py-2.5 text-sm font-bold text-ink/70">
            How to pose
            <Icon name="chevron" className="h-4 w-4 rotate-90 transition group-open:-rotate-90" />
          </summary>
          <ol className="list-decimal space-y-1 pl-5 leading-snug marker:font-bold">
            {p.steps.map((st) => <li key={st}>{st}</li>)}
          </ol>
          {p.tip && <p className="mt-3 text-sm text-ink/70"><b>Tip:</b> {p.tip}</p>}
          {p.custom && (
            <button
              onClick={() => window.confirm('Delete this pose from this device?') && removeCustomPose(p.id)}
              className="mt-3 inline-flex items-center gap-1.5 py-2 text-sm font-bold text-rose-700"
            >
              <Icon name="trash" className="h-4 w-4" /> Delete this pose
            </button>
          )}
        </details>
      </div>
    </>
  );
}
