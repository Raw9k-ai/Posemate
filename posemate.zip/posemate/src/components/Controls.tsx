import type { ReactNode } from 'react';

/** Small shared form controls so every screen looks and behaves the same. */

export function Switch({
  checked, onChange, label, disabled,
}: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative h-8 w-14 shrink-0 rounded-full transition disabled:opacity-40 ${checked ? 'bg-cobalt' : 'bg-ink/20'}`}
    >
      <span className={`absolute top-1 h-6 w-6 rounded-full bg-white transition-all ${checked ? 'left-7' : 'left-1'}`} />
    </button>
  );
}

export function Segmented<T extends string | number>({
  value, options, onChange, label,
}: { value: T; options: readonly (readonly [string, T])[]; onChange: (v: T) => void; label: string }) {
  return (
    <div role="group" aria-label={label} className="flex gap-1 rounded-full bg-ink/10 p-1">
      {options.map(([text, v]) => (
        <button
          key={text}
          type="button"
          onClick={() => onChange(v)}
          aria-pressed={value === v}
          className={`flex-1 rounded-full px-2 py-2 text-sm font-bold transition ${value === v ? 'bg-ink text-white' : 'text-ink/80'}`}
        >
          {text}
        </button>
      ))}
    </div>
  );
}

/** A label (and optional hint) on the left, a control on the right. */
export function Row({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="min-w-0">
        <p className="font-bold">{label}</p>
        {hint && <p className="text-sm text-ink/60">{hint}</p>}
      </div>
      {children}
    </div>
  );
}
