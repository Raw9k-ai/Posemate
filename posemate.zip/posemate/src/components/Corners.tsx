/**
 * Four viewfinder corner marks. They frame the pose art the same way the camera
 * frames you, so "frame yourself" is the visual idea of the whole app.
 */
export default function Corners({ className = 'border-ink/40', inset = 'inset-3' }: { className?: string; inset?: string }) {
  const base = `absolute h-5 w-5 ${className}`;
  return (
    <div aria-hidden="true" className={`pointer-events-none absolute ${inset}`}>
      <span className={`${base} left-0 top-0 rounded-tl-lg border-l-[3px] border-t-[3px]`} />
      <span className={`${base} right-0 top-0 rounded-tr-lg border-r-[3px] border-t-[3px]`} />
      <span className={`${base} bottom-0 left-0 rounded-bl-lg border-b-[3px] border-l-[3px]`} />
      <span className={`${base} bottom-0 right-0 rounded-br-lg border-b-[3px] border-r-[3px]`} />
    </div>
  );
}
