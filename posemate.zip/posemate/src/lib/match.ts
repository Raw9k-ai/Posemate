import type { Figure, JointName } from '../data/poses';
import type { Person } from './draw';

const SEGS: [JointName, JointName][] = [
  ['lSh', 'lEl'], ['lEl', 'lWr'], ['rSh', 'rEl'], ['rEl', 'rWr'],
  ['lHip', 'lKn'], ['lKn', 'lAn'], ['rHip', 'rKn'], ['rKn', 'rAn'],
];

/**
 * Compares the direction of each visible limb segment with the reference pose.
 * 0 = every limb 60 degrees or more off, 1 = identical. Returns null when too
 * few limbs are visible to judge. This is a 2D approximation of the pose.
 */
export function matchScore(p: Person, ref: Figure, vw: number, vh: number): number | null {
  let sum = 0;
  let weight = 0;
  let used = 0;
  for (const [a, b] of SEGS) {
    if (p[a].v < 0.5 || p[b].v < 0.5) continue;
    const rdx = ref[b][0] - ref[a][0];
    const rdy = ref[b][1] - ref[a][1];
    const rl = Math.hypot(rdx, rdy);
    if (rl < 0.06) continue; // too foreshortened to judge
    const dx = (p[b].x - p[a].x) * vw; // normalised -> pixels so angles are true
    const dy = (p[b].y - p[a].y) * vh;
    if (Math.hypot(dx, dy) < 1e-3) continue;
    let d = Math.abs(Math.atan2(dy, dx) - Math.atan2(rdy, rdx));
    if (d > Math.PI) d = 2 * Math.PI - d;
    sum += Math.max(0, 1 - d / (Math.PI / 3)) * rl;
    weight += rl;
    used++;
  }
  return used < 4 ? null : sum / weight;
}

export function matchLabel(score: number): string {
  if (score >= 0.85) return 'Nailed it';
  if (score >= 0.7) return 'Very close';
  if (score >= 0.5) return 'Getting there';
  return 'Adjust your pose';
}
