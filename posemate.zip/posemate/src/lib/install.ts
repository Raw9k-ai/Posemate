import { useSyncExternalStore } from 'react';

// "Install app" support. Chrome and Brave on Android fire `beforeinstallprompt` when the site
// can be installed; we keep the event and show our own button instead of the browser's banner.
interface InstallEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

let deferred: InstallEvent | null = null;
const subs = new Set<() => void>();
const notify = () => subs.forEach((f) => f());

if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferred = e as InstallEvent;
    notify();
  });
  window.addEventListener('appinstalled', () => {
    deferred = null;
    notify();
  });
}

export function useInstall() {
  const canInstall = useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => deferred !== null,
  );
  const install = async () => {
    const e = deferred;
    if (!e) return;
    deferred = null; // an install prompt can only be used once
    notify();
    await e.prompt();
    await e.userChoice.catch(() => undefined);
  };
  return { canInstall, install };
}

/** True when the app is running from the home screen rather than a browser tab. */
export const isInstalled = () =>
  window.matchMedia('(display-mode: standalone)').matches ||
  (navigator as Navigator & { standalone?: boolean }).standalone === true;
