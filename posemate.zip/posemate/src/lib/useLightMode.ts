import { useEffect } from 'react';
import { isLowEndDevice, lightModeOn } from './perf';
import { usePrefs } from './prefs';

const LOW_END = isLowEndDevice(); // measured once; the phone does not change while the app is open

/** True when light mode is on (Performance setting, or Auto on a slow phone). */
export function useLightMode(): boolean {
  return lightModeOn(usePrefs().perf, LOW_END);
}

/** Mirrors light mode onto <html data-perf="light"> so the style sheet can drop blur and animations. */
export function useApplyLightMode() {
  const light = useLightMode();
  useEffect(() => {
    const el = document.documentElement;
    if (light) el.dataset.perf = 'light';
    else delete el.dataset.perf;
  }, [light]);
}

export const deviceLooksLowEnd = LOW_END;
