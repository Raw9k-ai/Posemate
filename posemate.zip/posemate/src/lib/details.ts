import type { Stroke } from '../data/poses';
import type { Grid } from './outline';
import { bilateral, cannyMasked, edgeStrokes, erode, sobel } from './vision';

// Inner detail lines: hands on hips, folded arms, clothing folds. These sit inside
// the silhouette, so a plain outline would lose them.

export interface EdgeInput {
  mag: Float32Array;
  dir: Uint8Array;
  gw: number;
  gh: number;
  inner: (Uint8Array | null)[]; // per person: eroded mask, keeps edges off the outer boundary
}

/** Smooths the photo with a bilateral filter, then measures gradients. Done once per photo. */
export function prepareEdgeInput(src: HTMLCanvasElement, grids: (Grid | null)[]): EdgeInput | null {
  const ref = grids.find((g): g is Grid => g !== null);
  if (!ref) return null;
  const { gw, gh } = ref;
  const c = document.createElement('canvas');
  c.width = gw;
  c.height = gh;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  if (!ctx) return null;
  ctx.drawImage(src, 0, 0, gw, gh);
  const d = ctx.getImageData(0, 0, gw, gh).data;
  let gray: Float32Array = new Float32Array(gw * gh);
  for (let i = 0; i < gray.length; i++) gray[i] = 0.299 * d[4 * i] + 0.587 * d[4 * i + 1] + 0.114 * d[4 * i + 2];
  gray = bilateral(bilateral(gray, gw, gh, 3, 2, 24), gw, gh, 3, 2, 24);
  const { mag, dir } = sobel(gray, gw, gh);
  const inner = grids.map((g) => (g ? erode(g.bin, gw, gh, 3) : null));
  return { mag, dir, gw, gh, inner };
}

export type DetailLevel = 0 | 1 | 2 | 3; // off, low, medium, high
// `floor` is the weakest edge (Sobel units, roughly 4x the brightness step) we will
// ever keep, so flat clothing and skin texture produce no lines even when the
// percentile would otherwise pick the "strongest" noise.
const LEVELS = {
  1: { percentile: 94, minPixels: 12, floor: 80 },
  2: { percentile: 89, minPixels: 9, floor: 60 },
  3: { percentile: 82, minPixels: 7, floor: 40 },
} as const;

/** Canny edges inside each person, as simplified polylines normalised to the photo. */
export function detailStrokes(e: EdgeInput, level: DetailLevel): (Stroke[] | null)[] {
  if (level === 0) return e.inner.map(() => null);
  const { percentile, minPixels, floor } = LEVELS[level];
  return e.inner.map((inner) => {
    if (!inner) return null;
    const vals: number[] = [];
    for (let i = 0; i < inner.length; i++) if (inner[i]) vals.push(e.mag[i]);
    if (vals.length < 50) return null;
    vals.sort((a, b) => a - b);
    const hi = Math.max(floor, vals[Math.min(vals.length - 1, Math.floor((vals.length * percentile) / 100))]);
    const edges = cannyMasked(e.mag, e.dir, e.gw, e.gh, inner, hi, hi * 0.4);
    return edgeStrokes(edges, e.gw, e.gh, minPixels, 0.9).map((poly) =>
      poly.map(([x, y]) => [Math.round((x / e.gw) * 1e4) / 1e4, Math.round((y / e.gh) * 1e4) / 1e4] as [number, number]),
    );
  });
}
