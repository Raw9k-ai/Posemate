import { useSyncExternalStore } from 'react';
import { isAccuracy, type Accuracy } from './accuracy';

// Small settings store kept in this browser's localStorage. Nothing is uploaded.
const KEY = 'posemate:prefs:v1';

export interface Prefs {
  favorites: string[]; // pose ids
  sound: boolean; // timer ticks and shutter click
  autoSnap: boolean; // take the photo when a solo pose is matched
  keepAwake: boolean; // keep the screen on while the camera is open
  saver: 'off' | 'auto' | 'on'; // battery saver: slower detection to use less power
  lightTips: boolean; // warn about dark, too bright or backlit scenes
  poseTips: boolean; // short advice on the camera such as "Lift your left arm"
  accuracy: Accuracy; // which pose model to run: lite (fast), full, heavy (most accurate)
  levelLine: boolean; // a line that shows how the phone is tilted
}

const DEFAULTS: Prefs = { favorites: [], sound: true, autoSnap: false, keepAwake: true, saver: 'auto', lightTips: true, poseTips: true, accuracy: 'lite', levelLine: true };

/** Turns whatever is stored into valid settings; unknown or corrupt values fall back to the defaults. */
export function parsePrefs(raw: string | null): Prefs {
  try {
    if (!raw) return { ...DEFAULTS, favorites: [] };
    const p = JSON.parse(raw) as Partial<Prefs>;
    return {
      favorites: Array.isArray(p.favorites) ? p.favorites.filter((x): x is string => typeof x === 'string') : [],
      sound: p.sound !== false,
      autoSnap: p.autoSnap === true,
      keepAwake: p.keepAwake !== false,
      saver: p.saver === 'off' || p.saver === 'on' ? p.saver : 'auto',
      lightTips: p.lightTips !== false,
      poseTips: p.poseTips !== false,
      accuracy: isAccuracy(p.accuracy) ? p.accuracy : 'lite',
      levelLine: p.levelLine !== false,
    };
  } catch {
    return { ...DEFAULTS, favorites: [] }; // corrupt: fall back to defaults
  }
}

function load(): Prefs {
  try {
    return parsePrefs(localStorage.getItem(KEY));
  } catch {
    return { ...DEFAULTS, favorites: [] }; // storage blocked
  }
}

let state: Prefs = load();
const subs = new Set<() => void>();

function commit(next: Prefs) {
  state = next; // a new object each time, so React sees the change
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* private mode or full: the change still applies until the page closes */
  }
  subs.forEach((f) => f());
}

export function usePrefs(): Prefs {
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => state,
  );
}

export const setPref = <K extends keyof Omit<Prefs, 'favorites'>>(key: K, value: Prefs[K]) =>
  commit({ ...state, [key]: value });

export const toggleFavorite = (id: string) =>
  commit({
    ...state,
    favorites: state.favorites.includes(id) ? state.favorites.filter((x) => x !== id) : [id, ...state.favorites],
  });

/** Back to a fresh install: no favorites, default settings, and the saved entry removed. */
export function resetPrefs() {
  commit({ ...DEFAULTS, favorites: [] });
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* storage blocked: nothing was saved anyway */
  }
}
