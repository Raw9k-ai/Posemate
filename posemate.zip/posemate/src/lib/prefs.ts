import { useSyncExternalStore } from 'react';
import { isAccuracy, type Accuracy } from './accuracy';
import type { PerfMode } from './perf';

// Small settings store kept in this browser's localStorage. Nothing is uploaded.
const KEY = 'posemate:prefs:v1';

export interface Prefs {
  favorites: string[]; // pose ids
  recent: string[]; // pose ids opened on the camera, newest first (at most RECENT_MAX)
  sound: boolean; // timer ticks and shutter click
  autoSnap: boolean; // take the photo when a solo pose is matched
  keepAwake: boolean; // keep the screen on while the camera is open
  saver: 'off' | 'auto' | 'on'; // battery saver: slower detection to use less power
  lightTips: boolean; // warn about dark, too bright or backlit scenes
  poseTips: boolean; // short advice on the camera such as "Lift your left arm"
  accuracy: Accuracy; // which pose model to run: lite (fast), full, heavy (most accurate)
  levelLine: boolean; // a line that shows how the phone is tilted
  perf: PerfMode; // auto: light mode on slow phones; light: always; full: never
  ghostLevel: 0 | 1 | 2 | 3; // remembered camera options
  showSkeleton: boolean;
  showDetail: boolean;
  timer: 0 | 3 | 5 | 10;
  follow: boolean; // the guide fits itself to your size and position
  guideMove: boolean; // one finger moves the guide, two resize it
  lightDebug: boolean; // show the lighting numbers on the camera, for testing
  burst: boolean; // each shutter press takes a short burst and you pick the best frame
}

export const RECENT_MAX = 6;

const DEFAULTS: Prefs = { favorites: [], recent: [], perf: 'auto', ghostLevel: 2, showSkeleton: true, showDetail: true, timer: 0, follow: false, guideMove: true, sound: true, autoSnap: false, keepAwake: true, saver: 'auto', lightTips: true, poseTips: true, accuracy: 'lite', levelLine: true, burst: false, lightDebug: false };

/** Turns whatever is stored into valid settings; unknown or corrupt values fall back to the defaults. */
export function parsePrefs(raw: string | null): Prefs {
  try {
    if (!raw) return { ...DEFAULTS, favorites: [], recent: [] };
    const p = JSON.parse(raw) as Partial<Prefs>;
    return {
      favorites: Array.isArray(p.favorites) ? p.favorites.filter((x): x is string => typeof x === 'string') : [],
      sound: p.sound !== false,
      autoSnap: p.autoSnap === true,
      keepAwake: p.keepAwake !== false,
      saver: p.saver === 'off' || p.saver === 'on' ? p.saver : 'auto',
      lightTips: p.lightTips !== false,
      poseTips: p.poseTips !== false,
      accuracy: isAccuracy(p.accuracy) ? p.accuracy : 'lite',
      levelLine: p.levelLine !== false,
      burst: p.burst === true,
      lightDebug: p.lightDebug === true,
      follow: p.follow === true,
      guideMove: p.guideMove !== false,
      recent: Array.isArray(p.recent) ? p.recent.filter((x): x is string => typeof x === 'string').slice(0, RECENT_MAX) : [],
      perf: p.perf === 'light' || p.perf === 'full' ? p.perf : 'auto',
      ghostLevel: p.ghostLevel === 0 || p.ghostLevel === 1 || p.ghostLevel === 3 ? p.ghostLevel : 2,
      showSkeleton: p.showSkeleton !== false,
      showDetail: p.showDetail !== false,
      timer: p.timer === 3 || p.timer === 5 || p.timer === 10 ? p.timer : 0,
    };
  } catch {
    return { ...DEFAULTS, favorites: [], recent: [] }; // corrupt: fall back to defaults
  }
}

function load(): Prefs {
  try {
    return parsePrefs(localStorage.getItem(KEY));
  } catch {
    return { ...DEFAULTS, favorites: [], recent: [] }; // storage blocked
  }
}

let state: Prefs = load();
const subs = new Set<() => void>();

function commit(next: Prefs) {
  state = next; // a new object each time, so React sees the change
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* private mode or full: the change still applies until the page closes */
  }
  subs.forEach((f) => f());
}

export function usePrefs(): Prefs {
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => state,
  );
}

export const setPref = <K extends keyof Omit<Prefs, 'favorites' | 'recent'>>(key: K, value: Prefs[K]) =>
  commit({ ...state, [key]: value });

export const toggleFavorite = (id: string) =>
  commit({
    ...state,
    favorites: state.favorites.includes(id) ? state.favorites.filter((x) => x !== id) : [id, ...state.favorites],
  });

/** Back to a fresh install: no favorites, default settings, and the saved entry removed. */
export function resetPrefs() {
  commit({ ...DEFAULTS, favorites: [] });
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* storage blocked: nothing was saved anyway */
  }
}

/** Remember a pose as just used (moves it to the front; keeps the newest RECENT_MAX). */
export const pushRecent = (id: string) => {
  if (state.recent[0] === id) return;
  commit({ ...state, recent: [id, ...state.recent.filter((x) => x !== id)].slice(0, RECENT_MAX) });
};
