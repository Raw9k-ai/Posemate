import { useSyncExternalStore } from 'react';

// Small settings store kept in this browser's localStorage. Nothing is uploaded.
const KEY = 'posemate:prefs:v1';

export interface Prefs {
  favorites: string[]; // pose ids
  sound: boolean; // timer ticks and shutter click
  autoSnap: boolean; // take the photo when a solo pose is matched
  keepAwake: boolean; // keep the screen on while the camera is open
}

const DEFAULTS: Prefs = { favorites: [], sound: true, autoSnap: false, keepAwake: true };

function load(): Prefs {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULTS };
    const p = JSON.parse(raw) as Partial<Prefs>;
    return {
      favorites: Array.isArray(p.favorites) ? p.favorites.filter((x): x is string => typeof x === 'string') : [],
      sound: p.sound !== false,
      autoSnap: p.autoSnap === true,
      keepAwake: p.keepAwake !== false,
    };
  } catch {
    return { ...DEFAULTS }; // storage blocked or corrupt: fall back to defaults
  }
}

let state: Prefs = load();
const subs = new Set<() => void>();

function commit(next: Prefs) {
  state = next; // a new object each time, so React sees the change
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* private mode or full: the change still applies until the page closes */
  }
  subs.forEach((f) => f());
}

export function usePrefs(): Prefs {
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => state,
  );
}

export const setPref = <K extends keyof Omit<Prefs, 'favorites'>>(key: K, value: Prefs[K]) =>
  commit({ ...state, [key]: value });

export const toggleFavorite = (id: string) =>
  commit({
    ...state,
    favorites: state.favorites.includes(id) ? state.favorites.filter((x) => x !== id) : [id, ...state.favorites],
  });
