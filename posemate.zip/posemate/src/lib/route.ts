import { useEffect, useState } from 'react';

// Tiny hash router: works on any static host with no rewrite rules, and the
// Android back button behaves naturally.
const read = () =>
  window.location.hash.replace(/^#\/?/, '').split('/').filter(Boolean).map(decodeURIComponent);

export function useRoute(): string[] {
  const [parts, setParts] = useState<string[]>(read);
  useEffect(() => {
    const on = () => setParts(read());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return parts;
}

export const go = (path: string) => {
  window.location.hash = '/' + path;
};
export const replace = (path: string) => {
  window.location.replace('#/' + path);
};
export const back = (fallback = '') => {
  if (window.history.length > 1) window.history.back();
  else go(fallback);
};
