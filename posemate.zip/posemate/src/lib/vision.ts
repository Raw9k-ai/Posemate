// Small, dependency-free image-processing helpers (an on-device stand-in for the
// handful of OpenCV calls we need). All work on flat row-major arrays.

/** Separable box blur with clamped edges. Two passes approximate a Gaussian blur. */
export function boxBlur(src: Float32Array, w: number, h: number, r: number): Float32Array {
  const tmp = new Float32Array(w * h);
  const out = new Float32Array(w * h);
  const k = 2 * r + 1;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let d = -r; d <= r; d++) s += src[y * w + Math.min(w - 1, Math.max(0, x + d))];
      tmp[y * w + x] = s / k;
    }
  }
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let d = -r; d <= r; d++) s += tmp[Math.min(h - 1, Math.max(0, y + d)) * w + x];
      out[y * w + x] = s / k;
    }
  }
  return out;
}

/** 3x3 binary erosion, repeated `n` times. Pixels outside the image count as empty. */
export function erode(bin: Uint8Array, w: number, h: number, n = 1): Uint8Array {
  let cur = bin;
  for (let it = 0; it < n; it++) {
    const out = new Uint8Array(w * h);
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        if (
          cur[i] && cur[i - 1] && cur[i + 1] && cur[i - w] && cur[i + w] &&
          cur[i - w - 1] && cur[i - w + 1] && cur[i + w - 1] && cur[i + w + 1]
        ) out[i] = 1;
      }
    }
    cur = out;
  }
  return cur;
}

/** 3x3 binary dilation, repeated `n` times. */
export function dilate(bin: Uint8Array, w: number, h: number, n = 1): Uint8Array {
  let cur = bin;
  for (let it = 0; it < n; it++) {
    const out = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let on = 0;
        for (let dy = -1; dy <= 1 && !on; dy++) {
          const yy = y + dy;
          if (yy < 0 || yy >= h) continue;
          for (let dx = -1; dx <= 1; dx++) {
            const xx = x + dx;
            if (xx >= 0 && xx < w && cur[yy * w + xx]) {
              on = 1;
              break;
            }
          }
        }
        out[y * w + x] = on;
      }
    }
    cur = out;
  }
  return cur;
}

/** Keeps only the biggest 4-connected blob. */
export function largestComponent(bin: Uint8Array, w: number, h: number): { bin: Uint8Array; area: number } {
  const label = new Int32Array(w * h);
  const stack: number[] = [];
  let best = 0;
  let bestId = 0;
  let id = 0;
  for (let i = 0; i < w * h; i++) {
    if (!bin[i] || label[i]) continue;
    id++;
    let area = 0;
    label[i] = id;
    stack.push(i);
    while (stack.length) {
      const c = stack.pop()!;
      area++;
      const x = c % w;
      const y = (c / w) | 0;
      if (x > 0 && bin[c - 1] && !label[c - 1]) { label[c - 1] = id; stack.push(c - 1); }
      if (x < w - 1 && bin[c + 1] && !label[c + 1]) { label[c + 1] = id; stack.push(c + 1); }
      if (y > 0 && bin[c - w] && !label[c - w]) { label[c - w] = id; stack.push(c - w); }
      if (y < h - 1 && bin[c + w] && !label[c + w]) { label[c + w] = id; stack.push(c + w); }
    }
    if (area > best) {
      best = area;
      bestId = id;
    }
  }
  const out = new Uint8Array(w * h);
  if (bestId) for (let i = 0; i < out.length; i++) out[i] = label[i] === bestId ? 1 : 0;
  return { bin: out, area: best };
}

/**
 * Edge-preserving smoothing (bilateral filter) on 0..255 values: flattens skin and
 * fabric texture but keeps strong structural boundaries.
 */
export function bilateral(src: Float32Array, w: number, h: number, radius = 3, sigmaS = 2, sigmaR = 24): Float32Array {
  const size = 2 * radius + 1;
  const sw = new Float32Array(size * size);
  for (let dy = -radius; dy <= radius; dy++) {
    for (let dx = -radius; dx <= radius; dx++) {
      sw[(dy + radius) * size + dx + radius] = Math.exp(-(dx * dx + dy * dy) / (2 * sigmaS * sigmaS));
    }
  }
  const rw = new Float32Array(256);
  for (let d = 0; d < 256; d++) rw[d] = Math.exp(-(d * d) / (2 * sigmaR * sigmaR));
  const out = new Float32Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const c = src[y * w + x];
      let sum = 0;
      let wsum = 0;
      for (let dy = -radius; dy <= radius; dy++) {
        const yy = Math.min(h - 1, Math.max(0, y + dy));
        for (let dx = -radius; dx <= radius; dx++) {
          const xx = Math.min(w - 1, Math.max(0, x + dx));
          const v = src[yy * w + xx];
          const wt = sw[(dy + radius) * size + dx + radius] * rw[Math.min(255, Math.abs(v - c) | 0)];
          sum += wt * v;
          wsum += wt;
        }
      }
      out[y * w + x] = sum / wsum;
    }
  }
  return out;
}

/** Sobel gradient magnitude and direction (0: horizontal, 1: 45deg, 2: vertical, 3: 135deg). */
export function sobel(g: Float32Array, w: number, h: number): { mag: Float32Array; dir: Uint8Array } {
  const mag = new Float32Array(w * h);
  const dir = new Uint8Array(w * h);
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const gx = g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1] - (g[i - w - 1] + 2 * g[i - 1] + g[i + w - 1]);
      const gy = g[i + w - 1] + 2 * g[i + w] + g[i + w + 1] - (g[i - w - 1] + 2 * g[i - w] + g[i - w + 1]);
      mag[i] = Math.hypot(gx, gy);
      let a = (Math.atan2(gy, gx) * 180) / Math.PI;
      if (a < 0) a += 180;
      dir[i] = a < 22.5 || a >= 157.5 ? 0 : a < 67.5 ? 1 : a < 112.5 ? 2 : 3;
    }
  }
  return { mag, dir };
}

const NMS: [number, number][] = [[1, 0], [1, 1], [0, 1], [-1, 1]];

/**
 * Canny non-maximum suppression plus hysteresis, restricted to a mask. `hi` seeds
 * strong edges, `lo` lets them grow along weaker connected edge pixels.
 */
export function cannyMasked(
  mag: Float32Array, dir: Uint8Array, w: number, h: number, mask: Uint8Array, hi: number, lo: number,
): Uint8Array {
  const m = new Float32Array(w * h);
  for (let i = 0; i < m.length; i++) m[i] = mask[i] ? mag[i] : 0;
  const thin = new Float32Array(w * h);
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const v = m[i];
      if (v < lo) continue;
      const [dx, dy] = NMS[dir[i]];
      if (v >= m[i + dy * w + dx] && v >= m[i - dy * w - dx]) thin[i] = v;
    }
  }
  const out = new Uint8Array(w * h);
  const stack: number[] = [];
  for (let i = 0; i < thin.length; i++) {
    if (thin[i] >= hi) {
      out[i] = 1;
      stack.push(i);
    }
  }
  while (stack.length) {
    const c = stack.pop()!;
    const x = c % w;
    const y = (c / w) | 0;
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        const xx = x + dx;
        const yy = y + dy;
        if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
        const n = yy * w + xx;
        if (!out[n] && thin[n] >= lo) {
          out[n] = 1;
          stack.push(n);
        }
      }
    }
  }
  return out;
}

type P = [number, number];

/** Ramer-Douglas-Peucker polyline simplification. */
export function rdp(p: P[], eps: number): P[] {
  if (p.length < 3) return p;
  const [x1, y1] = p[0];
  const [x2, y2] = p[p.length - 1];
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  let maxD = 0;
  let idx = 0;
  for (let i = 1; i < p.length - 1; i++) {
    const d = len === 0
      ? Math.hypot(p[i][0] - x1, p[i][1] - y1)
      : Math.abs(dy * p[i][0] - dx * p[i][1] + x2 * y1 - y2 * x1) / len;
    if (d > maxD) {
      maxD = d;
      idx = i;
    }
  }
  if (maxD > eps) {
    const l = rdp(p.slice(0, idx + 1), eps);
    const r = rdp(p.slice(idx), eps);
    return l.slice(0, -1).concat(r);
  }
  return [p[0], p[p.length - 1]];
}

/** Corner-cutting smoothing for a closed polygon. */
export function chaikin(p: P[]): P[] {
  const out: P[] = [];
  for (let i = 0; i < p.length; i++) {
    const a = p[i];
    const b = p[(i + 1) % p.length];
    out.push([0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1]]);
    out.push([0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]]);
  }
  return out;
}

const WALK: P[] = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]];

/**
 * Walks 1px-wide edge pixels into simplified polylines (pixel-centre coordinates).
 * Drops chains shorter than `minPixels` and keeps the `maxStrokes` longest.
 */
export function edgeStrokes(edges: Uint8Array, w: number, h: number, minPixels: number, eps: number, maxStrokes = 80): P[][] {
  const visited = new Uint8Array(w * h);
  const degree = (i: number) => {
    const x = i % w;
    const y = (i / w) | 0;
    let n = 0;
    for (const [dx, dy] of WALK) {
      const xx = x + dx;
      const yy = y + dy;
      if (xx >= 0 && yy >= 0 && xx < w && yy < h && edges[yy * w + xx]) n++;
    }
    return n;
  };
  const trace = (s: number): number[] => {
    const pts = [s];
    visited[s] = 1;
    let cur = s;
    for (;;) {
      let next = -1;
      const x = cur % w;
      const y = (cur / w) | 0;
      for (const [dx, dy] of WALK) {
        const xx = x + dx;
        const yy = y + dy;
        if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
        const n = yy * w + xx;
        if (edges[n] && !visited[n]) {
          next = n;
          break;
        }
      }
      if (next < 0) break;
      visited[next] = 1;
      pts.push(next);
      cur = next;
    }
    return pts;
  };

  const found: { len: number; poly: P[] }[] = [];
  const record = (pix: number[]) => {
    if (pix.length < minPixels) return;
    const poly = rdp(pix.map((i) => [(i % w) + 0.5, ((i / w) | 0) + 0.5] as P), eps);
    if (poly.length >= 2) found.push({ len: pix.length, poly });
  };
  for (let i = 0; i < edges.length; i++) if (edges[i] && !visited[i] && degree(i) === 1) record(trace(i));
  for (let i = 0; i < edges.length; i++) if (edges[i] && !visited[i]) record(trace(i));

  found.sort((a, b) => b.len - a.len);
  return found.slice(0, maxStrokes).map((f) => f.poly);
}
