import type { Person } from './draw';

// Lighting check for the camera view. Looks at a tiny copy of the frame (64 x 36 pixels) twice a
// second and says when the picture is too dark, too bright, or the person is lit from behind.
// Brightness is judged on the person when one is in view, because a dim room around a well lit
// person, or a bright window behind a well lit person, is not a problem for the photo.
// Numbers are first guesses to tune on real phones.

export type LightIssue = 'dark' | 'bright' | 'backlit';

export interface Box {
  x0: number;
  y0: number;
  x1: number;
  y1: number; // all 0..1 across the frame
}

export interface LightStats {
  mean: number; // average brightness of the whole frame, 0..255
  clipped: number; // share of the frame that is nearly white, 0..1
  subject: number | null; // average brightness inside the person's box
  subjectClipped: number | null; // share of the person's box that is nearly white
  background: number | null; // average brightness outside the box
}

const DARK = 55; // frame average under this is too dark (no person in view)
const DARK_SUBJECT = 45; // person average under this is too dark
const CLIP_LEVEL = 245;
const BRIGHT_FRAME = 0.3; // 30% of the frame blown out (no person in view)
const BRIGHT_SUBJECT = 0.2; // 20% of the person blown out
const BACKLIT_BG_MIN = 110; // background must be properly bright...
const BACKLIT_RATIO = 0.6; // ...person under 60% of it...
const BACKLIT_GAP = 45; // ...and at least this much darker
const MIN_SUBJECT_SHARE = 0.03; // ignore a box smaller than 3% of the frame
const MIN_BACKGROUND_SHARE = 0.2; // and compare to a background of at least 20%
export const LIGHT_HOLD_MS = 1500; // a problem must last this long before it is shown

/** Measure a frame. `rgba` is image data of size w x h; `box` is the person's area, if known. */
export function analyzeLight(rgba: ArrayLike<number>, w: number, h: number, box?: Box | null): LightStats {
  const bx0 = box ? Math.floor(box.x0 * w) : 0;
  const bx1 = box ? Math.ceil(box.x1 * w) : 0;
  const by0 = box ? Math.floor(box.y0 * h) : 0;
  const by1 = box ? Math.ceil(box.y1 * h) : 0;
  let sum = 0, clip = 0;
  let sSum = 0, sN = 0, sClip = 0;
  let bSum = 0, bN = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const l = 0.299 * rgba[i] + 0.587 * rgba[i + 1] + 0.114 * rgba[i + 2];
      sum += l;
      const hot = l >= CLIP_LEVEL;
      if (hot) clip++;
      if (box && x >= bx0 && x < bx1 && y >= by0 && y < by1) {
        sSum += l;
        sN++;
        if (hot) sClip++;
      } else {
        bSum += l;
        bN++;
      }
    }
  }
  const n = w * h;
  const useBox = !!box && sN / n >= MIN_SUBJECT_SHARE;
  return {
    mean: sum / n,
    clipped: clip / n,
    subject: useBox ? sSum / sN : null,
    subjectClipped: useBox ? sClip / sN : null,
    background: useBox && bN / n >= MIN_BACKGROUND_SHARE ? bSum / bN : null,
  };
}

/** What, if anything, is wrong with the light. */
export function lightIssue(s: LightStats): LightIssue | null {
  if (s.subject !== null && s.background !== null && s.background >= BACKLIT_BG_MIN && s.subject <= s.background * BACKLIT_RATIO && s.background - s.subject >= BACKLIT_GAP) {
    return 'backlit';
  }
  if (s.subject !== null) {
    if (s.subject < DARK_SUBJECT) return 'dark';
    if ((s.subjectClipped ?? 0) > BRIGHT_SUBJECT) return 'bright';
    return null;
  }
  if (s.mean < DARK) return 'dark';
  if (s.clipped > BRIGHT_FRAME) return 'bright';
  return null;
}

export const LIGHT_TIPS: Record<LightIssue, string> = {
  dark: 'Too dark. Move toward a light or turn one on.',
  bright: 'Too bright. Step into shade or turn away from the sun.',
  backlit: 'The light is behind you. Turn so it falls on your face.',
};

/** The person's area as a box around head, shoulders and hips (everyone in view combined). */
export function subjectBox(people: Person[]): Box | null {
  let x0 = 1, y0 = 1, x1 = 0, y1 = 0, pts = 0;
  for (const p of people) {
    for (const k of ['nose', 'lSh', 'rSh', 'lHip', 'rHip'] as const) {
      const j = p[k];
      if (j.v < 0.4) continue;
      x0 = Math.min(x0, j.x);
      x1 = Math.max(x1, j.x);
      y0 = Math.min(y0, j.y);
      y1 = Math.max(y1, j.y);
      pts++;
    }
  }
  if (pts < 3) return null;
  const px = (x1 - x0) * 0.15 + 0.03;
  const py = (y1 - y0) * 0.15 + 0.03;
  return { x0: Math.max(0, x0 - px), y0: Math.max(0, y0 - py), x1: Math.min(1, x1 + px), y1: Math.min(1, y1 + py) };
}

/**
 * Stops the tip flickering: a problem must last LIGHT_HOLD_MS before it shows, and must be gone for
 * as long before it hides. Tapping the tip hides it until the problem goes away or changes.
 */
export class LightWatcher {
  private candidate: LightIssue | null = null;
  private since = 0;
  private shown: LightIssue | null = null;
  private dismissed: LightIssue | null = null;

  update(issue: LightIssue | null, now: number): LightIssue | null {
    if (issue !== this.candidate) {
      this.candidate = issue;
      this.since = now;
    }
    if (now - this.since >= LIGHT_HOLD_MS) {
      this.shown = this.candidate;
      if (this.candidate === null) this.dismissed = null; // fixed: allow the tip again next time
    }
    return this.shown !== null && this.shown !== this.dismissed ? this.shown : null;
  }

  dismiss() {
    this.dismissed = this.shown;
  }

  reset() {
    this.candidate = this.shown = this.dismissed = null;
    this.since = 0;
  }
}


/** The numbers the checks use, so a test log can record which settings produced it. */
export const LIGHT_THRESHOLDS = {
  dark: DARK,
  darkSubject: DARK_SUBJECT,
  clipLevel: CLIP_LEVEL,
  brightFrame: BRIGHT_FRAME,
  brightSubject: BRIGHT_SUBJECT,
  backlitBgMin: BACKLIT_BG_MIN,
  backlitRatio: BACKLIT_RATIO,
  backlitGap: BACKLIT_GAP,
  holdMs: LIGHT_HOLD_MS,
} as const;

export interface LightSample {
  t: number; // ms
  stats: LightStats;
  issue: LightIssue | null; // what the check says right now
  shown: LightIssue | null; // what the person is shown (after the hold time)
  people: number;
  note?: string;
}

/**
 * The last few minutes of lighting readings, for tuning on a real phone. Kept in memory only.
 * `toCsv` gives text to paste into a chat, with the thresholds on the first line.
 */
export class LightLog {
  private items: LightSample[] = [];
  private max: number;
  constructor(max = 240) {
    this.max = max;
  }

  get size() {
    return this.items.length;
  }

  add(s: LightSample) {
    this.items.push(s);
    if (this.items.length > this.max) this.items.shift();
  }

  /** Marks the newest reading, for example "tip wrong" or "missed". Returns false if empty. */
  mark(note: string): boolean {
    const last = this.items[this.items.length - 1];
    if (!last) return false;
    last.note = note;
    return true;
  }

  clear() {
    this.items = [];
  }

  toCsv(): string {
    const one = (n: number | null) => (n === null ? '' : (Math.round(n * 10) / 10).toString());
    const pct = (n: number | null) => (n === null ? '' : (Math.round(n * 1000) / 10).toString());
    const t0 = this.items[0]?.t ?? 0;
    const lines = [
      '# thresholds ' + Object.entries(LIGHT_THRESHOLDS).map(([k, v]) => `${k}=${v}`).join(' '),
      'sec,people,mean,clipped_pct,subject,subject_clipped_pct,background,issue,shown,note',
    ];
    for (const s of this.items) {
      lines.push(
        [
          one((s.t - t0) / 1000),
          s.people,
          one(s.stats.mean),
          pct(s.stats.clipped),
          one(s.stats.subject),
          pct(s.stats.subjectClipped),
          one(s.stats.background),
          s.issue ?? '',
          s.shown ?? '',
          (s.note ?? '').replace(/[,\n]/g, ' '),
        ].join(','),
      );
    }
    return lines.join('\n');
  }
}
