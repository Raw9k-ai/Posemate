// On-device body detection with MediaPipe Pose Landmarker.
// The runtime and model are served from this site (see scripts/setup-assets.mjs)
// and frames/photos never leave the browser. The library is loaded on demand so
// the home screen stays light.
import type { PoseLandmarker } from '@mediapipe/tasks-vision';
import { toPerson, type Person } from './draw';

const MODEL_PATH = 'models/pose_landmarker_lite.task';
const WASM_PATH = 'mediapipe/wasm';

const abs = (p: string) => new URL(import.meta.env.BASE_URL + p, document.baseURI).href;

type Mod = typeof import('@mediapipe/tasks-vision');
interface Runtime {
  mod: Mod;
  fileset: Awaited<ReturnType<Mod['FilesetResolver']['forVisionTasks']>>;
  modelUrl: string;
}

let runtime: Promise<Runtime> | null = null;
function prepare(): Promise<Runtime> {
  if (!runtime) {
    runtime = (async () => {
      const modelUrl = abs(MODEL_PATH);
      let res: Response;
      try {
        res = await fetch(modelUrl, { method: 'HEAD' });
      } catch {
        throw new Error('The pose model could not be loaded. Check your connection and reload.');
      }
      const type = res.headers.get('content-type') || '';
      if (!res.ok || type.includes('text/html')) {
        throw new Error('The pose model file is missing. Run "npm run setup:assets" and rebuild.');
      }
      const mod = await import('@mediapipe/tasks-vision');
      const fileset = await mod.FilesetResolver.forVisionTasks(abs(WASM_PATH));
      return { mod, fileset, modelUrl };
    })().catch((e) => {
      runtime = null; // allow a retry
      throw e;
    });
  }
  return runtime;
}

// ---------- live video detection ----------

export interface Detector {
  delegate: 'GPU' | 'CPU';
  detect(source: HTMLCanvasElement): Person[];
  setMaxPeople(n: number): void;
}

let cached: Promise<Detector> | null = null;
export function loadDetector(): Promise<Detector> {
  if (!cached) {
    cached = createLive().catch((e) => {
      cached = null;
      throw e;
    });
  }
  return cached;
}

async function createLive(): Promise<Detector> {
  const { mod, fileset, modelUrl } = await prepare();
  const make = (delegate: 'GPU' | 'CPU') =>
    mod.PoseLandmarker.createFromOptions(fileset, {
      baseOptions: { modelAssetPath: modelUrl, delegate },
      runningMode: 'VIDEO',
      numPoses: 1,
      minPoseDetectionConfidence: 0.5,
      minPosePresenceConfidence: 0.5,
      minTrackingConfidence: 0.5,
    });

  let lm: PoseLandmarker;
  let delegate: 'GPU' | 'CPU' = 'GPU';
  try {
    lm = await make('GPU');
  } catch {
    try {
      lm = await make('CPU');
      delegate = 'CPU';
    } catch {
      throw new Error('Pose detection is not supported in this browser. Try a recent version of Chrome.');
    }
  }

  let lastTs = 0;
  let people = 1;
  return {
    delegate,
    detect(source) {
      const ts = Math.max(performance.now(), lastTs + 1); // timestamps must increase
      lastTs = ts;
      return lm.detectForVideo(source, ts).landmarks.map(toPerson);
    },
    setMaxPeople(n) {
      if (n === people) return;
      people = n;
      void lm.setOptions({ numPoses: n });
    },
  };
}

// ---------- single still photo, with body masks (used by the pose creator) ----------

export interface BodyMask { data: Float32Array; width: number; height: number }
export interface StillResult { persons: Person[]; masks: (BodyMask | null)[] }
export interface StillDetector { detect(source: HTMLCanvasElement): StillResult }

let stillCached: Promise<StillDetector> | null = null;
export function loadStillDetector(): Promise<StillDetector> {
  if (!stillCached) {
    stillCached = createStill().catch((e) => {
      stillCached = null;
      throw e;
    });
  }
  return stillCached;
}

async function createStill(): Promise<StillDetector> {
  const { mod, fileset, modelUrl } = await prepare();
  // CPU is plenty fast for one photo and avoids GPU quirks with segmentation masks.
  const lm = await mod.PoseLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: modelUrl, delegate: 'CPU' },
    runningMode: 'IMAGE',
    numPoses: 5,
    minPoseDetectionConfidence: 0.5,
    minPosePresenceConfidence: 0.5,
    outputSegmentationMasks: true,
  });
  return {
    detect(source) {
      const r = lm.detect(source);
      const masks = r.landmarks.map((_, i): BodyMask | null => {
        const m = r.segmentationMasks?.[i];
        if (!m) return null;
        try {
          return { data: m.getAsFloat32Array().slice(), width: m.width, height: m.height };
        } finally {
          m.close();
        }
      });
      return { persons: r.landmarks.map(toPerson), masks };
    },
  };
}
