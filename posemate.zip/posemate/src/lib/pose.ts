// On-device body detection with MediaPipe Pose Landmarker.
// The runtime and model are served from this site (see scripts/setup-assets.mjs)
// and frames never leave the browser. The library is loaded on demand so the
// home screen stays light.
import type { PoseLandmarker } from '@mediapipe/tasks-vision';
import { toPerson, type Person } from './draw';

const MODEL_PATH = 'models/pose_landmarker_lite.task';
const WASM_PATH = 'mediapipe/wasm';

const abs = (p: string) => new URL(import.meta.env.BASE_URL + p, document.baseURI).href;

export interface Detector {
  delegate: 'GPU' | 'CPU';
  detect(source: HTMLCanvasElement): Person[];
  setMaxPeople(n: number): void;
}

let cached: Promise<Detector> | null = null;
export function loadDetector(): Promise<Detector> {
  if (!cached) {
    cached = create().catch((e) => {
      cached = null; // allow a retry
      throw e;
    });
  }
  return cached;
}

async function create(): Promise<Detector> {
  const modelUrl = abs(MODEL_PATH);

  let res: Response;
  try {
    res = await fetch(modelUrl, { method: 'HEAD' });
  } catch {
    throw new Error('The pose model could not be loaded. Check your connection and reload.');
  }
  const type = res.headers.get('content-type') || '';
  if (!res.ok || type.includes('text/html')) {
    throw new Error('The pose model file is missing. Run "npm run setup:assets" and rebuild.');
  }

  const { FilesetResolver, PoseLandmarker: PL } = await import('@mediapipe/tasks-vision');
  const fileset = await FilesetResolver.forVisionTasks(abs(WASM_PATH));

  const make = (delegate: 'GPU' | 'CPU') =>
    PL.createFromOptions(fileset, {
      baseOptions: { modelAssetPath: modelUrl, delegate },
      runningMode: 'VIDEO',
      numPoses: 1,
      minPoseDetectionConfidence: 0.5,
      minPosePresenceConfidence: 0.5,
      minTrackingConfidence: 0.5,
    });

  let lm: PoseLandmarker;
  let delegate: 'GPU' | 'CPU' = 'GPU';
  try {
    lm = await make('GPU');
  } catch {
    try {
      lm = await make('CPU');
      delegate = 'CPU';
    } catch {
      throw new Error('Pose detection is not supported in this browser. Try a recent version of Chrome.');
    }
  }

  let lastTs = 0;
  let people = 1;
  return {
    delegate,
    detect(source) {
      const ts = Math.max(performance.now(), lastTs + 1); // timestamps must increase
      lastTs = ts;
      const r = lm.detectForVideo(source, ts);
      return r.landmarks.map(toPerson);
    },
    setMaxPeople(n) {
      if (n === people) return;
      people = n;
      void lm.setOptions({ numPoses: n });
    },
  };
}
