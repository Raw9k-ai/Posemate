import type { Grid } from './outline';
import { erode } from './vision';

// Photo ghost: the person's own pixels, cut out with the cleaned body mask, so the
// camera can show a faded copy of the reference photo. Only created when the user
// opts in. The cut-out is a small image stored on this device with the pose.

export interface Cutout {
  blob: Blob; // transparent-background image of one person
  box: [number, number, number, number]; // x0, y0, x1, y1 of the cut-out, normalised to the photo
}

/** Tight box around the person pixels in grid cells, padded and clamped. Null if the mask is empty. */
export function maskBox(bin: Uint8Array, gw: number, gh: number, pad = 2): [number, number, number, number] | null {
  let x0 = gw, y0 = gh, x1 = -1, y1 = -1;
  for (let y = 0; y < gh; y++) {
    for (let x = 0; x < gw; x++) {
      if (!bin[y * gw + x]) continue;
      if (x < x0) x0 = x;
      if (x > x1) x1 = x;
      if (y < y0) y0 = y;
      if (y > y1) y1 = y;
    }
  }
  if (x1 < 0) return null;
  return [Math.max(0, x0 - pad), Math.max(0, y0 - pad), Math.min(gw, x1 + 1 + pad), Math.min(gh, y1 + 1 + pad)];
}

/** One cut-out per person (null where there is no usable mask). Long side is capped to keep storage small. */
export async function makeCutouts(
  source: HTMLCanvasElement,
  grids: (Grid | null)[],
  maxSide = 512,
  quality = 0.85,
): Promise<(Cutout | null)[]> {
  const out: (Cutout | null)[] = [];
  for (const g of grids) {
    const box = g ? maskBox(g.bin, g.gw, g.gh) : null;
    if (!g || !box) {
      out.push(null);
      continue;
    }
    const [x0, y0, x1, y1] = box;
    const sx = source.width / g.gw;
    const sy = source.height / g.gh;
    const sw = (x1 - x0) * sx;
    const sh = (y1 - y0) * sy;
    const k = Math.min(1, maxSide / Math.max(sw, sh));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(sw * k));
    c.height = Math.max(1, Math.round(sh * k));
    const ctx = c.getContext('2d');
    if (!ctx) {
      out.push(null);
      continue;
    }
    ctx.drawImage(source, x0 * sx, y0 * sy, sw, sh, 0, 0, c.width, c.height);

    // Alpha comes from the mask, pulled in by one cell so background colour does not fringe the edge.
    // Scaling the small mask up with smoothing feathers the edge slightly.
    const m = document.createElement('canvas');
    m.width = g.gw;
    m.height = g.gh;
    const mctx = m.getContext('2d');
    if (!mctx) {
      out.push(null);
      continue;
    }
    const inner = erode(g.bin, g.gw, g.gh, 1);
    const img = mctx.createImageData(g.gw, g.gh);
    for (let i = 0; i < inner.length; i++) img.data[4 * i + 3] = inner[i] ? 255 : 0;
    mctx.putImageData(img, 0, 0);
    ctx.globalCompositeOperation = 'destination-in';
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(m, x0, y0, x1 - x0, y1 - y0, 0, 0, c.width, c.height);

    // WebP keeps transparency and is small; browsers without WebP encoding return PNG instead.
    const blob = await new Promise<Blob | null>((res) => c.toBlob(res, 'image/webp', quality));
    out.push(blob ? { blob, box: [x0 / g.gw, y0 / g.gh, x1 / g.gw, y1 / g.gh] } : null);
  }
  return out;
}
