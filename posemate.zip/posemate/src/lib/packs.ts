// Pose packs: the format the batch builder writes and the app will later download.
//   packs/<mode>/poses.json      all poses of that mode (joints, outlines, body-part lines, ghost references)
//   packs/<mode>/ghosts/*.webp   one small cut-out image per person
//   packs/<mode>/manifest.json   every file with its size, so the app can show "8 MB" and a progress bar
// Pure code (no DOM) so it can be tested in Node.
import { MOODS, SCENES, type Figure, type Mode, type Mood, type Outline, type SceneId, type Stroke } from '../data/poses';
import type { ZipEntry } from './zip';

export interface PackGhostRef { file: string; box: [number, number, number, number]; mirrored: boolean }

export interface PackPose {
  id: string;
  title: string;
  mode: Mode;
  scenes: SceneId[];
  moods?: Mood[];
  steps: string[];
  tip: string;
  figures: Figure[];
  outlines?: (Outline | null)[];
  details?: (Stroke[] | null)[];
  ghosts?: (PackGhostRef | null)[];
}

export interface PackFile { v: 1; mode: Mode; poses: PackPose[] }

export interface PackManifest {
  v: 1;
  mode: Mode;
  count: number;
  ghostCount: number;
  totalBytes: number;
  files: { path: string; bytes: number }[]; // relative to packs/<mode>/
}

// ---------- names and ids ----------

export const slug = (s: string): string =>
  s.toLowerCase().replace(/\.[a-z0-9]{2,5}$/, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'pose';

/** "pk-solo-001"; a number is added if the id is already taken. */
export function uniqueId(mode: Mode, fileName: string, used: Set<string>): string {
  const base = `pk-${mode}-${slug(fileName)}`;
  let id = base;
  for (let n = 2; used.has(id); n++) id = `${base}-${n}`;
  used.add(id);
  return id;
}

export function defaultTitle(fileName: string): string {
  const base = fileName.replace(/^.*[\\/]/, '').replace(/\.[a-z0-9]{2,5}$/i, '');
  if (/^\d+$/.test(base)) return `Pose ${base}`;
  const t = base.replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim();
  return t ? t[0].toUpperCase() + t.slice(1) : 'Pose';
}

export const DEFAULT_STEPS = [
  'Stand where the guide fits you',
  'Match your arms and legs to the shape',
  'Relax your face, then take the shot',
];
export const DEFAULT_TIP = 'Take a breath and soften your shoulders before you shoot.';

export function naturalCompare(a: string, b: string): number {
  return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
}

// ---------- CSV (sheet of names, moods, tips) ----------

/** RFC 4180-style parser: quotes, doubled quotes, commas and line breaks inside quotes, BOM, CRLF. */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  const src = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') { cell += '"'; i++; } else quoted = false;
      } else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && src[i + 1] === '\n') i++;
      row.push(cell); cell = '';
      rows.push(row); row = [];
    } else cell += ch;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  return rows.filter((r) => r.some((c) => c.trim() !== ''));
}

export const csvCell = (v: string | number): string => {
  const s = String(v);
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
export const toCsv = (rows: (string | number)[][]): string => rows.map((r) => r.map(csvCell).join(',')).join('\r\n') + '\r\n';

export interface SheetRow { name?: string; moods?: Mood[]; tip?: string; steps?: string[] }

export const fileKey = (name: string): string => name.replace(/^.*[\\/]/, '').replace(/\.[a-z0-9]{2,5}$/i, '').trim().toLowerCase();

/**
 * Columns (any order, header row required): file, name, mood, tip, steps.
 * `mood` may hold several separated by space, comma-free "/" or ";". `steps` are separated by "|".
 */
export function parseSheet(text: string): { rows: Map<string, SheetRow>; warnings: string[] } {
  const table = parseCsv(text);
  const warnings: string[] = [];
  const rows = new Map<string, SheetRow>();
  if (table.length === 0) return { rows, warnings: ['The sheet is empty.'] };
  const head = table[0].map((h) => h.trim().toLowerCase());
  const col = (n: string) => head.indexOf(n);
  const cFile = col('file');
  if (cFile < 0) return { rows, warnings: ['The first row needs a "file" column (file, name, mood, tip, steps).'] };
  const cName = col('name'), cMood = col('mood'), cTip = col('tip'), cSteps = col('steps');
  const moodIds = new Set<string>(MOODS.map((m) => m.id));
  table.slice(1).forEach((r, i) => {
    const key = fileKey(r[cFile] ?? '');
    if (!key) return;
    if (rows.has(key)) warnings.push(`Row ${i + 2}: "${r[cFile]}" appears twice; the first one is used.`);
    const out: SheetRow = {};
    const name = cName >= 0 ? (r[cName] ?? '').trim() : '';
    if (name) out.name = name;
    if (cMood >= 0) {
      const wanted = (r[cMood] ?? '').toLowerCase().split(/[\s/;]+/).filter(Boolean);
      const good = wanted.filter((m) => moodIds.has(m)) as Mood[];
      const bad = wanted.filter((m) => !moodIds.has(m));
      if (bad.length) warnings.push(`Row ${i + 2}: unknown mood "${bad.join(', ')}" (use ${[...moodIds].join(', ')}).`);
      if (good.length) out.moods = [...new Set(good)];
    }
    const tip = cTip >= 0 ? (r[cTip] ?? '').trim() : '';
    if (tip) out.tip = tip;
    const steps = cSteps >= 0 ? (r[cSteps] ?? '').split('|').map((s) => s.trim()).filter(Boolean).slice(0, 5) : [];
    if (steps.length) out.steps = steps;
    if (!rows.has(key)) rows.set(key, out);
  });
  return { rows, warnings };
}

export const sheetTemplate = (files: string[]): string =>
  toCsv([['file', 'name', 'mood', 'tip', 'steps'], ...files.map((f) => [f, '', '', '', ''])]);

// ---------- is this photo usable? ----------

export type Verdict = 'ok' | 'check' | 'failed';

export const PEOPLE: Record<Mode, [number, number]> = { solo: [1, 1], couple: [2, 2], group: [3, 5] };

export function peopleProblem(mode: Mode, n: number): string | null {
  const [lo, hi] = PEOPLE[mode];
  if (n < lo || n > hi) {
    const want = lo === hi ? `${lo}` : `${lo} to ${hi}`;
    return `Found ${n} ${n === 1 ? 'person' : 'people'}, ${mode} needs ${want}`;
  }
  return null;
}

type Box = [number, number, number, number];

/** Decides whether a processed photo is fine, worth a look, or unusable. */
export function judge(i: { mode: Mode; people: number; boxes: (Box | null)[]; partial: boolean }): { status: Verdict; note: string } {
  const wrong = peopleProblem(i.mode, i.people);
  if (wrong) return { status: 'failed', note: wrong };
  const good = i.boxes.filter((b): b is Box => !!b);
  if (good.length === 0) return { status: 'failed', note: 'No cut-out could be made (the body outline was not found)' };
  const notes: string[] = [];
  if (good.length < i.boxes.length) notes.push(`${i.boxes.length - good.length} of ${i.boxes.length} people have no cut-out`);
  if (i.partial) notes.push('part of the body is outside the photo');
  const tallest = Math.max(...good.map((b) => b[3] - b[1]));
  if (tallest < (i.mode === 'group' ? 0.2 : 0.3)) notes.push('the person is small in the photo');
  if (notes.length) return { status: 'check', note: notes[0][0].toUpperCase() + notes.join('; ').slice(1) };
  return { status: 'ok', note: '' };
}

// ---------- building a pose and its files ----------

export interface ComposedLike {
  figures: Figure[];
  outlines: (Outline | null)[];
  details: (Stroke[] | null)[];
  ghostPhotos: ({ blob: Blob; box: Box; mirrored: boolean } | null)[];
}

export interface PoseMeta { id: string; title: string; mode: Mode; moods?: Mood[]; steps?: string[]; tip?: string }

export interface GhostFile { file: string; blob: Blob }

const ghostExt = (type: string) => (type === 'image/webp' ? 'webp' : type === 'image/png' ? 'png' : 'img');

export function buildPackPose(meta: PoseMeta, c: ComposedLike): { pose: PackPose; ghosts: GhostFile[] } {
  const ghosts: GhostFile[] = [];
  const refs = c.ghostPhotos.map((g, i): PackGhostRef | null => {
    if (!g) return null;
    const file = `ghosts/${meta.id}-${i + 1}.${ghostExt(g.blob.type)}`;
    ghosts.push({ file, blob: g.blob });
    return { file, box: g.box, mirrored: g.mirrored };
  });
  const pose: PackPose = {
    id: meta.id,
    title: meta.title,
    mode: meta.mode,
    scenes: SCENES.map((s) => s.id), // places are being phased out; every pose shows everywhere for now
    steps: meta.steps?.length ? meta.steps : DEFAULT_STEPS,
    tip: meta.tip || DEFAULT_TIP,
    figures: c.figures,
  };
  if (meta.moods?.length) pose.moods = meta.moods;
  if (c.outlines.some(Boolean)) pose.outlines = c.outlines;
  if (c.details.some((d) => d && d.length)) pose.details = c.details;
  if (refs.some(Boolean)) pose.ghosts = refs;
  return { pose, ghosts };
}

export interface PackItem { pose: PackPose; ghosts: GhostFile[] }

/** All files of one pack (relative to the zip root) plus the manifest. */
export function packEntries(mode: Mode, items: PackItem[]): { entries: ZipEntry[]; manifest: PackManifest } {
  const poses: PackFile = { v: 1, mode, poses: items.map((i) => i.pose) };
  const json = JSON.stringify(poses);
  const files: { path: string; bytes: number }[] = [{ path: 'poses.json', bytes: new TextEncoder().encode(json).length }];
  const entries: ZipEntry[] = [{ path: `packs/${mode}/poses.json`, data: json }];
  let ghostCount = 0;
  for (const it of items) {
    for (const g of it.ghosts) {
      entries.push({ path: `packs/${mode}/${g.file}`, data: g.blob });
      files.push({ path: g.file, bytes: g.blob.size });
      ghostCount++;
    }
  }
  const manifest: PackManifest = {
    v: 1,
    mode,
    count: items.length,
    ghostCount,
    totalBytes: files.reduce((n, f) => n + f.bytes, 0),
    files,
  };
  entries.push({ path: `packs/${mode}/manifest.json`, data: JSON.stringify(manifest, null, 1) });
  return { entries, manifest };
}

export function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export interface ReportRow { file: string; status: string; people: number; title: string; note: string; included: boolean; ghostBytes: number }

export const reportCsv = (rows: ReportRow[]): string =>
  toCsv([
    ['file', 'status', 'people', 'title', 'note', 'included', 'cutout_kb'],
    ...rows.map((r) => [r.file, r.status, r.people, r.title, r.note, r.included ? 'yes' : 'no', Math.round(r.ghostBytes / 1024)]),
  ]);
