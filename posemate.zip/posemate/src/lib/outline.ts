import type { Outline } from '../data/poses';

// Turns a person-segmentation mask into a simplified closed outline.
// Steps: threshold -> keep largest blob -> trace its edge -> simplify -> smooth.

type P = [number, number];

function rdp(p: P[], eps: number): P[] {
  if (p.length < 3) return p;
  const [x1, y1] = p[0];
  const [x2, y2] = p[p.length - 1];
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  let maxD = 0;
  let idx = 0;
  for (let i = 1; i < p.length - 1; i++) {
    const d = len === 0
      ? Math.hypot(p[i][0] - x1, p[i][1] - y1)
      : Math.abs(dy * p[i][0] - dx * p[i][1] + x2 * y1 - y2 * x1) / len;
    if (d > maxD) {
      maxD = d;
      idx = i;
    }
  }
  if (maxD > eps) {
    const l = rdp(p.slice(0, idx + 1), eps);
    const r = rdp(p.slice(idx), eps);
    return l.slice(0, -1).concat(r);
  }
  return [p[0], p[p.length - 1]];
}

function chaikin(p: P[]): P[] {
  const out: P[] = [];
  for (let i = 0; i < p.length; i++) {
    const a = p[i];
    const b = p[(i + 1) % p.length];
    out.push([0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1]]);
    out.push([0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]]);
  }
  return out;
}

const DX = [-1, -1, 0, 1, 1, 1, 0, -1]; // W, NW, N, NE, E, SE, S, SW (clockwise on screen)
const DY = [0, -1, -1, -1, 0, 1, 1, 1];

/**
 * @param mask foreground confidence 0..1, row-major, size mw x mh
 * @returns outline points normalised to 0..1 of the mask, or null if no usable blob
 */
export function traceOutline(mask: Float32Array, mw: number, mh: number, threshold = 0.5): Outline | null {
  const k = Math.min(1, 160 / Math.max(mw, mh));
  const gw = Math.max(1, Math.round(mw * k));
  const gh = Math.max(1, Math.round(mh * k));
  const W = gw + 2; // 1px empty border so tracing never leaves the grid
  const H = gh + 2;
  const g = new Uint8Array(W * H);
  for (let y = 0; y < gh; y++) {
    const sy = Math.min(mh - 1, Math.floor((y + 0.5) / k));
    for (let x = 0; x < gw; x++) {
      const sx = Math.min(mw - 1, Math.floor((x + 0.5) / k));
      if (mask[sy * mw + sx] >= threshold) g[(y + 1) * W + x + 1] = 1;
    }
  }

  // keep only the largest connected blob (drops specks and other background people)
  const label = new Int32Array(W * H);
  const stack: number[] = [];
  let best = 0;
  let bestId = 0;
  let id = 0;
  for (let i = 0; i < W * H; i++) {
    if (!g[i] || label[i]) continue;
    id++;
    let area = 0;
    label[i] = id;
    stack.push(i);
    while (stack.length) {
      const c = stack.pop()!;
      area++;
      const x = c % W;
      const y = (c / W) | 0;
      const ns = [x > 0 ? c - 1 : -1, x < W - 1 ? c + 1 : -1, y > 0 ? c - W : -1, y < H - 1 ? c + W : -1];
      for (const n of ns) {
        if (n >= 0 && g[n] && !label[n]) {
          label[n] = id;
          stack.push(n);
        }
      }
    }
    if (area > best) {
      best = area;
      bestId = id;
    }
  }
  if (best < gw * gh * 0.002) return null;
  for (let i = 0; i < g.length; i++) g[i] = label[i] === bestId ? 1 : 0;

  let start = -1;
  for (let i = 0; i < g.length; i++) {
    if (g[i]) {
      start = i;
      break;
    }
  }
  if (start < 0) return null;

  // Moore-neighbour boundary tracing
  const sx = start % W;
  const sy = (start / W) | 0;
  let cx = sx;
  let cy = sy;
  let bx = sx - 1;
  let by = sy;
  const pts: P[] = [[cx - 0.5, cy - 0.5]];
  for (let guard = 0; guard < W * H * 4; guard++) {
    let i0 = 0;
    for (let d = 0; d < 8; d++) {
      if (cx + DX[d] === bx && cy + DY[d] === by) {
        i0 = d;
        break;
      }
    }
    let found = -1;
    for (let j = 1; j <= 8; j++) {
      const d = (i0 + j) % 8;
      if (g[(cy + DY[d]) * W + cx + DX[d]]) {
        found = d;
        break;
      }
    }
    if (found < 0) break;
    const pd = (found + 7) % 8;
    bx = cx + DX[pd];
    by = cy + DY[pd];
    cx += DX[found];
    cy += DY[found];
    if (cx === sx && cy === sy && pts.length > 2) break;
    pts.push([cx - 0.5, cy - 0.5]);
  }
  if (pts.length < 8) return null;

  let simple = rdp(pts.concat([pts[0]]), 1.1);
  simple = simple.slice(0, -1);
  if (simple.length < 6) return null;
  const smooth = chaikin(simple);

  return smooth.map(([x, y]) => [Math.round((x / gw) * 1e4) / 1e4, Math.round((y / gh) * 1e4) / 1e4] as [number, number]);
}
