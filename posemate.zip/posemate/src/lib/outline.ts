import type { Outline } from '../data/poses';
import { boxBlur, chaikin, dilate, erode, largestComponent, rdp } from './vision';

// Turns a person-segmentation mask into a clean closed outline.
// Steps: sample to a working grid -> blur + threshold -> morphological opening
// (removes stray hair, flyaway fabric and thin spikes) -> keep the biggest blob
// -> trace its edge -> simplify -> smooth.

type P = [number, number];

export const GRID_LONG = 288; // working resolution (long side) for outlines and inner edges

export interface Grid {
  bin: Uint8Array; // 1 = person, row-major gw x gh
  gw: number;
  gh: number;
}

/** Cleans a raw mask (0..1 confidence) into a smooth binary person blob. */
export function refineMask(mask: Float32Array, mw: number, mh: number, threshold = 0.5): Grid | null {
  const k = Math.min(1, GRID_LONG / Math.max(mw, mh));
  const gw = Math.max(1, Math.round(mw * k));
  const gh = Math.max(1, Math.round(mh * k));
  const f = new Float32Array(gw * gh);
  for (let y = 0; y < gh; y++) {
    const sy = Math.min(mh - 1, Math.floor((y + 0.5) / k));
    for (let x = 0; x < gw; x++) {
      const sx = Math.min(mw - 1, Math.floor((x + 0.5) / k));
      f[y * gw + x] = mask[sy * mw + sx];
    }
  }
  const soft = boxBlur(boxBlur(f, gw, gh, 2), gw, gh, 1); // ~Gaussian blur, then threshold
  let bin: Uint8Array = new Uint8Array(gw * gh);
  for (let i = 0; i < bin.length; i++) bin[i] = soft[i] >= threshold ? 1 : 0;
  bin = dilate(erode(bin, gw, gh, 2), gw, gh, 2); // opening: prune thin pixels, round sharp corners
  const { bin: big, area } = largestComponent(bin, gw, gh);
  if (area < gw * gh * 0.002) return null;
  return { bin: big, gw, gh };
}

const DX = [-1, -1, 0, 1, 1, 1, 0, -1]; // W, NW, N, NE, E, SE, S, SW (clockwise on screen)
const DY = [0, -1, -1, -1, 0, 1, 1, 1];

/** Traces the outer boundary of a cleaned blob into points normalised to 0..1. */
export function traceGrid(grid: Grid): Outline | null {
  const { gw, gh } = grid;
  const W = gw + 2; // 1px empty border so tracing never leaves the grid
  const H = gh + 2;
  const g = new Uint8Array(W * H);
  for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) g[(y + 1) * W + x + 1] = grid.bin[y * gw + x];

  let start = -1;
  for (let i = 0; i < g.length; i++) {
    if (g[i]) {
      start = i;
      break;
    }
  }
  if (start < 0) return null;

  // Moore-neighbour boundary tracing
  const sx = start % W;
  const sy = (start / W) | 0;
  let cx = sx;
  let cy = sy;
  let bx = sx - 1;
  let by = sy;
  const pts: P[] = [[cx - 0.5, cy - 0.5]];
  for (let guard = 0; guard < W * H * 4; guard++) {
    let i0 = 0;
    for (let d = 0; d < 8; d++) {
      if (cx + DX[d] === bx && cy + DY[d] === by) {
        i0 = d;
        break;
      }
    }
    let found = -1;
    for (let j = 1; j <= 8; j++) {
      const d = (i0 + j) % 8;
      if (g[(cy + DY[d]) * W + cx + DX[d]]) {
        found = d;
        break;
      }
    }
    if (found < 0) break;
    const pd = (found + 7) % 8;
    bx = cx + DX[pd];
    by = cy + DY[pd];
    cx += DX[found];
    cy += DY[found];
    if (cx === sx && cy === sy && pts.length > 2) break;
    pts.push([cx - 0.5, cy - 0.5]);
  }
  if (pts.length < 8) return null;

  let simple = rdp(pts.concat([pts[0]]), 2.0);
  simple = simple.slice(0, -1);
  if (simple.length < 3) return null;
  const smooth = chaikin(chaikin(simple));

  return smooth.map(([x, y]) => [Math.round((x / gw) * 1e4) / 1e4, Math.round((y / gh) * 1e4) / 1e4] as P);
}

export function traceOutline(mask: Float32Array, mw: number, mh: number): Outline | null {
  const g = refineMask(mask, mw, mh);
  return g ? traceGrid(g) : null;
}
