import type { JointName } from '../data/poses';
import type { Person } from './draw';

// One Euro filter (Casiez et al.): heavy smoothing when a joint is still, light
// smoothing when it moves fast, so the skeleton neither jitters nor lags.
// Coordinates are normalised 0..1, so speeds are small numbers; beta is tuned for that.
const MIN_CUTOFF = 1.5; // Hz: lower = steadier when still
const BETA = 4; // higher = less lag when moving
const D_CUTOFF = 1;
const SAME_PERSON = 0.2; // max centre movement (0..1) between frames to count as the same person

const alpha = (cutoff: number, dt: number) => 1 / (1 + 1 / (2 * Math.PI * cutoff) / dt);

class OneEuro {
  private x: number | null = null;
  private dx = 0;
  private prev: number | null = null;

  filter(v: number, dt: number): number {
    const d = this.prev === null ? 0 : (v - this.prev) / dt;
    this.prev = v;
    this.dx = this.dx + alpha(D_CUTOFF, dt) * (d - this.dx);
    const a = alpha(MIN_CUTOFF + BETA * Math.abs(this.dx), dt);
    this.x = this.x === null ? v : this.x + a * (v - this.x);
    return this.x;
  }
}

interface Track {
  f: Partial<Record<JointName, [OneEuro, OneEuro]>>;
  cx: number;
  cy: number;
}

const centre = (p: Person): [number, number] => {
  const pts = [p.lSh, p.rSh, p.lHip, p.rHip];
  return [pts.reduce((s, q) => s + q.x, 0) / 4, pts.reduce((s, q) => s + q.y, 0) / 4];
};

/** Smooths detected people over time. Keep one instance per camera session. */
export class PoseSmoother {
  private tracks: Track[] = [];
  private lastT = 0;

  reset() {
    this.tracks = [];
    this.lastT = 0;
  }

  apply(people: Person[], tMs: number): Person[] {
    const dt = this.lastT ? Math.min(0.25, Math.max(0.005, (tMs - this.lastT) / 1000)) : 0.05;
    this.lastT = tMs;

    const used = new Set<Track>();
    const next: Track[] = [];
    const out = people.map((p) => {
      const [cx, cy] = centre(p);
      // Reuse the nearest unclaimed track so people keep their own filters if the model reorders them.
      let best: Track | null = null;
      let bestD = SAME_PERSON;
      for (const t of this.tracks) {
        if (used.has(t)) continue;
        const d = Math.hypot(t.cx - cx, t.cy - cy);
        if (d < bestD) {
          best = t;
          bestD = d;
        }
      }
      const track: Track = best ?? { f: {}, cx, cy };
      used.add(track);
      track.cx = cx;
      track.cy = cy;
      next.push(track);

      const sm = {} as Person;
      (Object.keys(p) as JointName[]).forEach((k) => {
        const pair = (track.f[k] ??= [new OneEuro(), new OneEuro()]);
        sm[k] = { x: pair[0].filter(p[k].x, dt), y: pair[1].filter(p[k].y, dt), v: p[k].v };
      });
      return sm;
    });
    this.tracks = next; // tracks with no match this frame are dropped
    return out;
  }
}
