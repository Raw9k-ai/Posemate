import type { JointName, Stroke } from '../data/poses';
import type { Person } from './draw';
import type { Grid } from './outline';
import { chaikinOpen, edgeStrokes, labelBoundaries, modeFilter } from './vision';

// Part segmentation from the detected skeleton + the person mask.
// Every mask pixel is assigned to the nearest body part (head, torso, upper arm,
// forearm, hand, thigh, shin, foot). The contours are the borders between parts, so
// crossed arms, hands on hips and bent knees stay readable inside the silhouette.
// Borders only exist between two parts that are both inside the mask, so they never
// double up with the outer outline. This is skeleton-guided, not a trained
// part-segmentation network: its accuracy follows the joint detection.

// fine part ids
const HEAD = 1, TORSO = 2;
const L_UARM = 3, L_FARM = 4, L_HAND = 5;
const R_UARM = 6, R_FARM = 7, R_HAND = 8;
const L_THIGH = 9, L_SHIN = 10, L_FOOT = 11;
const R_THIGH = 12, R_SHIN = 13, R_FOOT = 14;

interface Seg { id: number; ax: number; ay: number; bx: number; by: number; r: number }
interface XY { x: number; y: number }

const MIN_V = 0.4;

function segDist(px: number, py: number, s: Seg): number {
  const dx = s.bx - s.ax;
  const dy = s.by - s.ay;
  const l2 = dx * dx + dy * dy;
  const t = l2 === 0 ? 0 : Math.max(0, Math.min(1, ((px - s.ax) * dx + (py - s.ay) * dy) / l2));
  return Math.hypot(px - (s.ax + t * dx), py - (s.ay + t * dy));
}

function inQuad(px: number, py: number, q: XY[]): boolean {
  let inside = false;
  for (let i = 0, j = q.length - 1; i < q.length; j = i++) {
    if (q[i].y > py !== q[j].y > py && px < ((q[j].x - q[i].x) * (py - q[i].y)) / (q[j].y - q[i].y) + q[i].x) inside = !inside;
  }
  return inside;
}

function quadDist(px: number, py: number, q: XY[]): number {
  let best = Infinity;
  for (let i = 0; i < q.length; i++) {
    const a = q[i];
    const b = q[(i + 1) % q.length];
    best = Math.min(best, segDist(px, py, { id: 0, ax: a.x, ay: a.y, bx: b.x, by: b.y, r: 1 }));
  }
  return best;
}

/** Part layout for one person in grid pixels. Parts whose joints are not visible are skipped. */
function layout(person: Person, gw: number, gh: number): { segs: Seg[]; quad: XY[] | null; torsoR: number } | null {
  const P = (j: JointName): XY => ({ x: person[j].x * gw, y: person[j].y * gh });
  const ok = (...js: JointName[]) => js.every((j) => person[j].v >= MIN_V);

  const sh = { l: P('lSh'), r: P('rSh') };
  const hip = { l: P('lHip'), r: P('rHip') };
  const sm = { x: (sh.l.x + sh.r.x) / 2, y: (sh.l.y + sh.r.y) / 2 };
  const hm = { x: (hip.l.x + hip.r.x) / 2, y: (hip.l.y + hip.r.y) / 2 };
  const sw = Math.hypot(sh.l.x - sh.r.x, sh.l.y - sh.r.y);
  const haveTorso = ok('lSh', 'rSh', 'lHip', 'rHip');
  if (!ok('lSh', 'rSh')) return null; // need a usable body scale
  const u = haveTorso ? Math.max(Math.hypot(sm.x - hm.x, sm.y - hm.y), sw * 1.2) : sw * 1.5;
  if (u < 4) return null;

  const segs: Seg[] = [];
  const add = (id: number, a: XY, b: XY, r: number) => segs.push({ id, ax: a.x, ay: a.y, bx: b.x, by: b.y, r: r * u });
  // continue a limb past its end joint (hand beyond wrist, foot beyond ankle)
  const beyond = (from: XY, to: XY, len: number): XY => {
    const d = Math.hypot(to.x - from.x, to.y - from.y) || 1;
    return { x: to.x + ((to.x - from.x) / d) * len * u, y: to.y + ((to.y - from.y) / d) * len * u };
  };

  if (ok('nose')) add(HEAD, sm, P('nose'), 0.24);

  const sides = [
    { s: 'l', ua: L_UARM, fa: L_FARM, ha: L_HAND, th: L_THIGH, sn: L_SHIN, ft: L_FOOT },
    { s: 'r', ua: R_UARM, fa: R_FARM, ha: R_HAND, th: R_THIGH, sn: R_SHIN, ft: R_FOOT },
  ] as const;
  for (const k of sides) {
    const Sh = `${k.s}Sh` as JointName, El = `${k.s}El` as JointName, Wr = `${k.s}Wr` as JointName;
    const Hp = `${k.s}Hip` as JointName, Kn = `${k.s}Kn` as JointName, An = `${k.s}An` as JointName;
    if (ok(Sh, El)) add(k.ua, P(Sh), P(El), 0.16);
    if (ok(El, Wr)) {
      add(k.fa, P(El), P(Wr), 0.13);
      add(k.ha, P(Wr), beyond(P(El), P(Wr), 0.16), 0.12);
    }
    if (ok(Hp, Kn)) add(k.th, P(Hp), P(Kn), 0.2);
    if (ok(Kn, An)) {
      add(k.sn, P(Kn), P(An), 0.16);
      add(k.ft, P(An), beyond(P(Kn), P(An), 0.14), 0.1);
    }
  }
  const quad = haveTorso ? [sh.l, sh.r, hip.r, hip.l] : null;
  return { segs, quad, torsoR: 0.13 * u };
}

interface PartInput {
  gw: number;
  gh: number;
  parts: (Uint8Array | null)[]; // per person: fine part id per grid pixel (0 = outside)
}

// The label map only depends on the photo, so compute it once per analysis.
const cache = new WeakMap<(Grid | null)[], { persons: Person[]; input: PartInput | null }>();

function prepare(persons: Person[], grids: (Grid | null)[]): PartInput | null {
  const hit = cache.get(grids);
  if (hit && hit.persons === persons) return hit.input;

  const ref = grids.find((g): g is Grid => g !== null);
  let input: PartInput | null = null;
  if (ref) {
    const { gw, gh } = ref;
    const parts = persons.map((person, i) => {
      const g = grids[i];
      const lay = g ? layout(person, gw, gh) : null;
      if (!g || !lay) return null;
      const out = new Uint8Array(gw * gh);
      for (let y = 0; y < gh; y++) {
        for (let x = 0; x < gw; x++) {
          const idx = y * gw + x;
          if (!g.bin[idx]) continue;
          const px = x + 0.5;
          const py = y + 0.5;
          // score < 1: inside that part's capsule. The torso scores exactly 1 inside its quad, so a
          // limb lying across the chest (folded arms, hand on hip) wins over the torso beneath it.
          let bestId = 0;
          let best = Infinity;
          for (const s of lay.segs) {
            const sc = segDist(px, py, s) / s.r;
            if (sc < best) {
              best = sc;
              bestId = s.id;
            }
          }
          if (lay.quad) {
            const sc = inQuad(px, py, lay.quad) ? 1 : 1 + quadDist(px, py, lay.quad) / lay.torsoR;
            if (sc < best) {
              best = sc;
              bestId = TORSO;
            }
          }
          out[idx] = bestId;
        }
      }
      return out;
    });
    input = { gw, gh, parts };
  }
  cache.set(grids, { persons, input });
  return input;
}

export type DetailLevel = 0 | 1 | 2 | 3; // off, simple (6 regions), detailed (10 limb parts), hands & feet (14)

// fine part id -> group id for each level (index = fine id)
const GROUPS: Record<1 | 2 | 3, number[]> = {
  //   0  head torso lUA lFA lH rUA rFA rH lTh lSh lFt rTh rSh rFt
  1: [0, 1, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6],
  2: [0, 1, 2, 3, 4, 4, 5, 6, 6, 7, 8, 8, 9, 10, 10],
  3: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
};
const MIN_PIXELS: Record<1 | 2 | 3, number> = { 1: 12, 2: 10, 3: 8 };

/** Contours between body parts, as smoothed polylines normalised to the photo (per person). */
export function partStrokes(persons: Person[], grids: (Grid | null)[], level: DetailLevel): (Stroke[] | null)[] {
  if (level === 0) return persons.map(() => null);
  const input = prepare(persons, grids);
  if (!input) return persons.map(() => null);
  const { gw, gh } = input;
  const table = GROUPS[level];
  return input.parts.map((fine) => {
    if (!fine) return null;
    let grouped: Uint8Array = new Uint8Array(fine.length);
    for (let i = 0; i < fine.length; i++) grouped[i] = table[fine[i]] ?? 0;
    grouped = modeFilter(modeFilter(grouped, gw, gh), gw, gh); // smooth jagged region borders
    const edges = labelBoundaries(grouped, gw, gh);
    return edgeStrokes(edges, gw, gh, MIN_PIXELS[level], 1.0).map((poly) =>
      chaikinOpen(poly, 1).map(([x, y]) => [Math.round((x / gw) * 1e4) / 1e4, Math.round((y / gh) * 1e4) / 1e4] as [number, number]),
    );
  });
}
