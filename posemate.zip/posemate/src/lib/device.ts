import { useEffect, useState } from 'react';

// ---------- sound (generated on the phone, no audio files) ----------
let ctx: AudioContext | null = null;

function audio(): AudioContext | null {
  if (!ctx) {
    const C = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!C) return null;
    try {
      ctx = new C();
    } catch {
      return null;
    }
  }
  if (ctx.state === 'suspended') void ctx.resume();
  return ctx;
}

/** Call from a tap so the browser allows sound later (for example the auto-snap beep). */
export const primeAudio = () => void audio();

function tone(freq: number, ms: number, vol = 0.25, delay = 0) {
  const a = audio();
  if (!a) return;
  const t = a.currentTime + delay;
  const osc = a.createOscillator();
  const g = a.createGain();
  osc.type = 'sine';
  osc.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + ms / 1000);
  osc.connect(g).connect(a.destination);
  osc.start(t);
  osc.stop(t + ms / 1000 + 0.02);
}

/** One countdown tick; the last second is higher so it is easy to tell. */
export const tickSound = (last = false) => tone(last ? 1320 : 880, 110);

/** Short rising chime: the pose is matched, hold still. */
export const lockSound = () => {
  tone(660, 90, 0.2);
  tone(990, 140, 0.2, 0.09);
};

/** Shutter click: two quick bursts of filtered noise. */
export function shutterSound() {
  const a = audio();
  if (!a) return;
  const click = (delay: number, len: number) => {
    const n = Math.floor(a.sampleRate * len);
    const buf = a.createBuffer(1, n, a.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 3);
    const src = a.createBufferSource();
    src.buffer = buf;
    const f = a.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 2400;
    const g = a.createGain();
    g.gain.value = 0.7;
    src.connect(f).connect(g).connect(a.destination);
    src.start(a.currentTime + delay);
  };
  click(0, 0.035);
  click(0.07, 0.05);
}

// ---------- screen wake lock ----------
/** Keeps the screen on while `enabled` and the page is visible. Does nothing where unsupported. */
export function useWakeLock(enabled: boolean) {
  useEffect(() => {
    if (!enabled || !('wakeLock' in navigator)) return;
    let lock: WakeLockSentinel | null = null;
    let dead = false;

    const acquire = async () => {
      try {
        const l = await navigator.wakeLock.request('screen');
        if (dead) {
          void l.release();
          return;
        }
        lock = l;
        l.addEventListener('release', () => {
          if (lock === l) lock = null; // the browser drops it when the tab is hidden
        });
      } catch {
        /* refused, for example in battery saver: the screen just follows the phone's normal timeout */
      }
    };
    const onVisible = () => {
      if (document.visibilityState === 'visible' && !lock) void acquire();
    };

    void acquire();
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      dead = true;
      document.removeEventListener('visibilitychange', onVisible);
      void lock?.release();
      lock = null;
    };
  }, [enabled]);
}

// ---------- battery level ----------
interface BatteryManager extends EventTarget {
  level: number;
  charging: boolean;
}

/**
 * Is the battery low (20% or less) and unplugged? Uses the Battery Status API, which Chrome on
 * Android has. A web page cannot see Android's own Battery Saver switch, so this is the signal we have.
 * `supported` is false where the browser does not share battery info (it is blocked in some browsers).
 */
export function useLowBattery(): { supported: boolean; low: boolean } {
  const [state, setState] = useState({ supported: false, low: false });
  useEffect(() => {
    const nav = navigator as Navigator & { getBattery?: () => Promise<BatteryManager> };
    if (!nav.getBattery) return;
    let battery: BatteryManager | null = null;
    let dead = false;
    const update = () => {
      if (battery && !dead) setState({ supported: true, low: !battery.charging && battery.level <= 0.2 });
    };
    nav
      .getBattery()
      .then((b) => {
        if (dead) return;
        battery = b;
        update();
        b.addEventListener('levelchange', update);
        b.addEventListener('chargingchange', update);
      })
      .catch(() => {
        /* blocked by the browser: treat as unsupported */
      });
    return () => {
      dead = true;
      battery?.removeEventListener('levelchange', update);
      battery?.removeEventListener('chargingchange', update);
    };
  }, []);
  return state;
}
