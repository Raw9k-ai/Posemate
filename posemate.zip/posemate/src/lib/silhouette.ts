import type { JointName } from '../data/poses';

export interface XY { x: number; y: number }

/** Body parts as simple shapes: limbs are capsules, the head is an oval. */
export type Shape =
  | { t: 'cap'; a: XY; b: XY; r: number }
  | { t: 'ell'; c: XY; rx: number; ry: number; rot: number }
  | { t: 'poly'; pts: XY[]; r: number }
  | { t: 'path'; pts: XY[] }; // traced contour from a reference photo

const mid = (a: XY, b: XY): XY => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });

/**
 * Builds a body-shaped silhouette from the 13 joints, in whatever coordinate
 * space the joints are in. Proportions scale with the torso length.
 */
export function bodyShapes(p: Record<JointName, XY>): Shape[] {
  const sm = mid(p.lSh, p.rSh);
  const hm = mid(p.lHip, p.rHip);
  const sw = Math.hypot(p.lSh.x - p.rSh.x, p.lSh.y - p.rSh.y);
  const u = Math.max(Math.hypot(sm.x - hm.x, sm.y - hm.y), sw * 1.2, 1e-6);
  const dot = (c: XY): XY => ({ x: c.x + u * 0.001, y: c.y });

  const out: Shape[] = [];
  out.push({ t: 'poly', pts: [p.lSh, p.rSh, p.rHip, p.lHip], r: 0.11 * u });
  out.push({ t: 'cap', a: sm, b: p.nose, r: 0.07 * u });
  out.push({
    t: 'ell', c: p.nose, rx: 0.17 * u, ry: 0.21 * u,
    rot: Math.atan2(p.nose.y - sm.y, p.nose.x - sm.x) + Math.PI / 2,
  });

  for (const s of ['l', 'r'] as const) {
    const sh = p[`${s}Sh` as JointName], el = p[`${s}El` as JointName], wr = p[`${s}Wr` as JointName];
    const hip = p[`${s}Hip` as JointName], kn = p[`${s}Kn` as JointName], an = p[`${s}An` as JointName];
    out.push({ t: 'cap', a: sh, b: el, r: 0.15 * u });
    out.push({ t: 'cap', a: el, b: wr, r: 0.12 * u });
    out.push({ t: 'cap', a: wr, b: dot(wr), r: 0.11 * u }); // hand
    out.push({ t: 'cap', a: hip, b: kn, r: 0.2 * u });
    out.push({ t: 'cap', a: kn, b: an, r: 0.15 * u });
    const dir = s === 'l' ? 1 : -1; // person's left is on the image right
    out.push({ t: 'cap', a: an, b: { x: an.x + dir * 0.14 * u, y: an.y + 0.02 * u }, r: 0.07 * u }); // foot
  }
  return out;
}

/** Fill/stroke one shape, grown outward by x. Colours are set by the caller. */
export function paintShape(ctx: CanvasRenderingContext2D, s: Shape, x: number) {
  ctx.beginPath();
  if (s.t === 'cap') {
    ctx.lineCap = 'round';
    ctx.lineWidth = 2 * (s.r + x);
    ctx.moveTo(s.a.x, s.a.y);
    ctx.lineTo(s.b.x, s.b.y);
    ctx.stroke();
  } else if (s.t === 'ell') {
    ctx.ellipse(s.c.x, s.c.y, s.rx + x, s.ry + x, s.rot, 0, Math.PI * 2);
    ctx.fill();
  } else if (s.t === 'poly') {
    s.pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
    ctx.closePath();
    ctx.fill();
    ctx.lineJoin = 'round';
    ctx.lineWidth = 2 * (s.r + x);
    ctx.stroke();
  } else {
    s.pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
    ctx.closePath();
    ctx.fill();
    if (x > 0) {
      ctx.lineJoin = 'round';
      ctx.lineWidth = 2 * x;
      ctx.stroke();
    }
  }
}
