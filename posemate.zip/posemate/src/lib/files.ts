export const newId = () =>
  (crypto.randomUUID?.() ?? String(Date.now()) + Math.random().toString(16).slice(2));

export function fileName(ts: number): string {
  const d = new Date(ts);
  const p = (n: number) => String(n).padStart(2, '0');
  return `posemate-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}.jpg`;
}

export function formatBytes(n: number): string {
  return n > 1_000_000 ? (n / 1_000_000).toFixed(1) + ' MB' : Math.round(n / 1000) + ' KB';
}

export function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function canShareFile(blob: Blob, name: string): boolean {
  if (!navigator.canShare) return false;
  return navigator.canShare({ files: [new File([blob], name, { type: blob.type || 'image/jpeg' })] });
}

export async function shareBlob(blob: Blob, name: string) {
  const file = new File([blob], name, { type: blob.type || 'image/jpeg' });
  await navigator.share({ files: [file], title: 'PoseMate photo' });
}

/** Small JPEG for the gallery grid so we never decode full-size photos in a list. */
export async function makeThumb(blob: Blob, longSide = 360): Promise<Blob> {
  const bmp = await createImageBitmap(blob);
  const s = longSide / Math.max(bmp.width, bmp.height);
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bmp.width * s));
  canvas.height = Math.max(1, Math.round(bmp.height * s));
  canvas.getContext('2d')?.drawImage(bmp, 0, 0, canvas.width, canvas.height);
  bmp.close();
  const out = await new Promise<Blob | null>((res) => canvas.toBlob(res, 'image/jpeg', 0.8));
  if (!out) throw new Error('Thumbnail failed');
  return out;
}
