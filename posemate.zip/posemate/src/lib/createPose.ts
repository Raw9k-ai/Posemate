import type { Figure, JointName, Mode, Outline } from '../data/poses';
import type { Person } from './draw';
import { loadStillDetector } from './pose';
import { traceOutline } from './outline';

export interface Analysis {
  url: string; // object URL of the chosen photo (memory only, never stored)
  width: number;
  height: number;
  persons: Person[];
  outlines: (Outline | null)[]; // normalised to the photo
  partial: boolean; // some body parts were outside the photo
}

const MAX_SIDE = 1280;

/** Detects people in a photo and traces each body outline, all on-device. */
export async function analyzePhoto(file: File): Promise<Analysis> {
  let bmp: ImageBitmap;
  try {
    bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
  } catch {
    throw new Error('That file could not be read as an image. Try a JPEG or PNG photo.');
  }
  const k = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bmp.width * k));
  canvas.height = Math.max(1, Math.round(bmp.height * k));
  canvas.getContext('2d')!.drawImage(bmp, 0, 0, canvas.width, canvas.height);
  bmp.close();

  const det = await loadStillDetector();
  const { persons, masks } = det.detect(canvas);
  if (persons.length === 0) {
    throw new Error('No person was found. Use a clear photo where the whole body is visible and well lit.');
  }
  const outlines = persons.map((_, i) => {
    const m = masks[i];
    return m ? traceOutline(m.data, m.width, m.height) : null;
  });
  const partial = persons.some(
    (p) => (Object.keys(p) as JointName[]).filter((j) => j !== 'nose' && p[j].v < 0.5).length > 3,
  );
  return { url: URL.createObjectURL(file), width: canvas.width, height: canvas.height, persons, outlines, partial };
}

export const modeForCount = (n: number): Mode => (n <= 1 ? 'solo' : n === 2 ? 'couple' : 'group');

const swap = (j: JointName): JointName =>
  (j.startsWith('l') ? 'r' + j.slice(1) : j.startsWith('r') ? 'l' + j.slice(1) : j) as JointName;

/**
 * Converts detected people into the shared pose format: every figure and outline
 * is fitted into the 0..1 guide square (aspect ratio kept, feet near the bottom).
 */
export function composePose(a: Analysis, flip: boolean): { figures: Figure[]; outlines: (Outline | null)[] } {
  const cxOf = (p: Person) => (p.lHip.x + p.rHip.x + p.lSh.x + p.rSh.x) / 4;
  const items = a.persons
    .map((person, i) => ({ person, outline: a.outlines[i] ?? null }))
    .sort((p, q) => cxOf(p.person) - cxOf(q.person));

  let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
  const grow = (x: number, y: number) => {
    x0 = Math.min(x0, x); x1 = Math.max(x1, x);
    y0 = Math.min(y0, y); y1 = Math.max(y1, y);
  };
  for (const it of items) {
    if (it.outline) it.outline.forEach(([x, y]) => grow(x * a.width, y * a.height));
    else (Object.values(it.person) as Person[JointName][]).forEach((pt) => pt.v >= 0.5 && grow(pt.x * a.width, pt.y * a.height));
  }
  if (!isFinite(x0)) {
    items.forEach((it) => (Object.values(it.person) as Person[JointName][]).forEach((pt) => grow(pt.x * a.width, pt.y * a.height)));
  }
  const s = 0.94 / Math.max(x1 - x0, y1 - y0, 1);
  const midX = (x0 + x1) / 2;
  const map = (px: number, py: number): [number, number] => {
    const x = 0.5 + (px - midX) * s;
    return [Math.round((flip ? 1 - x : x) * 1e4) / 1e4, Math.round((0.97 - (y1 - py) * s) * 1e4) / 1e4];
  };

  const figures = items.map(({ person }) => {
    const f = {} as Figure;
    (Object.keys(person) as JointName[]).forEach((j) => {
      f[flip ? swap(j) : j] = map(person[j].x * a.width, person[j].y * a.height);
    });
    return f;
  });
  const outlines = items.map(({ outline }) =>
    outline ? outline.map(([x, y]) => map(x * a.width, y * a.height)) : null,
  );
  return { figures, outlines };
}
