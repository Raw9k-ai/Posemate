import { BONES, type Figure, type JointName, type Outline, type Stroke } from '../data/poses';
import { bodyShapes, paintShape, type Shape } from './silhouette';

export interface Pt { x: number; y: number; v: number }
/** One detected person, landmarks normalised 0..1 relative to the camera frame. */
export type Person = Record<JointName, Pt>;

// MediaPipe Pose landmark indices for the joints we use.
const LM_INDEX: Record<JointName, number> = {
  nose: 0, lSh: 11, rSh: 12, lEl: 13, rEl: 14, lWr: 15, rWr: 16,
  lHip: 23, rHip: 24, lKn: 25, rKn: 26, lAn: 27, rAn: 28,
};

export function toPerson(lms: { x: number; y: number; visibility?: number }[]): Person {
  const out = {} as Person;
  (Object.keys(LM_INDEX) as JointName[]).forEach((k) => {
    const l = lms[LM_INDEX[k]];
    out[k] = { x: l.x, y: l.y, v: l.visibility ?? 1 };
  });
  return out;
}

/** Where a w x h frame sits inside a cw x ch box when shown with object-fit: contain. */
export function fitRect(cw: number, ch: number, vw: number, vh: number) {
  const s = Math.min(cw / vw, ch / vh);
  const w = vw * s;
  const h = vh * s;
  return { x: (cw - w) / 2, y: (ch - h) / 2, w, h };
}

const COLORS = ['#D9F24B', '#6FE3E1', '#FF8FC0', '#B7A9FF', '#FFC24B'];

interface XY { x: number; y: number; v?: number }

function drawFigure(
  ctx: CanvasRenderingContext2D,
  p: Record<JointName, XY>,
  s: { color: string; lw: number; dash?: boolean },
) {
  const ok = (j: JointName) => (p[j].v ?? 1) >= 0.4;
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.lineWidth = s.lw;
  ctx.strokeStyle = s.color;
  ctx.fillStyle = s.color;
  ctx.shadowColor = 'rgba(0,0,0,0.55)';
  ctx.shadowBlur = 4;
  if (s.dash) ctx.setLineDash([s.lw * 1.4, s.lw * 2]);

  for (const [a, b] of BONES) {
    if (!ok(a) || !ok(b)) continue;
    ctx.beginPath();
    ctx.moveTo(p[a].x, p[a].y);
    ctx.lineTo(p[b].x, p[b].y);
    ctx.stroke();
  }
  if (ok('nose')) {
    const sw = ok('lSh') && ok('rSh') ? Math.hypot(p.lSh.x - p.rSh.x, p.lSh.y - p.rSh.y) : 40;
    ctx.beginPath();
    ctx.arc(p.nose.x, p.nose.y, Math.max(8, sw * 0.3), 0, Math.PI * 2);
    ctx.stroke();
  }
  if (!s.dash) {
    (Object.keys(p) as JointName[]).forEach((j) => {
      if (j === 'nose' || !ok(j)) return;
      ctx.beginPath();
      ctx.arc(p[j].x, p[j].y, s.lw * 0.9, 0, Math.PI * 2);
      ctx.fill();
    });
  }
  ctx.restore();
}


// The body-outline guide is expensive to build but only changes when the pose
// or screen size changes, so it is rendered once and reused every frame.
let guideCache: {
  ref: Figure[];
  outlines?: (Outline | null)[];
  details?: (Stroke[] | null)[];
  key: string;
  canvas: HTMLCanvasElement;
} | null = null;

// Ghost fill per figure: white for the first, then soft tints so each person in a
// couple/group pose can tell which ghost is theirs.
const GHOST_COLORS = ['#FFFFFF', '#BFE9FF', '#FFD6EC', '#E3FFB0', '#FFE2A8'];

const EDGE_COLOR = '#C8F7FF'; // soft cyan-white part contours
const BONE_COLOR = '#FF5CF4'; // neon skeleton, different from the live skeleton colours

function drawGuideSkeleton(ctx: CanvasRenderingContext2D, p: Record<JointName, XY>, side: number, dpr: number) {
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.globalAlpha = 0.65;
  ctx.strokeStyle = ctx.fillStyle = BONE_COLOR;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const lw = Math.max(2.5, side * 0.007);
  ctx.lineWidth = lw;
  for (const [a, b] of BONES) {
    ctx.beginPath();
    ctx.moveTo(p[a].x, p[a].y);
    ctx.lineTo(p[b].x, p[b].y);
    ctx.stroke();
  }
  const mx = (p.lSh.x + p.rSh.x) / 2;
  const my = (p.lSh.y + p.rSh.y) / 2;
  ctx.beginPath();
  ctx.moveTo(mx, my);
  ctx.lineTo(p.nose.x, p.nose.y);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(p.nose.x, p.nose.y, Math.max(6, Math.hypot(p.lSh.x - p.rSh.x, p.lSh.y - p.rSh.y) * 0.3), 0, Math.PI * 2);
  ctx.stroke();
  (Object.keys(p) as JointName[]).forEach((j) => {
    if (j === 'nose') return;
    ctx.beginPath();
    ctx.arc(p[j].x, p[j].y, lw * 0.9, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.restore();
}

function guideLayer(
  ref: Figure[],
  outlines: (Outline | null)[] | undefined,
  details: (Stroke[] | null)[] | undefined,
  showDetail: boolean,
  ghost: number,
  W: number, H: number, dpr: number, bx: number, by: number, side: number,
) {
  const key = `${W}x${H}|${bx.toFixed(1)}|${by.toFixed(1)}|${side.toFixed(1)}|${showDetail ? 1 : 0}|${ghost}`;
  if (
    guideCache && guideCache.ref === ref && guideCache.outlines === outlines &&
    guideCache.details === details && guideCache.key === key
  ) return guideCache.canvas;

  const layer = guideCache?.canvas ?? document.createElement('canvas');
  layer.width = W;
  layer.height = H;
  const lctx = layer.getContext('2d')!;
  lctx.clearRect(0, 0, W, H);
  const tmp = document.createElement('canvas');
  tmp.width = W;
  tmp.height = H;
  const t = tmp.getContext('2d')!;
  const border = Math.max(2.5, side * 0.007);

  const reset = () => {
    t.setTransform(1, 0, 0, 1, 0, 0);
    t.globalCompositeOperation = 'source-over';
    t.clearRect(0, 0, W, H);
    t.setTransform(dpr, 0, 0, dpr, 0, 0);
    t.fillStyle = t.strokeStyle = '#fff';
  };

  ref.forEach((f, idx) => {
    const pts = {} as Record<JointName, { x: number; y: number }>;
    (Object.keys(f) as JointName[]).forEach((j) => {
      pts[j] = { x: bx + f[j][0] * side, y: by + f[j][1] * side };
    });
    // a traced outline (from a photo) wins; otherwise build the body from the joints
    const traced = outlines?.[idx];
    const shapes: Shape[] = traced
      ? [{ t: 'path', pts: traced.map(([x, y]) => ({ x: bx + x * side, y: by + y * side })) }]
      : bodyShapes(pts);

    // ghost: a translucent filled figure to line yourself up with (drawn on a scratch
    // canvas first so overlapping limbs don't double up the opacity)
    if (ghost > 0) {
      reset();
      t.fillStyle = t.strokeStyle = GHOST_COLORS[idx % GHOST_COLORS.length];
      shapes.forEach((s) => paintShape(t, s, 0));
      lctx.globalAlpha = ghost;
      lctx.drawImage(tmp, 0, 0);
    }

    // body-part contours: borders between head, torso, arms and legs (always inside the outline)
    const strokes = traced && showDetail ? details?.[idx] : null;
    if (strokes?.length) {
      lctx.save();
      lctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      lctx.globalAlpha = 0.55;
      lctx.strokeStyle = EDGE_COLOR;
      lctx.lineWidth = Math.max(1.3, side * 0.0032);
      lctx.lineCap = 'round';
      lctx.lineJoin = 'round';
      for (const line of strokes) {
        lctx.beginPath();
        line.forEach(([x, y], i) => (i ? lctx.lineTo(bx + x * side, by + y * side) : lctx.moveTo(bx + x * side, by + y * side)));
        lctx.stroke();
      }
      lctx.restore();
    }

    // outline of the combined shape: grow everything, then cut the inside out
    reset();
    shapes.forEach((s) => paintShape(t, s, border));
    t.globalCompositeOperation = 'destination-out';
    shapes.forEach((s) => paintShape(t, s, 0));
    lctx.globalAlpha = 0.95;
    lctx.shadowColor = 'rgba(0,0,0,0.5)';
    lctx.shadowBlur = 5 * dpr;
    lctx.drawImage(tmp, 0, 0);
    lctx.shadowBlur = 0;
    lctx.globalAlpha = 1;

    // skeleton on top so elbows, shoulders and head stay readable inside bulky clothing
    if (traced && showDetail) drawGuideSkeleton(lctx, pts as Record<JointName, XY>, side, dpr);
  });
  guideCache = { ref, outlines, details, key, canvas: layer };
  return layer;
}

export interface OverlayOpts {
  vw: number; // frame / photo pixel width
  vh: number; // frame / photo pixel height
  persons?: Person[]; // detected landmarks
  reference?: Figure[]; // reference pose guide
  outlines?: (Outline | null)[]; // traced body outlines for the guide, if any
  details?: (Stroke[] | null)[]; // inner detail lines for the guide, if any
  showDetail?: boolean; // draw inner lines + guide skeleton (default true)
  ghost?: number; // opacity 0..1 of the filled ghost figure (default 0.4, 0 = outline only)
}

/**
 * Draws the guide and detected skeleton on a transparent canvas that sits on
 * top of the video or photo. The photo itself is never modified.
 */
export function drawOverlay(canvas: HTMLCanvasElement, o: OverlayOpts) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const cw = canvas.clientWidth;
  const ch = canvas.clientHeight;
  if (!cw || !ch) return;
  const W = Math.round(cw * dpr);
  const H = Math.round(ch * dpr);
  if (canvas.width !== W || canvas.height !== H) {
    canvas.width = W;
    canvas.height = H;
  }
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cw, ch);

  const r = fitRect(cw, ch, o.vw, o.vh);

  if (o.reference?.length) {
    const side = Math.min(r.w, r.h);
    const bx = r.x + (r.w - side) / 2;
    const by = r.y + (r.h - side) * 0.55;
    ctx.drawImage(guideLayer(o.reference, o.outlines, o.details, o.showDetail ?? true, o.ghost ?? 0.4, W, H, dpr, bx, by, side), 0, 0, cw, ch);
  }

  o.persons?.forEach((person, i) => {
    const pts = {} as Record<JointName, XY>;
    (Object.keys(person) as JointName[]).forEach((j) => {
      pts[j] = { x: r.x + person[j].x * r.w, y: r.y + person[j].y * r.h, v: person[j].v };
    });
    drawFigure(ctx, pts, { color: COLORS[i % COLORS.length], lw: Math.max(3, r.w * 0.009) });
  });
}
