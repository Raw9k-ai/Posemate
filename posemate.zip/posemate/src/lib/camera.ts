export type Facing = 'user' | 'environment';

export interface CameraSession {
  stream: MediaStream;
  track: MediaStreamTrack;
  facing: Facing;
  label: string;
}

export function explainCameraError(e: unknown): string {
  const name = e instanceof DOMException ? e.name : e instanceof Error ? e.name : '';
  const msg = e instanceof Error ? e.message : '';
  switch (name) {
    case 'NotAllowedError':
    case 'PermissionDeniedError':
      return 'Camera permission was blocked. Tap the lock icon in the address bar, allow Camera for this site, then try again.';
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return 'No camera was found on this device.';
    case 'NotReadableError':
    case 'TrackStartError':
      return 'The camera is busy. Close other apps that use it (video calls, other camera apps) and try again.';
    case 'OverconstrainedError':
      return 'This camera does not support the requested settings.';
    case 'SecurityError':
      return 'The browser blocked camera access. PoseMate must be opened over HTTPS (or localhost).';
    case 'AbortError':
      return 'The camera stopped while starting. Please try again.';
    default:
      return msg || 'The camera could not be started.';
  }
}

/**
 * Opens a camera at the highest practical resolution. The numbers below are
 * "ideal" hints, not requirements: the browser picks the closest mode the
 * camera actually supports, so this never fails just because 4K is missing.
 * 4:3 matches what most phone sensors use for full-resolution stills.
 */
export async function openCamera(facing: Facing): Promise<CameraSession> {
  if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
    throw new DOMException('Camera needs a secure context', 'SecurityError');
  }
  const portrait = window.innerHeight > window.innerWidth;
  const long = 4032;
  const short = 3024;
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: false,
    video: {
      facingMode: { ideal: facing },
      width: { ideal: portrait ? short : long },
      height: { ideal: portrait ? long : short },
      aspectRatio: { ideal: portrait ? 3 / 4 : 4 / 3 },
    },
  });
  const track = stream.getVideoTracks()[0];
  const reported = track.getSettings().facingMode;
  return {
    stream,
    track,
    facing: reported === 'user' || reported === 'environment' ? reported : facing,
    label: track.label,
  };
}

export interface CapturedPhoto {
  blob: Blob;
  width: number;
  height: number;
  method: 'ImageCapture (full sensor)' | 'Video frame';
}

// ImageCapture is not in every TypeScript DOM lib, so describe what we use.
interface ImageCaptureLike {
  getPhotoCapabilities(): Promise<{
    imageWidth?: { max: number };
    imageHeight?: { max: number };
  }>;
  takePhoto(o?: { imageWidth: number; imageHeight: number }): Promise<Blob>;
}

/**
 * Takes the best still the browser can give us. On Android Chrome,
 * ImageCapture.takePhoto returns a full-sensor JPEG, usually much larger than
 * the live preview. Everywhere else we fall back to the current video frame.
 */
export async function takeBestPhoto(session: CameraSession, video: HTMLVideoElement): Promise<CapturedPhoto> {
  const IC = (window as unknown as { ImageCapture?: new (t: MediaStreamTrack) => ImageCaptureLike }).ImageCapture;
  if (IC) {
    try {
      const ic = new IC(session.track);
      let opts: { imageWidth: number; imageHeight: number } | undefined;
      try {
        const caps = await ic.getPhotoCapabilities();
        if (caps.imageWidth?.max && caps.imageHeight?.max) {
          opts = { imageWidth: caps.imageWidth.max, imageHeight: caps.imageHeight.max };
        }
      } catch {
        /* capabilities unavailable; use defaults */
      }
      const blob = await ic.takePhoto(opts);
      const bmp = await createImageBitmap(blob);
      const out = { blob, width: bmp.width, height: bmp.height, method: 'ImageCapture (full sensor)' as const };
      bmp.close();
      return out;
    } catch {
      /* fall through to the video-frame path */
    }
  }
  const w = video.videoWidth;
  const h = video.videoHeight;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not read the camera frame.');
  ctx.drawImage(video, 0, 0, w, h);
  const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, 'image/jpeg', 0.95));
  if (!blob) throw new Error('Could not encode the photo.');
  return { blob, width: w, height: h, method: 'Video frame' };
}
