import type { Fit } from './fit';
import { guideSquare } from './fit';

// Moving, resizing and auto-fitting the pose guide. All distances are in video-frame pixels.
// A Fit says "move the guide's anchor `cr` onto `cu`, scaled by `s`" (see drawOverlay), so a manual
// adjustment is just a shift of `cu` and a multiplier on `s`, applied on top of the automatic fit.

export interface GuideAdjust {
  dx: number;
  dy: number;
  scale: number;
}

export const IDENTITY: GuideAdjust = { dx: 0, dy: 0, scale: 1 };
export const SCALE_MIN = 0.4;
export const SCALE_MAX = 2.5;

export const isIdentity = (a: GuideAdjust) => a.dx === 0 && a.dy === 0 && a.scale === 1;

export function clampAdjust(a: GuideAdjust, vw: number, vh: number): GuideAdjust {
  return {
    dx: Math.max(-vw, Math.min(vw, a.dx)),
    dy: Math.max(-vh, Math.min(vh, a.dy)),
    scale: Math.max(SCALE_MIN, Math.min(SCALE_MAX, a.scale)),
  };
}

/** The Fit to draw: the automatic fit (or none) plus the person's own adjustment. Null = default placement. */
export function composeFit(auto: Fit | null, adj: GuideAdjust, vw: number, vh: number): Fit | null {
  if (!auto && isIdentity(adj)) return null;
  let base = auto;
  if (!base) {
    const { side, bx, by } = guideSquare(vw, vh);
    const c = { x: bx + side / 2, y: by + side / 2 };
    base = { s: 1, cu: c, cr: c };
  }
  return { s: base.s * adj.scale, cu: { x: base.cu.x + adj.dx, y: base.cu.y + adj.dy }, cr: base.cr };
}

/** Eases the automatic fit so the guide glides instead of jumping. `a` is how far to move toward the new fit (0..1). */
export function smoothFit(prev: Fit | null, next: Fit | null, a = 0.3): Fit | null {
  if (!next) return null;
  if (!prev) return next;
  const l = (p: number, n: number) => p + (n - p) * a;
  return {
    s: l(prev.s, next.s),
    cu: { x: l(prev.cu.x, next.cu.x), y: l(prev.cu.y, next.cu.y) },
    cr: { x: l(prev.cr.x, next.cr.x), y: l(prev.cr.y, next.cr.y) },
  };
}

/**
 * Finger drag in screen pixels -> frame pixels. `k` is screen pixels per frame pixel. The canvas of a
 * front camera sits inside a mirrored box, so a drag to the right is a move to the left in canvas terms.
 */
export function dragBy(a: GuideAdjust, sx: number, sy: number, k: number, mirrored: boolean): GuideAdjust {
  if (!(k > 0)) return a;
  return { ...a, dx: a.dx + (mirrored ? -sx : sx) / k, dy: a.dy + sy / k };
}

/** Pinch: the fingers' distance now divided by before. */
export function pinchBy(a: GuideAdjust, ratio: number): GuideAdjust {
  if (!Number.isFinite(ratio) || ratio <= 0) return a;
  return { ...a, scale: a.scale * ratio };
}
