// Local storage in the browser's IndexedDB. Nothing is uploaded.
import type { Person } from './draw';
import type { Pose } from '../data/poses';

export interface PhotoRecord {
  id: string;
  createdAt: number;
  blob: Blob; // the original photo, exactly as captured
  thumb: Blob; // small preview for the gallery grid
  width: number;
  height: number;
  poseId: string | null; // overlay data is stored separately from the photo
  people: Person[];
  overlayValid: boolean;
  mirrored: boolean;
  method: string;
}

const DB = 'posemate';
const PHOTOS = 'photos';
const POSES = 'poses';

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 2);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(PHOTOS)) db.createObjectStore(PHOTOS, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(POSES)) db.createObjectStore(POSES, { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Storage unavailable'));
  });
}

function run<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return open().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const tx = db.transaction(store, mode);
        const req = fn(tx.objectStore(store));
        tx.oncomplete = () => {
          db.close();
          resolve(req.result);
        };
        tx.onerror = tx.onabort = () => {
          db.close();
          reject(tx.error ?? new Error('Storage failed'));
        };
      }),
  );
}

// ---- photos ----
export async function savePhoto(r: PhotoRecord): Promise<void> {
  await run(PHOTOS, 'readwrite', (s) => s.put(r));
  // Ask the browser not to evict our data under storage pressure (best effort).
  void navigator.storage?.persist?.();
}

export async function listPhotos(): Promise<PhotoRecord[]> {
  const all = await run<PhotoRecord[]>(PHOTOS, 'readonly', (s) => s.getAll());
  return all.sort((a, b) => b.createdAt - a.createdAt);
}

export const deletePhoto = (id: string) => run(PHOTOS, 'readwrite', (s) => s.delete(id));

// ---- custom poses (outline + joints only; the reference photo is never stored) ----
export const saveCustomPose = async (p: Pose) => {
  await run(POSES, 'readwrite', (s) => s.put(p));
  void navigator.storage?.persist?.();
};
export const listCustomPoses = () => run<Pose[]>(POSES, 'readonly', (s) => s.getAll());
export const deleteCustomPose = (id: string) => run(POSES, 'readwrite', (s) => s.delete(id));
