import { useSyncExternalStore } from 'react';

// Everything the person can change about how the app looks and reads: colours, font, text size,
// corner style, renamed text, replaced icons, and per-element tweaks (colour, image, hidden).
// Saved in this browser (localStorage); images are small data URLs. Nothing is uploaded.

export const COLOR_KEYS = ['ink', 'paper', 'volt', 'cobalt', 'bubble', 'sun', 'aqua', 'lilac', 'mist', 'mint', 'coral'] as const;
export type ColorKey = (typeof COLOR_KEYS)[number];

export const DEFAULT_COLORS: Record<ColorKey, string> = {
  ink: '#12142B', paper: '#F3F4FA', volt: '#D9F24B', cobalt: '#3D4DFF', bubble: '#FF8FC0', sun: '#FFC24B',
  aqua: '#6FE3E1', lilac: '#B7A9FF', mist: '#A9D4FF', mint: '#B8EBC0', coral: '#FF9E85',
};

export const COLOR_LABELS: Record<ColorKey, string> = {
  ink: 'Text and dark buttons', paper: 'Background', volt: 'Highlight (active, good match)', cobalt: 'Main buttons',
  bubble: 'Hearts and favorites', sun: 'Warnings', aqua: 'Tile: aqua', lilac: 'Tile: lilac', mist: 'Tile: sky', mint: 'Tile: mint', coral: 'Tile: coral',
};

export const PRESETS: { id: string; name: string; colors: Partial<Record<ColorKey, string>> }[] = [
  { id: 'default', name: 'Default', colors: {} },
  { id: 'sunset', name: 'Sunset', colors: { ink: '#2B1B17', paper: '#FFF3EA', volt: '#FFD25E', cobalt: '#E4572E', bubble: '#FF7B9C', sun: '#FFB347', aqua: '#FFB997', lilac: '#E6A8D7', mist: '#F9C6A8', mint: '#FFE29A', coral: '#FF8C69' } },
  { id: 'forest', name: 'Forest', colors: { ink: '#10261C', paper: '#EEF5EC', volt: '#C6F36B', cobalt: '#1F7A4D', bubble: '#F2A0B8', sun: '#F4B942', aqua: '#7FD8C4', lilac: '#B9B0E6', mist: '#A8D8E8', mint: '#B5E3B0', coral: '#F2A07B' } },
  { id: 'berry', name: 'Berry', colors: { ink: '#2A1030', paper: '#F8EEF8', volt: '#F6E05E', cobalt: '#9B2FC9', bubble: '#FF6FAE', sun: '#FFB84D', aqua: '#7FD3E6', lilac: '#C9A6F2', mist: '#B6C9F5', mint: '#BDE8C8', coral: '#FF8F8F' } },
  { id: 'contrast', name: 'High contrast', colors: { ink: '#000000', paper: '#FFFFFF', volt: '#FFE600', cobalt: '#0033CC', bubble: '#FF3D8B', sun: '#FF9900', aqua: '#00C2C7', lilac: '#9A8CFF', mist: '#7FB8FF', mint: '#4CD964', coral: '#FF6B4A' } },
];

export interface FontOption { id: string; name: string; stack: string }
export const FONTS: FontOption[] = [
  { id: 'system', name: 'Phone default', stack: "system-ui, -apple-system, Roboto, 'Segoe UI', sans-serif" },
  { id: 'serif', name: 'Serif', stack: "Georgia, 'Noto Serif', 'Times New Roman', serif" },
  { id: 'rounded', name: 'Rounded', stack: "ui-rounded, 'SF Pro Rounded', 'Arial Rounded MT Bold', Nunito, system-ui, sans-serif" },
  { id: 'mono', name: 'Typewriter', stack: "ui-monospace, 'SF Mono', Menlo, Consolas, 'Droid Sans Mono', monospace" },
  { id: 'hand', name: 'Handwriting', stack: "'Segoe Print', 'Bradley Hand', 'Marker Felt', 'Comic Sans MS', cursive" },
  { id: 'condensed', name: 'Narrow', stack: "'Arial Narrow', 'Roboto Condensed', sans-serif-condensed, sans-serif" },
  { id: 'readable', name: 'Easy to read', stack: "Verdana, Tahoma, 'DejaVu Sans', sans-serif" },
];
export const CUSTOM_FONT_ID = 'custom';
export const CUSTOM_FONT_FAMILY = 'PoseMateCustom';

export type Corner = 'round' | 'soft' | 'square';
export type IconOverride = { kind: 'image'; src: string } | { kind: 'emoji'; text: string };
export interface ElRule { bg?: string; fg?: string; image?: string; hidden?: boolean }

export interface UiState {
  colors: Partial<Record<ColorKey, string>>;
  font: string; // a FONTS id, or CUSTOM_FONT_ID
  fontName?: string; // file name of the custom font, for display
  textScale: number; // 0.85 .. 1.4
  corner: Corner;
  texts: Record<string, string>; // original text -> replacement
  icons: Record<string, IconOverride>; // icon name -> replacement
  els: Record<string, ElRule>; // element key -> tweaks
}

export const TEXT_SCALE_MIN = 0.85;
export const TEXT_SCALE_MAX = 1.4;
export const EMPTY_UI: UiState = { colors: {}, font: 'system', textScale: 1, corner: 'round', texts: {}, icons: {}, els: {} };

const MAX_TEXTS = 200;
const MAX_ELS = 200;
const MAX_ICONS = 40;
const MAX_IMAGE_CHARS = 300_000; // about 220 KB of image
const HEX = /^#[0-9a-f]{6}$/i;
const isImage = (s: unknown): s is string => typeof s === 'string' && s.startsWith('data:image/') && s.length <= MAX_IMAGE_CHARS;

/** Collapses whitespace and shortens, so the same label always gives the same key. */
export const normKey = (s: string | null | undefined) => (s ?? '').replace(/\s+/g, ' ').trim().slice(0, 60);

export function hexToTriplet(hex: string): string {
  const n = parseInt(hex.slice(1), 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}

function luminance(hex: string): number {
  const n = parseInt(hex.slice(1), 16);
  const f = (c: number) => {
    const v = c / 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * f((n >> 16) & 255) + 0.7152 * f((n >> 8) & 255) + 0.0722 * f(n & 255);
}

/** WCAG contrast ratio between two #rrggbb colours (1 to 21). 4.5 or more is comfortable for text. */
export function contrastRatio(a: string, b: string): number {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

export const colorOf = (s: UiState, k: ColorKey) => s.colors[k] ?? DEFAULT_COLORS[k];

/** Reads saved settings; anything unexpected is dropped rather than trusted. */
export function parseUi(raw: unknown): UiState {
  let o: Record<string, unknown> | null = null;
  try {
    const v = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (v && typeof v === 'object' && !Array.isArray(v)) o = v as Record<string, unknown>;
  } catch {
    /* corrupt: use defaults */
  }
  if (!o) return { ...EMPTY_UI, colors: {}, texts: {}, icons: {}, els: {} };
  const rec = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {});

  const colors: UiState['colors'] = {};
  for (const [k, v] of Object.entries(rec(o.colors))) if ((COLOR_KEYS as readonly string[]).includes(k) && typeof v === 'string' && HEX.test(v)) colors[k as ColorKey] = v.toUpperCase();

  const texts: UiState['texts'] = {};
  for (const [k, v] of Object.entries(rec(o.texts)).slice(0, MAX_TEXTS)) if (k && k.length <= 60 && typeof v === 'string' && v.trim() && v.length <= 120) texts[k] = v;

  const icons: UiState['icons'] = {};
  for (const [k, v] of Object.entries(rec(o.icons)).slice(0, MAX_ICONS)) {
    const r = rec(v);
    if (r.kind === 'image' && isImage(r.src)) icons[k] = { kind: 'image', src: r.src };
    else if (r.kind === 'emoji' && typeof r.text === 'string' && r.text.trim() && r.text.length <= 8) icons[k] = { kind: 'emoji', text: r.text };
  }

  const els: UiState['els'] = {};
  for (const [k, v] of Object.entries(rec(o.els)).slice(0, MAX_ELS)) {
    const r = rec(v);
    const rule: ElRule = {};
    if (typeof r.bg === 'string' && HEX.test(r.bg)) rule.bg = r.bg;
    if (typeof r.fg === 'string' && HEX.test(r.fg)) rule.fg = r.fg;
    if (isImage(r.image)) rule.image = r.image;
    if (r.hidden === true) rule.hidden = true;
    if (k && k.length <= 80 && Object.keys(rule).length) els[k] = rule;
  }

  const scale = typeof o.textScale === 'number' && Number.isFinite(o.textScale) ? o.textScale : 1;
  const font = typeof o.font === 'string' && (o.font === CUSTOM_FONT_ID || FONTS.some((f) => f.id === o.font)) ? o.font : 'system';
  return {
    colors,
    font,
    fontName: typeof o.fontName === 'string' ? o.fontName.slice(0, 60) : undefined,
    textScale: Math.min(TEXT_SCALE_MAX, Math.max(TEXT_SCALE_MIN, scale)),
    corner: o.corner === 'soft' || o.corner === 'square' ? o.corner : 'round',
    texts, icons, els,
  };
}

// ---------------- the saved store ----------------

const KEY = 'posemate-ui';
const FONT_KEY = 'posemate-ui-font';
const read = (k: string) => {
  try {
    return localStorage.getItem(k);
  } catch {
    return null;
  }
};

let state: UiState = parseUi(read(KEY));
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

export const getUi = () => state;
export const subscribeUi = (l: () => void) => (listeners.add(l), () => void listeners.delete(l));
export const useUi = () =>
  useSyncExternalStore(subscribeUi, () => state, () => EMPTY_UI);

/** Applies a change and saves it. Returns false if the browser had no room to save (the change is then not applied). */
export function updateUi(fn: (s: UiState) => UiState): boolean {
  const next = parseUi(fn(state));
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    return false;
  }
  state = next;
  emit();
  return true;
}

export function resetUi() {
  try {
    localStorage.removeItem(KEY);
    localStorage.removeItem(FONT_KEY);
  } catch {
    /* nothing saved anyway */
  }
  state = parseUi(null);
  emit();
}

export const getCustomFontData = () => read(FONT_KEY);
export function saveCustomFont(dataUrl: string | null): boolean {
  try {
    if (dataUrl) localStorage.setItem(FONT_KEY, dataUrl);
    else localStorage.removeItem(FONT_KEY);
    return true;
  } catch {
    return false;
  }
}

/** A backup the person can keep: all settings, plus the custom font if there is one. */
export function exportUi(): string {
  return JSON.stringify({ app: 'posemate-ui', v: 1, ui: state, font: getCustomFontData() }, null, 1);
}

export function importUi(text: string): boolean {
  try {
    const o = JSON.parse(text);
    if (!o || o.app !== 'posemate-ui' || !o.ui) return false;
    const next = parseUi(o.ui);
    const font = typeof o.font === 'string' && o.font.startsWith('data:') && o.font.length < 3_000_000 ? o.font : null;
    if (!saveCustomFont(font)) return false;
    return updateUi(() => (next.font === CUSTOM_FONT_ID && !font ? { ...next, font: 'system' } : next));
  } catch {
    return false;
  }
}

// ---------------- element rule helpers (pure, shared by the editor and the Customize list) ----------------

export const withText = (s: UiState, original: string, to: string): UiState => {
  const texts = { ...s.texts };
  const k = normKey(original);
  if (!k) return s;
  if (!to.trim() || normKey(to) === k) delete texts[k];
  else texts[k] = to.trim().slice(0, 120);
  return { ...s, texts };
};

export const withEl = (s: UiState, key: string, patch: Partial<ElRule> | null): UiState => {
  const els = { ...s.els };
  const merged: ElRule = { ...(els[key] ?? {}), ...(patch ?? {}) };
  for (const k of Object.keys(merged) as (keyof ElRule)[]) if (merged[k] === undefined || merged[k] === false) delete merged[k];
  if (!patch || Object.keys(merged).length === 0) delete els[key];
  else els[key] = merged;
  return { ...s, els };
};

export const withIcon = (s: UiState, name: string, ov: IconOverride | null): UiState => {
  const icons = { ...s.icons };
  if (ov) icons[name] = ov;
  else delete icons[name];
  return { ...s, icons };
};

/** The saved override for an icon, or null. */
export const useIconOverride = (name: string): IconOverride | null => useUi().icons[name] ?? null;
