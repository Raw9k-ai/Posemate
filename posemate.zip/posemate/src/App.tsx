import { useEffect } from 'react';
import { useRoute } from './lib/route';
import { isMode, isScene } from './data/poses';
import { refreshCustomPoses, useLibraryVersion } from './data/custom';
import Home from './screens/Home';
import Scenes from './screens/Scenes';
import Poses from './screens/Poses';
import CameraScreen from './screens/Camera';
import Gallery from './screens/Gallery';
import Create from './screens/Create';

export default function App() {
  const [a, b, c] = useRoute();
  useLibraryVersion(); // re-render when the user's own poses change
  useEffect(() => {
    void refreshCustomPoses();
  }, []);

  if (a === 'scenes' && isMode(b)) return <Scenes mode={b} />;
  if (a === 'poses' && isMode(b) && isScene(c)) return <Poses mode={b} scene={c} />;
  if (a === 'camera') return <CameraScreen poseId={b} />;
  if (a === 'gallery') return <Gallery />;
  if (a === 'create') return <Create />;
  return <Home />;
}
