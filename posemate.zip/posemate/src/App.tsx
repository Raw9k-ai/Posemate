import { useRoute } from './lib/route';
import { isMode, isScene } from './data/poses';
import Home from './screens/Home';
import Scenes from './screens/Scenes';
import Poses from './screens/Poses';
import CameraScreen from './screens/Camera';
import Gallery from './screens/Gallery';

export default function App() {
  const [a, b, c] = useRoute();
  if (a === 'scenes' && isMode(b)) return <Scenes mode={b} />;
  if (a === 'poses' && isMode(b) && isScene(c)) return <Poses mode={b} scene={c} />;
  if (a === 'camera') return <CameraScreen poseId={b} />;
  if (a === 'gallery') return <Gallery />;
  return <Home />;
}
