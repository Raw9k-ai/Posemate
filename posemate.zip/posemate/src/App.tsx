import { useEffect } from 'react';
import { useRoute } from './lib/route';
import { isMode, isScene } from './data/poses';
import { refreshCustomPoses, useLibraryVersion } from './data/custom';
import Home from './screens/Home';
import Scenes from './screens/Scenes';
import Poses from './screens/Poses';
import CameraScreen from './screens/Camera';
import Gallery from './screens/Gallery';
import Create from './screens/Create';
import Favorites from './screens/Favorites';
import Privacy from './screens/Privacy';
import { useApplyLightMode } from './lib/useLightMode';
import Customize from './screens/Customize';
import EditMode from './ui/EditMode';
import { useUi } from './lib/ui';
import { applyTheme } from './ui/theme';
import { startUiEngine } from './ui/engine';

export default function App() {
  return (
    <>
      <Screens />
      <EditMode />
    </>
  );
}

function Screens() {
  const [a, b, c] = useRoute();
  const ui = useUi();
  useEffect(() => applyTheme(ui), [ui]); // colors, font, text size, corners
  useEffect(() => startUiEngine(), []); // renamed text, element tweaks
  useLibraryVersion(); // re-render when the user's own poses change
  useApplyLightMode();
  useEffect(() => {
    void refreshCustomPoses();
  }, []);

  if (a === 'scenes' && isMode(b)) return <Scenes mode={b} />;
  if (a === 'poses' && isMode(b) && isScene(c)) return <Poses mode={b} scene={c} />;
  if (a === 'camera') return <CameraScreen poseId={b} />;
  if (a === 'gallery') return <Gallery />;
  if (a === 'create') return <Create />;
  if (a === 'favorites') return <Favorites />;
  if (a === 'privacy') return <Privacy />;
  if (a === 'customize') return <Customize />;
  return <Home />;
}
