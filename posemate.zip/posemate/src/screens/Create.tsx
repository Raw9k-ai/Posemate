import { useEffect, useMemo, useRef, useState, type ChangeEvent } from 'react';
import Header from '../components/Header';
import Icon from '../components/Icon';
import PoseArt from '../components/PoseArt';
import { SCENES, type Pose, type SceneId, type Stroke } from '../data/poses';
import { addCustomPose } from '../data/custom';
import { analyzePhoto, composePose, modeForCount, type Analysis } from '../lib/createPose';
import { detailStrokes, type DetailLevel } from '../lib/details';
import { drawOverlay, fitRect } from '../lib/draw';
import { newId } from '../lib/files';
import { go } from '../lib/route';

type Phase = 'pick' | 'working' | 'review';

const DEFAULT_STEPS = ['Line up with the outline on screen', 'Hold the pose and relax your face', 'Take the photo'];

export default function Create() {
  const [phase, setPhase] = useState<Phase>('pick');
  const [error, setError] = useState<string | null>(null);
  const [a, setA] = useState<Analysis | null>(null);

  const [title, setTitle] = useState('');
  const [scenes, setScenes] = useState<SceneId[]>(SCENES.map((s) => s.id));
  const [stepsText, setStepsText] = useState('');
  const [tip, setTip] = useState('');
  const [flip, setFlip] = useState(false);
  const [level, setLevel] = useState<DetailLevel>(2);
  const [saving, setSaving] = useState(false);

  // inner detail lines depend on the photo and the chosen sensitivity
  const strokes = useMemo(() => (a?.edge ? detailStrokes(a.edge, level) : undefined), [a, level]);
  const composed = useMemo(() => (a ? composePose(a, flip, strokes) : null), [a, flip, strokes]);

  // The chosen photo only lives in memory; release it when leaving the screen.
  useEffect(() => () => { if (a) URL.revokeObjectURL(a.url); }, [a]);

  const onFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // lets the same file be picked again
    if (!file) return;
    setError(null);
    setPhase('working');
    try {
      setA(await analyzePhoto(file));
      setPhase('review');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'The photo could not be analysed.');
      setPhase('pick');
    }
  };

  const toggleScene = (id: SceneId) =>
    setScenes((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]));

  const save = async () => {
    if (!a || !composed || scenes.length === 0) return;
    setSaving(true);
    setError(null);
    const mode = modeForCount(composed.figures.length);
    const steps = stepsText.split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 6);
    const pose: Pose = {
      id: 'custom-' + newId(),
      title: title.trim() || 'My pose',
      mode,
      scenes,
      steps: steps.length ? steps : DEFAULT_STEPS,
      tip: tip.trim(),
      figures: composed.figures,
      outlines: composed.outlines,
      details: composed.details,
      custom: true,
      createdAt: Date.now(),
    };
    try {
      await addCustomPose(pose);
      go(`poses/${mode}/${scenes[0]}`);
    } catch {
      setError('Could not save on this device. Browser storage may be full or blocked (for example in private browsing).');
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto min-h-dvh w-full max-w-3xl pb-10">
      <Header title="Make a pose" sub="Turn a photo into a camera guide" />
      <div className="px-4 pt-2">
        <label className="sr-only" htmlFor="pose-photo">Choose a photo</label>
        <input id="pose-photo" type="file" accept="image/*" onChange={onFile} className="hidden" />

        {error && <p role="alert" className="mb-4 rounded-2xl bg-rose-100 p-4 text-rose-900">{error}</p>}

        {phase === 'pick' && (
          <div className="rounded-[1.75rem] bg-white p-5 ring-1 ring-ink/5">
            <p className="text-lg font-extrabold">Pick a photo of the pose</p>
            <p className="mt-1 text-ink/70">
              Use a clear photo where the whole body is visible. One person makes a solo pose, two a couple pose,
              three or more a group pose (up to 5 people).
            </p>
            <label htmlFor="pose-photo" className="btn mt-4 w-full cursor-pointer bg-ink text-white">
              <Icon name="gallery" className="h-5 w-5" /> Choose photo
            </label>
            <p className="mt-4 flex items-start gap-2 text-sm text-ink/60">
              <Icon name="shield" className="mt-0.5 h-5 w-5 shrink-0" />
              <span>
                The photo is analysed on your phone and is not uploaded or saved. Only the outline and joint
                positions are stored. Use photos you took or have permission to use.
              </span>
            </p>
          </div>
        )}

        {phase === 'working' && (
          <div role="status" className="rounded-[1.75rem] bg-white p-8 text-center ring-1 ring-ink/5">
            <p className="text-lg font-extrabold">Finding the body outline…</p>
            <p className="mt-1 text-ink/65">The first time can take a few seconds while the model loads.</p>
          </div>
        )}

        {phase === 'review' && a && composed && (
          <>
            <div className="h-[55dvh] overflow-hidden rounded-[1.75rem] bg-ink">
              <AnalysisView a={a} strokes={strokes} />
            </div>
            {a.partial && (
              <p className="mt-3 rounded-2xl bg-amber-200 p-3 text-sm">
                Some body parts were outside the photo, so the match score may be less accurate. A full-body photo works best.
              </p>
            )}

            <div className="mt-4 grid grid-cols-[8rem_1fr] items-center gap-4 rounded-[1.75rem] bg-volt p-4">
              <PoseArt figures={composed.figures} outlines={composed.outlines} details={composed.details} className="h-32 w-32" />
              <div>
                <p className="font-extrabold">Your guide</p>
                <p className="text-sm text-ink/70">
                  {composed.figures.length} {composed.figures.length === 1 ? 'person' : 'people'} ·{' '}
                  {modeForCount(composed.figures.length)} pose
                  {composed.outlines.some((o) => o === null) && ' · some outlines drawn from joints'}
                </p>
                <button
                  onClick={() => setFlip((v) => !v)}
                  aria-pressed={flip}
                  className={`btn mt-2 min-h-10 px-4 text-sm ${flip ? 'bg-ink text-white' : 'bg-white'}`}
                >
                  Flip left / right
                </button>
              </div>
            </div>

            <fieldset className="mt-4 rounded-[1.75rem] bg-white p-5 ring-1 ring-ink/5">
              <legend className="sr-only">Inner detail lines</legend>
              <p className="font-bold">Inner detail lines</p>
              <p className="text-sm text-ink/65">Keeps hands, folded arms and clothing folds visible inside the outline.</p>
              <div className="mt-2 flex gap-1 rounded-full bg-ink/10 p-1">
                {([['Off', 0], ['Low', 1], ['Medium', 2], ['High', 3]] as [string, DetailLevel][]).map(([label, v]) => (
                  <button key={label} type="button" onClick={() => setLevel(v)} aria-pressed={level === v} className={`flex-1 rounded-full py-2 text-sm font-bold ${level === v ? 'bg-ink text-white' : ''}`}>{label}</button>
                ))}
              </div>
            </fieldset>

            <div className="mt-4 space-y-4 rounded-[1.75rem] bg-white p-5 ring-1 ring-ink/5">
              <div>
                <label htmlFor="pose-title" className="font-bold">Name</label>
                <input
                  id="pose-title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  maxLength={40}
                  placeholder="My pose"
                  className="mt-1 w-full rounded-2xl bg-paper px-4 py-3 text-base"
                />
              </div>

              <fieldset>
                <legend className="font-bold">Show it in these places</legend>
                <div className="mt-2 flex flex-wrap gap-2">
                  {SCENES.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => toggleScene(s.id)}
                      aria-pressed={scenes.includes(s.id)}
                      className={`rounded-full px-4 py-2 text-sm font-bold ${scenes.includes(s.id) ? 'bg-ink text-white' : 'bg-ink/10'}`}
                    >
                      {s.emoji} {s.name}
                    </button>
                  ))}
                </div>
                {scenes.length === 0 && <p className="mt-2 text-sm text-rose-700">Pick at least one place.</p>}
              </fieldset>

              <div>
                <label htmlFor="pose-steps" className="font-bold">Instructions <span className="font-normal text-ink/60">(one per line, optional)</span></label>
                <textarea
                  id="pose-steps"
                  value={stepsText}
                  onChange={(e) => setStepsText(e.target.value)}
                  rows={3}
                  placeholder={DEFAULT_STEPS.join('\n')}
                  className="mt-1 w-full rounded-2xl bg-paper px-4 py-3 text-base"
                />
              </div>

              <div>
                <label htmlFor="pose-tip" className="font-bold">Tip <span className="font-normal text-ink/60">(optional)</span></label>
                <input
                  id="pose-tip"
                  value={tip}
                  onChange={(e) => setTip(e.target.value)}
                  maxLength={100}
                  className="mt-1 w-full rounded-2xl bg-paper px-4 py-3 text-base"
                />
              </div>
            </div>

            <div className="mt-4 flex gap-3">
              <label htmlFor="pose-photo" className="btn cursor-pointer bg-ink/10">Different photo</label>
              <button onClick={save} disabled={saving || scenes.length === 0} className="btn flex-1 bg-ink text-white disabled:opacity-50">
                <Icon name="check" className="h-5 w-5" /> {saving ? 'Saving…' : 'Save pose'}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/** The photo with detected joints and the traced outline drawn on top, so you can check the result. */
function AnalysisView({ a, strokes }: { a: Analysis; strokes?: (Stroke[] | null)[] }) {
  const box = useRef<HTMLDivElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const draw = () => {
      const c = cv.current;
      if (!c) return;
      drawOverlay(c, { vw: a.width, vh: a.height, persons: a.persons });
      const ctx = c.getContext('2d');
      if (!ctx || !c.clientWidth) return;
      const r = fitRect(c.clientWidth, c.clientHeight, a.width, a.height);
      ctx.save();
      ctx.strokeStyle = '#6FE3E1';
      ctx.lineWidth = 3;
      ctx.lineJoin = 'round';
      for (const o of a.outlines) {
        if (!o) continue;
        ctx.beginPath();
        o.forEach(([x, y], i) => (i ? ctx.lineTo(r.x + x * r.w, r.y + y * r.h) : ctx.moveTo(r.x + x * r.w, r.y + y * r.h)));
        ctx.closePath();
        ctx.stroke();
      }
      // inner detail lines (thin, soft white) so you can judge them against the photo
      ctx.strokeStyle = 'rgba(255,255,255,0.7)';
      ctx.lineWidth = 1.2;
      for (const person of strokes ?? []) {
        for (const line of person ?? []) {
          ctx.beginPath();
          line.forEach(([x, y], i) => (i ? ctx.lineTo(r.x + x * r.w, r.y + y * r.h) : ctx.moveTo(r.x + x * r.w, r.y + y * r.h)));
          ctx.stroke();
        }
      }
      ctx.restore();
    };
    draw();
    const el = box.current;
    if (!el) return;
    const ro = new ResizeObserver(draw);
    ro.observe(el);
    return () => ro.disconnect();
  }, [a, strokes]);

  return (
    <div ref={box} className="relative h-full w-full">
      <img src={a.url} alt="Your reference photo" className="h-full w-full object-contain" />
      <canvas ref={cv} className="pointer-events-none absolute inset-0 h-full w-full" />
    </div>
  );
}
