import { MODES, POSES } from '../data/poses';
import PoseArt from '../components/PoseArt';
import Icon from '../components/Icon';
import { go } from '../lib/route';

export default function Home() {
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col px-5 pb-8 pt-[max(1.25rem,env(safe-area-inset-top))]">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <img src="./favicon.svg" alt="" className="h-9 w-9" />
          <span className="text-xl font-extrabold tracking-tight">PoseMate</span>
        </div>
        <button onClick={() => go('gallery')} className="btn min-h-11 bg-ink px-4 text-sm text-white">
          <Icon name="gallery" className="h-5 w-5" /> My photos
        </button>
      </header>

      <h1 className="mt-8 font-display text-[2.5rem] leading-[1.02] tracking-tight">
        Know exactly how to stand.
      </h1>
      <p className="mt-3 max-w-md text-lg leading-snug text-ink/70">
        Pick a pose, line up with the live guide, and take the shot. Free, and nothing leaves your phone.
      </p>

      <section aria-label="Photo types" className="mt-7 grid gap-3 md:grid-cols-3">
        {MODES.map((m) => (
          <button
            key={m.id}
            onClick={() => go('scenes/' + m.id)}
            className={`relative min-h-36 overflow-hidden rounded-[2rem] p-5 text-left transition active:scale-[0.98] md:min-h-60 ${m.bg}`}
          >
            <span className="block text-3xl font-extrabold">{m.name}</span>
            <span className="mt-1 block max-w-[10rem] text-base text-ink/70">{m.blurb}</span>
            <PoseArt figures={POSES.find((p) => p.mode === m.id)!.figures} className="absolute -bottom-2 right-2 h-36 w-36 md:left-1/2 md:h-32 md:w-32 md:-translate-x-1/2" />
          </button>
        ))}
      </section>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <button onClick={() => go('camera')} className="btn w-full bg-cobalt text-white">
          <Icon name="camera" className="h-5 w-5" /> Open camera without a pose
        </button>
        <button onClick={() => go('create')} className="btn w-full bg-white ring-2 ring-ink">
          <Icon name="poses" className="h-5 w-5" /> Create a pose from a photo
        </button>
      </div>

      <p className="mt-auto flex items-start gap-2 pt-8 text-sm text-ink/60">
        <Icon name="shield" className="mt-0.5 h-5 w-5 shrink-0" />
        <span>
          Body detection runs on your device. No uploads, no account, no tracking. The camera starts only when you open it.
        </span>
      </p>
    </main>
  );
}
