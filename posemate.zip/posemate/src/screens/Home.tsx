import { MODES, POSES, getAllPoses, type Mode } from '../data/poses';
import PoseArt from '../components/PoseArt';
import Corners from '../components/Corners';
import BottomNav from '../components/BottomNav';
import Icon from '../components/Icon';
import { go } from '../lib/route';
import { usePrefs } from '../lib/prefs';
import { useInstall } from '../lib/install';

// One characteristic pose per photo type; the figure is the memorable thing on this screen.
const SHOWCASE: Record<Mode, string> = {
  solo: 'solo-jump-for-joy',
  couple: 'couple-side-hug',
  group: 'group-line-up',
};

export default function Home() {
  const prefs = usePrefs();
  const favCount = prefs.favorites.length;
  const everything = getAllPoses();
  const recent = prefs.recent.map((id) => everything.find((p) => p.id === id)).filter((p): p is NonNullable<typeof p> => !!p);
  const { canInstall, install } = useInstall();
  return (
    <>
      <main className="mx-auto w-full max-w-3xl px-5 pb-28 pt-[max(1.25rem,env(safe-area-inset-top))]">
        <header className="flex items-center gap-2">
          <img src="./icons/icon-192.png" alt="" className="h-9 w-9 rounded-xl" />
          <span className="text-lg font-extrabold tracking-tight">PoseMate</span>
        </header>

        <h1 className="mt-9 text-[2.6rem] font-black leading-[0.98] tracking-[-0.03em]">Who&rsquo;s in the photo?</h1>
        <p className="mt-3 max-w-sm text-lg leading-snug text-ink/70">
          Pick a pose, line up with its ghost on the camera, and shoot.
        </p>

        <section aria-label="Photo types" className="mt-7 grid gap-3 md:grid-cols-3">
          {MODES.map((m, i) => {
            const pose = POSES.find((p) => p.id === SHOWCASE[m.id])!;
            return (
              <button
                key={m.id}
                onClick={() => go('scenes/' + m.id)}
                style={{ animationDelay: `${i * 70}ms` }}
                className={`rise relative h-44 overflow-hidden rounded-[2rem] p-5 text-left transition active:scale-[0.985] md:h-72 ${m.bg}`}
              >
                <Corners inset="inset-2.5" />
                <span className="relative block text-3xl font-black tracking-tight">{m.name}</span>
                <span className="relative mt-1 block max-w-[8.5rem] text-base leading-snug text-ink/70">{m.blurb}</span>
                <PoseArt
                  figures={pose.figures}
                  className="absolute bottom-3 right-4 h-36 w-36 md:bottom-6 md:left-1/2 md:right-auto md:h-40 md:w-40 md:-translate-x-1/2"
                />
              </button>
            );
          })}
        </section>

        {recent.length > 0 && (
          <section aria-label="Recently used poses" className="mt-6">
            <h2 className="mb-2 text-sm font-extrabold uppercase tracking-wide text-ink/60">Pick up where you left off</h2>
            <ul className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              {recent.map((p) => (
                <li key={p.id} className="shrink-0">
                  <button onClick={() => go('camera/' + p.id)} className="block w-28 rounded-2xl bg-white p-2 text-left active:scale-[0.97]">
                    <PoseArt figures={p.figures} outlines={p.outlines} details={p.details} detail={false} className="h-20 w-full rounded-xl bg-volt/60" />
                    <span className="mt-1 block text-xs font-bold leading-tight">{p.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )}

        <button onClick={() => go('favorites')} className="btn-quiet mt-4 w-full">
          <Icon name="heart" className="h-5 w-5" filled={favCount > 0} />
          Favorites{favCount > 0 ? ` (${favCount})` : ''}
        </button>

        <button data-no-hide onClick={() => go('customize')} className="btn-quiet mt-3 w-full">
          <Icon name="sliders" className="h-5 w-5" /> Customize look
        </button>

        {canInstall && (
          <button onClick={() => void install()} className="btn-quiet mt-3 w-full">
            <Icon name="download" className="h-5 w-5" /> Install PoseMate
          </button>
        )}

        <p className="mt-8 max-w-sm text-sm text-ink/60">
          Body detection runs on your phone. No uploads, no account, no tracking.
        </p>
        <button onClick={() => go('privacy')} className="mt-1 inline-flex items-center gap-1.5 py-2 text-sm font-bold text-ink/70">
          <Icon name="shield" className="h-4 w-4" /> Privacy and data
        </button>
      </main>
      <BottomNav active="home" />
    </>
  );
}
