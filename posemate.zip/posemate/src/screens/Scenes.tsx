import { MODES, SCENES, getPoses, type Mode } from '../data/poses';
import Header from '../components/Header';
import Icon from '../components/Icon';
import BottomNav from '../components/BottomNav';
import { go } from '../lib/route';

export default function Scenes({ mode }: { mode: Mode }) {
  const meta = MODES.find((m) => m.id === mode)!;
  return (
    <>
      <div className="mx-auto w-full max-w-3xl pb-28">
        <Header title={meta.name} sub="Where are you shooting?" />
        <ul className="grid gap-2.5 px-4 pt-2 md:grid-cols-2">
          {SCENES.map((s) => {
            const n = getPoses(mode, s.id).length;
            return (
              <li key={s.id}>
                <button
                  onClick={() => go(`poses/${mode}/${s.id}`)}
                  className={`flex w-full items-center gap-4 rounded-[1.75rem] px-5 py-4 text-left transition active:scale-[0.99] ${s.bg}`}
                >
                  <span className="text-4xl" aria-hidden="true">{s.emoji}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-lg font-extrabold leading-tight">{s.name}</span>
                    <span className="block text-sm text-ink/65">{n} {n === 1 ? 'pose' : 'poses'}</span>
                  </span>
                  <Icon name="chevron" className="h-5 w-5 shrink-0 text-ink/50" />
                </button>
              </li>
            );
          })}
        </ul>
      </div>
      <BottomNav active="home" />
    </>
  );
}
