import { MODES, SCENES, getPoses, type Mode } from '../data/poses';
import Header from '../components/Header';
import { go } from '../lib/route';

export default function Scenes({ mode }: { mode: Mode }) {
  const meta = MODES.find((m) => m.id === mode)!;
  return (
    <div className="mx-auto min-h-dvh w-full max-w-3xl pb-8">
      <Header title={`${meta.name} poses`} sub="Where are you shooting?" />
      <div className="grid grid-cols-2 gap-3 px-4 pt-2 md:grid-cols-3">
        {SCENES.map((s) => {
          const n = getPoses(mode, s.id).length;
          return (
            <button
              key={s.id}
              onClick={() => go(`poses/${mode}/${s.id}`)}
              className={`flex min-h-40 flex-col justify-between rounded-[1.75rem] p-4 text-left transition active:scale-[0.97] ${s.bg} last:col-span-2 md:last:col-span-1`}
            >
              <span className="text-5xl" aria-hidden="true">{s.emoji}</span>
              <span>
                <span className="block text-lg font-extrabold leading-tight">{s.name}</span>
                <span className="block text-sm text-ink/65">{n} {n === 1 ? 'pose' : 'poses'}</span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
