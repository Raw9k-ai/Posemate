import { MODES, SCENES, getPoses, type Mode, type SceneId } from '../data/poses';
import Header from '../components/Header';
import PoseArt from '../components/PoseArt';
import Corners from '../components/Corners';
import BottomNav from '../components/BottomNav';
import Icon from '../components/Icon';
import { go } from '../lib/route';
import { removeCustomPose } from '../data/custom';

export default function Poses({ mode, scene }: { mode: Mode; scene: SceneId }) {
  const m = MODES.find((x) => x.id === mode)!;
  const s = SCENES.find((x) => x.id === scene)!;
  const poses = getPoses(mode, scene);
  return (
    <>
      <div className="mx-auto w-full max-w-3xl pb-28">
        <Header title={s.name} sub={`${m.name} poses`} />
        {poses.length === 0 && (
          <div className="px-5 pt-8">
            <p className="text-xl font-black tracking-tight">No poses here yet</p>
            <p className="mt-1 text-ink/70">Pick another place, or make your own from a photo.</p>
            <button onClick={() => go('create')} className="btn-quiet mt-4">
              <Icon name="plus" className="h-5 w-5" /> Make a pose
            </button>
          </div>
        )}
        <ul className="grid gap-9 px-4 pt-2 md:grid-cols-2">
          {poses.map((p) => (
            <li key={p.id}>
              <div className={`relative overflow-hidden rounded-[2rem] ${s.bg}`}>
                <Corners />
                <PoseArt figures={p.figures} outlines={p.outlines} details={p.details} className="mx-auto h-60 w-full max-w-[15rem] py-5" />
              </div>
              <div className="px-1 pt-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="text-xl font-black leading-tight tracking-tight">{p.title}</h2>
                    <p className="mt-0.5 leading-snug text-ink/70">{p.steps[0]}</p>
                  </div>
                  {p.custom && <span className="shrink-0 rounded-full bg-volt px-2.5 py-0.5 text-xs font-bold">Yours</span>}
                </div>
                <button onClick={() => go('camera/' + p.id)} className="btn-primary mt-3 w-full">
                  <Icon name="camera" className="h-5 w-5" /> Try this pose
                </button>
                <details className="group mt-1">
                  <summary className="flex cursor-pointer items-center gap-1 py-2.5 text-sm font-bold text-ink/70">
                    How to pose
                    <Icon name="chevron" className="h-4 w-4 rotate-90 transition group-open:-rotate-90" />
                  </summary>
                  <ol className="list-decimal space-y-1 pl-5 leading-snug marker:font-bold">
                    {p.steps.map((st) => <li key={st}>{st}</li>)}
                  </ol>
                  {p.tip && <p className="mt-3 text-sm text-ink/70"><b>Tip:</b> {p.tip}</p>}
                  {p.custom && (
                    <button
                      onClick={() => window.confirm('Delete this pose from this device?') && removeCustomPose(p.id)}
                      className="mt-3 inline-flex items-center gap-1.5 py-2 text-sm font-bold text-rose-700"
                    >
                      <Icon name="trash" className="h-4 w-4" /> Delete this pose
                    </button>
                  )}
                </details>
              </div>
            </li>
          ))}
        </ul>
      </div>
      <BottomNav active="home" />
    </>
  );
}
