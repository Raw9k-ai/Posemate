import { MODES, SCENES, getPoses, type Mode, type SceneId } from '../data/poses';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import Icon from '../components/Icon';
import PoseCard from '../components/PoseCard';
import { go } from '../lib/route';

export default function Poses({ mode, scene }: { mode: Mode; scene: SceneId }) {
  const m = MODES.find((x) => x.id === mode)!;
  const s = SCENES.find((x) => x.id === scene)!;
  const poses = getPoses(mode, scene);
  return (
    <>
      <div className="mx-auto w-full max-w-3xl pb-28">
        <Header title={s.name} sub={`${m.name} poses`} />
        {poses.length === 0 && (
          <div className="px-5 pt-8">
            <p className="text-xl font-black tracking-tight">No poses here yet</p>
            <p className="mt-1 text-ink/70">Pick another place, or make your own from a photo.</p>
            <button onClick={() => go('create')} className="btn-quiet mt-4">
              <Icon name="plus" className="h-5 w-5" /> Make a pose
            </button>
          </div>
        )}
        <ul className="grid gap-9 px-4 pt-2 md:grid-cols-2">
          {poses.map((p) => (
            <li key={p.id}>
              <PoseCard pose={p} bg={s.bg} />
            </li>
          ))}
        </ul>
      </div>
      <BottomNav active="home" />
    </>
  );
}
