import { MODES, SCENES, getPoses, type Mode, type SceneId } from '../data/poses';
import Header from '../components/Header';
import PoseArt from '../components/PoseArt';
import Icon from '../components/Icon';
import { go } from '../lib/route';
import { removeCustomPose } from '../data/custom';

export default function Poses({ mode, scene }: { mode: Mode; scene: SceneId }) {
  const m = MODES.find((x) => x.id === mode)!;
  const s = SCENES.find((x) => x.id === scene)!;
  const poses = getPoses(mode, scene);
  return (
    <div className="mx-auto min-h-dvh w-full max-w-3xl pb-10">
      <Header title={s.name} sub={`${m.name} poses`} />
      {poses.length === 0 && <p className="px-5 pt-6 text-ink/70">No poses here yet. Try another place.</p>}
      <ul className="grid gap-4 px-4 pt-2 md:grid-cols-2">
        {poses.map((p) => (
          <li key={p.id} className="overflow-hidden rounded-[1.75rem] bg-white shadow-sm ring-1 ring-ink/5">
            <div className={`${s.bg} px-6 pt-4`}>
              <PoseArt figures={p.figures} outlines={p.outlines} className="mx-auto h-56 w-full max-w-[16rem]" />
            </div>
            <div className="p-5">
              <div className="flex items-start justify-between gap-2">
                <h2 className="text-xl font-extrabold">{p.title}</h2>
                {p.custom && <span className="shrink-0 rounded-full bg-volt px-2.5 py-0.5 text-xs font-bold">Yours</span>}
              </div>
              <ol className="mt-2 list-decimal space-y-1 pl-5 text-base leading-snug text-ink/80 marker:font-bold marker:text-ink">
                {p.steps.map((st) => <li key={st}>{st}</li>)}
              </ol>
              <p className="mt-3 rounded-2xl bg-paper px-4 py-3 text-sm text-ink/75"><b>Tip:</b> {p.tip}</p>
              <button onClick={() => go('camera/' + p.id)} className="btn mt-4 w-full bg-ink text-white">
                <Icon name="camera" className="h-5 w-5" /> Try this pose
              </button>
              {p.custom && (
                <button
                  onClick={() => window.confirm('Delete this pose from this device?') && removeCustomPose(p.id)}
                  className="btn mt-2 min-h-10 w-full bg-ink/5 text-sm"
                >
                  <Icon name="trash" className="h-4 w-4" /> Delete my pose
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
      <div className="px-4 pt-6">
        <button onClick={() => go('create')} className="btn w-full bg-ink/10">
          <Icon name="plus" className="h-5 w-5" /> Make your own pose from a photo
        </button>
      </div>
    </div>
  );
}
