import { MODES, getAllPoses } from '../data/poses';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import PoseCard from '../components/PoseCard';
import { usePrefs } from '../lib/prefs';

export default function Favorites() {
  const { favorites } = usePrefs();
  const all = getAllPoses();
  // Newest favorite first; ids of deleted poses are skipped.
  const poses = favorites.map((id) => all.find((p) => p.id === id)).filter((p): p is NonNullable<typeof p> => !!p);
  return (
    <>
      <div className="mx-auto w-full max-w-3xl pb-28">
        <Header title="Favorites" sub="Saved on this device" />
        {poses.length === 0 && (
          <div className="px-5 pt-8">
            <p className="text-xl font-black tracking-tight">No favorites yet</p>
            <p className="mt-1 text-ink/70">Tap the heart on any pose to keep it here.</p>
          </div>
        )}
        <ul className="grid gap-9 px-4 pt-2 md:grid-cols-2">
          {poses.map((p) => (
            <li key={p.id}>
              <PoseCard pose={p} bg={MODES.find((m) => m.id === p.mode)!.bg} />
            </li>
          ))}
        </ul>
      </div>
      <BottomNav active="home" />
    </>
  );
}
