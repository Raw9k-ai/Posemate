import { useEffect, useState } from 'react';
import Header from '../components/Header';
import Icon from '../components/Icon';
import PhotoWithOverlay from '../components/PhotoWithOverlay';
import { getPose } from '../data/poses';
import { deletePhoto, listPhotos, type PhotoRecord } from '../lib/db';
import { canShareFile, downloadBlob, fileName, formatBytes, shareBlob } from '../lib/files';
import { go } from '../lib/route';

interface Item { rec: PhotoRecord; thumbUrl: string }

export default function Gallery() {
  const [items, setItems] = useState<Item[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [open, setOpen] = useState<PhotoRecord | null>(null);
  const [openUrl, setOpenUrl] = useState<string | null>(null);
  const openPose = getPose(open?.poseId ?? undefined);

  useEffect(() => {
    let urls: string[] = [];
    listPhotos()
      .then((recs) => {
        const next = recs.map((rec) => ({ rec, thumbUrl: URL.createObjectURL(rec.thumb) }));
        urls = next.map((i) => i.thumbUrl);
        setItems(next);
      })
      .catch(() => setError('Saved photos could not be read. Browser storage may be blocked (for example in private browsing).'));
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
  }, []);

  useEffect(() => {
    if (!open) return;
    const u = URL.createObjectURL(open.blob);
    setOpenUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [open]);

  const remove = async (rec: PhotoRecord) => {
    if (!window.confirm('Delete this photo from this device?')) return;
    await deletePhoto(rec.id);
    setItems((cur) => cur?.filter((i) => i.rec.id !== rec.id) ?? null);
    setOpen(null);
  };

  return (
    <div className="mx-auto min-h-dvh w-full max-w-3xl pb-10">
      <Header title="My photos" sub="Stored only on this device" fallback="" />
      {error && <p role="alert" className="mx-4 rounded-2xl bg-rose-100 p-4 text-rose-900">{error}</p>}
      {items && items.length === 0 && (
        <div className="px-6 pt-12 text-center">
          <p className="text-xl font-extrabold">No photos yet</p>
          <p className="mt-1 text-ink/65">Photos you save will show up here.</p>
          <button onClick={() => go('camera')} className="btn mt-5 bg-ink text-white">Open camera</button>
        </div>
      )}
      <ul className="grid grid-cols-3 gap-1.5 px-1.5 md:grid-cols-4">
        {items?.map(({ rec, thumbUrl }) => (
          <li key={rec.id}>
            <button onClick={() => setOpen(rec)} className="block aspect-square w-full overflow-hidden rounded-xl bg-ink/10">
              <img src={thumbUrl} alt={`Photo from ${new Date(rec.createdAt).toLocaleString()}`} className="h-full w-full object-cover" loading="lazy" />
            </button>
          </li>
        ))}
      </ul>

      {open && openUrl && (
        <div className="fixed inset-0 z-20 flex flex-col bg-ink text-white">
          <div className="flex items-center justify-between px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]">
            <div>
              <p className="font-extrabold">{new Date(open.createdAt).toLocaleString()}</p>
              <p className="text-sm text-white/65">{open.width} × {open.height} · {formatBytes(open.blob.size)}</p>
            </div>
            <button onClick={() => setOpen(null)} aria-label="Close" className="cam-btn"><Icon name="close" /></button>
          </div>
          <div className="min-h-0 flex-1 bg-black">
            <PhotoWithOverlay
              url={openUrl}
              width={open.width}
              height={open.height}
              people={open.people}
              figures={openPose?.figures}
              outlines={openPose?.outlines}
              details={openPose?.details}
              overlayValid={open.overlayValid}
            />
          </div>
          <div className="flex gap-3 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3">
            <button onClick={() => downloadBlob(open.blob, fileName(open.createdAt))} className="btn flex-1 bg-volt text-ink">
              <Icon name="download" className="h-5 w-5" /> Download
            </button>
            {canShareFile(open.blob, fileName(open.createdAt)) && (
              <button
                onClick={() => shareBlob(open.blob, fileName(open.createdAt)).catch(() => undefined)}
                aria-label="Share"
                className="cam-btn h-12 w-12 bg-white/15"
              ><Icon name="share" /></button>
            )}
            <button onClick={() => remove(open)} aria-label="Delete" className="cam-btn h-12 w-12 bg-white/15">
              <Icon name="trash" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
