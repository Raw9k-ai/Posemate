import { useCallback, useEffect, useState } from 'react';
import { getAllPoses } from '../data/poses';
import { removeAllCustomPoses, useLibraryVersion } from '../data/custom';
import { clearPhotos, countPhotos } from '../lib/db';
import { resetPrefs, usePrefs } from '../lib/prefs';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import Icon from '../components/Icon';

const plural = (n: number, one: string, many = one + 's') => `${n} ${n === 1 ? one : many}`;

function Section({ title, detail, action, onAction, disabled }: { title: string; detail: string; action: string; onAction: () => void; disabled?: boolean }) {
  return (
    <li className="rounded-[1.75rem] bg-white p-5">
      <p className="text-lg font-extrabold leading-tight">{title}</p>
      <p className="mt-1 text-ink/70">{detail}</p>
      <button onClick={onAction} disabled={disabled} className="btn mt-3 w-full bg-rose-100 text-rose-800 disabled:opacity-40">
        <Icon name="trash" className="h-5 w-5" /> {action}
      </button>
    </li>
  );
}

export default function Privacy() {
  useLibraryVersion(); // re-render when your poses change
  const favorites = usePrefs().favorites.length;
  const poses = getAllPoses().filter((p) => p.custom).length;
  const withGhost = getAllPoses().filter((p) => p.custom && p.ghostPhotos?.some(Boolean)).length;

  const [photos, setPhotos] = useState<number | null>(null); // null = not known yet or storage unavailable
  const [unavailable, setUnavailable] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    try {
      setPhotos(await countPhotos());
      setUnavailable(false);
    } catch {
      setUnavailable(true); // for example private browsing with storage blocked
    }
  }, []);
  useEffect(() => {
    void refresh();
  }, [refresh]);

  const run = async (question: string, message: string, work: () => Promise<void> | void) => {
    if (busy || !window.confirm(question)) return;
    setBusy(true);
    try {
      await work();
      setDone(message);
    } catch {
      setDone('Something went wrong, and nothing was deleted. Try again.');
    } finally {
      await refresh();
      setBusy(false);
    }
  };

  const deletePhotos = () => run('Delete all saved photos from this device? This cannot be undone.', 'All photos deleted.', clearPhotos);
  const deletePoses = () => run('Delete all poses you made from photos, including any photo ghosts? This cannot be undone.', 'Your poses deleted.', removeAllCustomPoses);
  const resetSettings = () => run('Remove all favorites and reset settings?', 'Favorites and settings reset.', resetPrefs);
  const deleteAll = () =>
    run(
      'Delete all photos, your poses, favorites and settings from this device? This cannot be undone.',
      'Everything deleted. PoseMate is back to a fresh start.',
      async () => {
        await clearPhotos();
        await removeAllCustomPoses();
        resetPrefs();
      },
    );

  const photoDetail = unavailable ? 'This browser is not letting PoseMate save anything right now, so there is nothing to delete.' : photos === null ? 'Checking…' : `${plural(photos, 'photo')} saved in My photos.`;

  return (
    <>
      <div className="mx-auto w-full max-w-3xl pb-28">
        <Header title="Privacy and data" sub="Everything stays on this phone" />
        <div className="px-5 pt-1">
          <p className="max-w-md leading-snug text-ink/70">
            PoseMate does not upload your photos, camera view or poses, and has no account or tracking. What it keeps is listed below, and you can delete any of it here.
          </p>
        </div>

        {done && <p role="status" className="mx-4 mt-4 rounded-2xl bg-volt px-4 py-3 font-bold">{done}</p>}

        <ul className="mt-4 grid gap-3 px-4 md:grid-cols-2">
          <Section title="Photos" detail={photoDetail} action="Delete all photos" onAction={deletePhotos} disabled={busy || unavailable || !photos} />
          <Section
            title="Poses you made"
            detail={poses === 0 ? 'None saved.' : `${plural(poses, 'pose')} made from photos${withGhost > 0 ? `, ${plural(withGhost, 'with a photo ghost', 'with photo ghosts')} (a small cut-out of the person)` : ''}.`}
            action="Delete my poses"
            onAction={deletePoses}
            disabled={busy || unavailable || poses === 0}
          />
          <Section
            title="Favorites and settings"
            detail={`${plural(favorites, 'favorite')}, plus your guide, sound and battery settings.`}
            action="Reset favorites and settings"
            onAction={resetSettings}
            disabled={busy}
          />
          <li className="rounded-[1.75rem] bg-ink p-5 text-white">
            <p className="text-lg font-extrabold leading-tight">Delete everything</p>
            <p className="mt-1 text-white/75">Photos, your poses, favorites and settings, all at once.</p>
            <button onClick={deleteAll} disabled={busy} className="btn mt-3 w-full bg-rose-500 text-white disabled:opacity-40">
              <Icon name="trash" className="h-5 w-5" /> Delete everything
            </button>
          </li>
        </ul>

        <p className="mt-6 max-w-md px-5 text-sm leading-snug text-ink/60">
          The app files and pose model saved for offline use (about 20 MB) are not personal data and stay. To remove them, clear this site&rsquo;s data in your browser settings.
        </p>
      </div>
      <BottomNav active="home" />
    </>
  );
}
