import { useRef, useState, type ReactNode } from 'react';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import Icon, { ICON_NAMES, type IconName } from '../components/Icon';
import { Row, Segmented } from '../components/Controls';
import { go } from '../lib/route';
import {
  COLOR_KEYS, COLOR_LABELS, CUSTOM_FONT_ID, DEFAULT_COLORS, FONTS, PRESETS, TEXT_SCALE_MAX, TEXT_SCALE_MIN,
  colorOf, contrastRatio, exportUi, importUi, resetUi, saveCustomFont, updateUi, useUi, withEl, withIcon, withText,
  type ColorKey, type Corner, type ElRule,
} from '../lib/ui';
import { readFontFile, readImage } from '../ui/theme';
import { setEditing } from '../ui/editing';

const Card = ({ title, children }: { title: string; children: ReactNode }) => (
  <section className="rounded-[1.75rem] bg-white p-5">
    <h2 className="mb-3 text-lg font-black tracking-tight">{title}</h2>
    <div className="space-y-4">{children}</div>
  </section>
);

const pill = 'rounded-full bg-ink/10 px-4 py-2 text-sm font-bold active:scale-95';

export default function Customize() {
  const ui = useUi();
  const [msg, setMsg] = useState<string | null>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const say = (m: string) => setMsg(m);
  const saved = (ok: boolean, m = 'Saved') => say(ok ? m : 'There is not enough space to save that. Try smaller pictures, or remove some changes.');

  const pickImage = (kind: 'icon' | 'bg', then: (url: string) => void) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async () => {
      const f = input.files?.[0];
      if (!f) return;
      const url = await readImage(f, kind);
      if (!url) return say('That file could not be used as a picture.');
      then(url);
    };
    input.click();
  };

  const contrast = contrastRatio(colorOf(ui, 'ink'), colorOf(ui, 'paper'));
  const textRules = Object.entries(ui.texts) as [string, string][];
  const elRules = Object.entries(ui.els) as [string, ElRule][];

  return (
    <>
      <Header title="Customize" sub="Make the app look and read your way" fallback="" />
      <main className="mx-auto w-full max-w-3xl space-y-4 px-4 pb-32 pt-2">
        {msg && <p role="status" className="rounded-2xl bg-volt px-4 py-2.5 text-sm font-bold text-ink">{msg}</p>}

        <Card title="Change anything on screen">
          <p className="text-ink/70">Tap any text, button or heading to rename it, give it a colour or a picture, swap its icon, or hide it. It changes everywhere that wording appears.</p>
          <button data-no-hide onClick={() => { setEditing(true); go(''); }} className="btn-primary w-full">Start editing the screen</button>
        </Card>

        <Card title="Colors">
          <div className="flex flex-wrap gap-2">
            {PRESETS.map((p) => (
              <button key={p.id} onClick={() => saved(updateUi((s) => ({ ...s, colors: { ...p.colors } })), p.name + ' colors on')} className={pill}>
                <span className="mr-2 inline-flex -space-x-1 align-middle">
                  {(['paper', 'ink', 'cobalt', 'volt'] as ColorKey[]).map((k) => (
                    <span key={k} className="h-4 w-4 rounded-full ring-1 ring-ink/20" style={{ background: p.colors[k] ?? DEFAULT_COLORS[k] }} />
                  ))}
                </span>
                {p.name}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-1 gap-3">
            {COLOR_KEYS.map((k) => (
              <label key={k} className="flex items-center gap-3">
                <input
                  type="color"
                  value={colorOf(ui, k)}
                  onChange={(e) => updateUi((s) => ({ ...s, colors: { ...s.colors, [k]: e.target.value } }))}
                  aria-label={COLOR_LABELS[k]}
                  className="h-10 w-12 shrink-0 rounded-lg"
                />
                <span className="flex-1 font-bold">{COLOR_LABELS[k]}</span>
                {ui.colors[k] && <button type="button" onClick={() => updateUi((s) => { const c = { ...s.colors }; delete c[k]; return { ...s, colors: c }; })} className="text-sm font-bold text-ink/70 underline">Reset</button>}
              </label>
            ))}
          </div>
          {contrast < 4.5 && <p role="alert" className="rounded-xl bg-amber-100 px-3 py-2 text-sm font-medium text-amber-900">Text and background are close in color, so the app may be hard to read. Pick a darker text color or a lighter background.</p>}
        </Card>

        <Card title="Font and size">
          <div className="space-y-2" role="radiogroup" aria-label="Font">
            {FONTS.map((f) => (
              <button key={f.id} role="radio" aria-checked={ui.font === f.id} onClick={() => updateUi((s) => ({ ...s, font: f.id }))} style={{ fontFamily: f.stack }} className={`flex w-full items-center justify-between rounded-2xl px-4 py-3 text-left text-lg ${ui.font === f.id ? 'bg-ink text-white' : 'bg-ink/5'}`}>
                <span>{f.name}: Pick a pose, line up, shoot</span>
              </button>
            ))}
            {ui.font === CUSTOM_FONT_ID && (
              <div className="rounded-2xl bg-ink px-4 py-3 text-lg text-white" role="radio" aria-checked="true">Your font: {ui.fontName ?? 'custom'}</div>
            )}
          </div>
          <button
            onClick={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = '.ttf,.otf,.woff,.woff2,font/*';
              input.onchange = async () => {
                const f = input.files?.[0];
                if (!f) return;
                const url = await readFontFile(f);
                if (!url) return say('That file is not a font, or it is over 2 MB. Use a .ttf, .otf or .woff file.');
                if (!saveCustomFont(url)) return say('There is not enough space to keep that font.');
                saved(updateUi((s) => ({ ...s, font: CUSTOM_FONT_ID, fontName: f.name.replace(/\.[^.]+$/, '') })), 'Font added');
              };
              input.click();
            }}
            className={pill}
          >
            Use a font file from my phone
          </button>
          <Row label="Text size" hint={`${Math.round(ui.textScale * 100)}% of normal`}>
            <input
              type="range" min={TEXT_SCALE_MIN} max={TEXT_SCALE_MAX} step={0.05} value={ui.textScale}
              onChange={(e) => updateUi((s) => ({ ...s, textScale: Number(e.target.value) }))}
              aria-label="Text size" className="w-36"
            />
          </Row>
          <div>
            <p className="mb-2 font-bold">Corners</p>
            <Segmented label="Corners" value={ui.corner} onChange={(v: Corner) => updateUi((s) => ({ ...s, corner: v }))} options={[['Round', 'round'], ['Soft', 'soft'], ['Square', 'square']] as const} />
          </div>
        </Card>

        <Card title="Icons">
          <p className="text-ink/70">Swap any icon for your own picture or an emoji. This includes the camera screen's buttons and the shutter.</p>
          <ul className="space-y-3">
            {ICON_NAMES.map((name: IconName) => (
              <li key={name} className="flex items-center gap-3">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-ink text-white"><Icon name={name} className="h-7 w-7" /></span>
                <span className="min-w-0 flex-1 truncate font-bold capitalize">{name === 'shutter' ? 'Shutter button' : name}</span>
                <button className={pill} onClick={() => pickImage('icon', (url) => saved(updateUi((s) => withIcon(s, name, { kind: 'image', src: url }))))}>Picture</button>
                <button className={pill} onClick={() => { const t = window.prompt('Type one emoji or letter', ''); if (t && t.trim()) saved(updateUi((s) => withIcon(s, name, { kind: 'emoji', text: t.trim().slice(0, 4) }))); }}>Emoji</button>
                {ui.icons[name] && <button className={pill} onClick={() => updateUi((s) => withIcon(s, name, null))}>Reset</button>}
              </li>
            ))}
          </ul>
        </Card>

        <Card title="Your changes">
          {textRules.length === 0 && elRules.length === 0 && <p className="text-ink/70">Nothing renamed, recolored or hidden yet.</p>}
          <ul className="space-y-2">
            {textRules.map(([from, to]) => (
              <li key={'t' + from} className="flex items-center gap-3 rounded-2xl bg-ink/5 px-4 py-2.5">
                <span className="min-w-0 flex-1 text-sm"><span className="text-ink/60">{from}</span> → <span className="font-bold">{to}</span></span>
                <button className="text-sm font-bold underline" onClick={() => updateUi((s) => withText(s, from, ''))}>Undo</button>
              </li>
            ))}
            {elRules.map(([key, r]) => (
              <li key={'e' + key} className="flex items-center gap-3 rounded-2xl bg-ink/5 px-4 py-2.5">
                <span className="min-w-0 flex-1 text-sm">
                  <span className="font-bold">{key.slice(2)}</span>{' '}
                  <span className="text-ink/60">{[r.hidden && 'hidden', r.bg && 'background', r.fg && 'text color', r.image && 'picture'].filter(Boolean).join(', ')}</span>
                </span>
                <button className="text-sm font-bold underline" onClick={() => updateUi((s) => withEl(s, key, null))}>{r.hidden ? 'Show again' : 'Undo'}</button>
              </li>
            ))}
          </ul>
        </Card>

        <Card title="Back up or start over">
          <div className="flex flex-wrap gap-2">
            <button
              className={pill}
              onClick={() => {
                const url = URL.createObjectURL(new Blob([exportUi()], { type: 'application/json' }));
                const a = document.createElement('a');
                a.href = url;
                a.download = 'posemate-look.json';
                a.click();
                setTimeout(() => URL.revokeObjectURL(url), 2000);
              }}
            >
              Save my look to a file
            </button>
            <button className={pill} onClick={() => importRef.current?.click()}>Load a saved look</button>
            <input
              ref={importRef} type="file" accept="application/json,.json" className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                e.target.value = '';
                if (f) say(importUi(await f.text()) ? 'Look loaded' : 'That file is not a PoseMate look, or it is too big to keep.');
              }}
            />
            <button className={`${pill} !bg-rose-100 !text-rose-800`} onClick={() => { if (window.confirm('Put every color, font, icon and wording back to the original?')) { resetUi(); say('Back to the original look'); } }}>Reset everything</button>
          </div>
        </Card>
      </main>
      <BottomNav active="home" />
    </>
  );
}
