import { useEffect, useMemo, useRef, useState } from 'react';
import type { Mode } from '../data/poses';
import Header from '../components/Header';
import { Row, Segmented, Switch } from '../components/Controls';
import { analyzePhoto, composePose } from '../lib/createPose';
import { makeCutouts } from '../lib/cutout';
import { partStrokes, type DetailLevel } from '../lib/parts';
import { loadStillDetector } from '../lib/pose';
import { ACCURACY_INFO, withFallback, type Accuracy } from '../lib/accuracy';
import {
  buildPackPose, defaultTitle, fileKey, fmtBytes, judge, naturalCompare, packEntries, parseSheet, reportCsv,
  sheetTemplate, uniqueId, type GhostFile, type PackPose, type SheetRow, type Verdict,
} from '../lib/packs';
import { zipStore } from '../lib/zip';

// Admin tool: turns a folder of reference photos into a pose pack (poses.json + small cut-out images).
// Open it at  #/batch  in desktop Chrome. Not linked anywhere in the app. Everything runs on this computer.

interface Item {
  key: string;
  file: File;
  id: string;
  state: 'wait' | 'busy' | Verdict;
  note: string;
  people: number;
  title: string;
  include: boolean;
  pose?: PackPose;
  ghosts: GhostFile[];
  ghostBytes: number;
  thumb?: string;
}

const MODE_OPTIONS = [['Solo', 'solo'], ['Couple', 'couple'], ['Group', 'group']] as const;
const MODEL_OPTIONS = [['Lite', 'lite'], ['Full', 'full'], ['Heavy', 'heavy']] as const;
const SIZE_OPTIONS = [['Small 256', 256], ['Medium 384', 384], ['Large 512', 512]] as const;
const LINE_OPTIONS = [['Off', 0], ['Simple', 1], ['Detailed', 2]] as const;

const isImage = (f: File) => f.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|bmp)$/i.test(f.name);
const tick = () => new Promise<void>((r) => setTimeout(r, 0));

function save(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

export default function Batch() {
  const [mode, setMode] = useState<Mode>('solo');
  const [model, setModel] = useState<Accuracy>('full');
  const [maxSide, setMaxSide] = useState<number>(384);
  const [lines, setLines] = useState<DetailLevel>(1);
  const [flip, setFlip] = useState(false);
  const [items, setItems] = useState<Item[]>([]);
  const [sheet, setSheet] = useState<Map<string, SheetRow>>(new Map());
  const [sheetNote, setSheetNote] = useState<string[]>([]);
  const [running, setRunning] = useState(false);
  const [modelNote, setModelNote] = useState<string | null>(null);
  const [fatal, setFatal] = useState<string | null>(null);
  const [onlyProblems, setOnlyProblems] = useState(false);
  const [busyZip, setBusyZip] = useState(false);
  const stop = useRef(false);
  const thumbs = useRef<string[]>([]);

  const dropThumbs = () => {
    thumbs.current.forEach((u) => URL.revokeObjectURL(u));
    thumbs.current = [];
  };
  useEffect(() => () => dropThumbs(), []);

  const patch = (key: string, p: Partial<Item>) => setItems((prev) => prev.map((it) => (it.key === key ? { ...it, ...p } : it)));

  // ---------- choosing photos and the optional sheet ----------
  const onPhotos = (list: FileList | null) => {
    if (!list) return;
    dropThumbs();
    const files = Array.from(list).filter(isImage).sort((a, b) => naturalCompare(a.name, b.name));
    const used = new Set<string>();
    setItems(
      files.map((file, i) => ({
        key: `${i}-${file.name}`,
        file,
        id: uniqueId(mode, file.name, used),
        state: 'wait',
        note: '',
        people: 0,
        title: '',
        include: true,
        ghosts: [],
        ghostBytes: 0,
      })),
    );
    setFatal(null);
  };

  const onSheet = async (list: FileList | null) => {
    const f = list?.[0];
    if (!f) return;
    const { rows, warnings } = parseSheet(await f.text());
    setSheet(rows);
    setSheetNote(warnings);
  };

  // changing the mode renames ids ("pk-solo-001" -> "pk-couple-001") and clears results
  useEffect(() => {
    dropThumbs();
    setItems((prev) => {
      const used = new Set<string>();
      return prev.map((it) => ({ ...it, id: uniqueId(mode, it.file.name, used), state: 'wait', note: '', pose: undefined, ghosts: [], ghostBytes: 0, thumb: undefined, people: 0, title: '' }));
    });
  }, [mode]);

  // ---------- processing ----------
  const run = async () => {
    if (running || items.length === 0) return;
    stop.current = false;
    setRunning(true);
    setFatal(null);
    setModelNote(null);
    dropThumbs();
    setItems((prev) => prev.map((it) => ({ ...it, state: 'wait', note: '', pose: undefined, ghosts: [], ghostBytes: 0, thumb: undefined, people: 0, title: '' })));

    let acc: Accuracy = model;
    try {
      const r = await withFallback(model, loadStillDetector);
      acc = r.used;
      if (r.failed) setModelNote(`The ${ACCURACY_INFO[r.failed.accuracy].label} model could not be loaded, so Lite is used. (${r.failed.message})`);
    } catch (e) {
      setFatal(e instanceof Error ? e.message : 'The pose model could not be loaded.');
      setRunning(false);
      return;
    }

    for (const it of items) {
      if (stop.current) break;
      patch(it.key, { state: 'busy' });
      await tick();
      try {
        const row = sheet.get(fileKey(it.file.name));
        const a = await analyzePhoto(it.file, acc);
        try {
          const strokes = partStrokes(a.persons, a.grids, lines);
          const cuts = await makeCutouts(a.source, a.grids, maxSide, 0.8);
          const verdict = judge({ mode, people: a.persons.length, boxes: cuts.map((c) => (c ? c.box : null)), partial: a.partial });
          if (verdict.status === 'failed') {
            patch(it.key, { state: 'failed', note: verdict.note, people: a.persons.length, include: false });
            continue;
          }
          const composed = composePose(a, flip, strokes, cuts);
          const title = row?.name || defaultTitle(it.file.name);
          const built = buildPackPose({ id: it.id, title, mode, moods: row?.moods, steps: row?.steps, tip: row?.tip }, composed);
          const ghostBytes = built.ghosts.reduce((n, g) => n + g.blob.size, 0);
          let thumb: string | undefined;
          if (built.ghosts[0]) {
            thumb = URL.createObjectURL(built.ghosts[0].blob);
            thumbs.current.push(thumb);
          }
          patch(it.key, {
            state: verdict.status,
            note: verdict.note,
            people: a.persons.length,
            title,
            pose: built.pose,
            ghosts: built.ghosts,
            ghostBytes,
            thumb,
            include: true,
          });
        } finally {
          URL.revokeObjectURL(a.url);
        }
      } catch (e) {
        patch(it.key, { state: 'failed', note: e instanceof Error ? e.message : 'Could not be processed', include: false });
      }
    }
    setRunning(false);
  };

  // ---------- numbers shown on screen ----------
  const stats = useMemo(() => {
    const done = items.filter((i) => i.state === 'ok' || i.state === 'check' || i.state === 'failed').length;
    const ok = items.filter((i) => i.state === 'ok').length;
    const check = items.filter((i) => i.state === 'check').length;
    const failed = items.filter((i) => i.state === 'failed').length;
    const chosen = items.filter((i) => i.include && i.pose);
    const ghostBytes = chosen.reduce((n, i) => n + i.ghostBytes, 0);
    return { done, ok, check, failed, chosen: chosen.length, ghostBytes };
  }, [items]);

  const shown = onlyProblems ? items.filter((i) => i.state === 'check' || i.state === 'failed') : items;

  // ---------- export ----------
  const exportZip = async () => {
    const chosen = items.filter((i) => i.include && i.pose);
    if (chosen.length === 0) return;
    setBusyZip(true);
    try {
      const { entries, manifest } = packEntries(mode, chosen.map((i) => ({ pose: i.pose!, ghosts: i.ghosts })));
      const blob = await zipStore(entries);
      save(blob, `posemate-${mode}-pack.zip`);
      setModelNote(`Saved ${manifest.count} poses, ${manifest.ghostCount} cut-outs, ${fmtBytes(manifest.totalBytes)} in total. Unzip it into your project's public folder.`);
    } catch (e) {
      setFatal(e instanceof Error ? e.message : 'The zip could not be made.');
    } finally {
      setBusyZip(false);
    }
  };

  const exportReport = () =>
    save(
      new Blob([reportCsv(items.map((i) => ({ file: i.file.name, status: i.state, people: i.people, title: i.title, note: i.note, included: i.include && !!i.pose, ghostBytes: i.ghostBytes })))], { type: 'text/csv' }),
      `posemate-${mode}-report.csv`,
    );

  const downloadTemplate = () => save(new Blob([sheetTemplate(items.map((i) => i.file.name))], { type: 'text/csv' }), `posemate-${mode}-sheet.csv`);

  const chip: Record<Item['state'], string> = {
    wait: 'bg-ink/10 text-ink/70',
    busy: 'bg-sun text-ink',
    ok: 'bg-mint text-ink',
    check: 'bg-sun text-ink',
    failed: 'bg-rose-100 text-rose-800',
  };
  const chipText: Record<Item['state'], string> = { wait: 'Waiting', busy: 'Working…', ok: 'Good', check: 'Check', failed: 'Failed' };

  return (
    <div className="mx-auto min-h-full max-w-3xl pb-16">
      <Header title="Pose pack builder" sub="Admin tool, not linked from the app" fallback="" />
      <div className="space-y-4 px-4">
        <section className="space-y-4 rounded-[1.75rem] bg-white p-5">
          <h2 className="text-lg font-extrabold">1. Settings</h2>
          <div>
            <p className="mb-2 font-bold">Pack</p>
            <Segmented label="Pack" value={mode} options={MODE_OPTIONS} onChange={setMode} />
            <p className="mt-1 text-sm text-ink/60">One run builds one pack. Solo needs 1 person per photo, couple 2, group 3 to 5.</p>
          </div>
          <div>
            <p className="mb-2 font-bold">Detection model</p>
            <Segmented label="Detection model" value={model} options={MODEL_OPTIONS} onChange={setModel} />
            <p className="mt-1 text-sm text-ink/60">Full or Heavy find joints and outlines better than Lite. If that model is missing on this site, Lite is used and you will see a note.</p>
          </div>
          <div>
            <p className="mb-2 font-bold">Cut-out size (long side, pixels)</p>
            <Segmented label="Cut-out size" value={maxSide} options={SIZE_OPTIONS} onChange={setMaxSide} />
            <p className="mt-1 text-sm text-ink/60">The cut-out is only a faded guide on the camera, so Small or Medium is usually enough and keeps the pack light.</p>
          </div>
          <div>
            <p className="mb-2 font-bold">Body-part lines</p>
            <Segmented label="Body-part lines" value={lines} options={LINE_OPTIONS} onChange={setLines} />
          </div>
          <Row label="Mirror every pose" hint="Flip left and right. Normally off.">
            <Switch checked={flip} onChange={setFlip} label="Mirror every pose" />
          </Row>
        </section>

        <section className="space-y-3 rounded-[1.75rem] bg-white p-5">
          <h2 className="text-lg font-extrabold">2. Photos and names</h2>
          <label className="btn-primary w-full cursor-pointer">
            Choose photos
            <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { onPhotos(e.target.files); e.target.value = ''; }} />
          </label>
          <label className="btn-quiet w-full cursor-pointer">
            Choose a whole folder
            <input
              type="file"
              multiple
              className="hidden"
              ref={(el) => el?.setAttribute('webkitdirectory', '')}
              onChange={(e) => { onPhotos(e.target.files); e.target.value = ''; }}
            />
          </label>
          <p className="text-sm text-ink/60">JPEG, PNG or WebP. iPhone HEIC photos will fail in Chrome: export them as JPEG first.</p>
          <p className="font-bold">{items.length} {items.length === 1 ? 'photo' : 'photos'} chosen</p>
          <hr className="border-ink/10" />
          <p className="text-sm text-ink/70">Optional sheet (CSV) with a name, mood, tip and steps for each photo. Columns: <b>file, name, mood, tip, steps</b>. Moods: confident, playful, cozy, elegant, candid. Separate steps with <b>|</b>. Photos without a row get a name from the file name and generic steps.</p>
          <div className="flex flex-wrap gap-2">
            <label className="btn-quiet cursor-pointer">
              Choose sheet (.csv)
              <input type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => { void onSheet(e.target.files); e.target.value = ''; }} />
            </label>
            <button onClick={downloadTemplate} disabled={items.length === 0} className="btn-quiet disabled:opacity-40">Get a blank sheet</button>
          </div>
          {sheet.size > 0 && <p className="text-sm font-bold text-ink/70">{sheet.size} rows loaded, {items.filter((i) => sheet.has(fileKey(i.file.name))).length} match your photos.</p>}
          {sheetNote.length > 0 && (
            <ul className="list-disc space-y-1 pl-5 text-sm text-rose-800">
              {sheetNote.slice(0, 8).map((w, i) => <li key={i}>{w}</li>)}
              {sheetNote.length > 8 && <li>…and {sheetNote.length - 8} more</li>}
            </ul>
          )}
        </section>

        <section className="space-y-3 rounded-[1.75rem] bg-white p-5">
          <h2 className="text-lg font-extrabold">3. Run</h2>
          <div className="flex gap-2">
            <button onClick={() => void run()} disabled={running || items.length === 0} className="btn-primary flex-1 disabled:opacity-40">
              {stats.done > 0 && !running ? 'Run again' : 'Start'}
            </button>
            <button onClick={() => { stop.current = true; }} disabled={!running} className="btn-quiet disabled:opacity-40">Stop</button>
          </div>
          {items.length > 0 && (
            <>
              <div className="h-3 overflow-hidden rounded-full bg-ink/10" role="progressbar" aria-valuemin={0} aria-valuemax={items.length} aria-valuenow={stats.done}>
                <div className="h-full bg-cobalt transition-all" style={{ width: `${(stats.done / items.length) * 100}%` }} />
              </div>
              <p className="text-sm font-bold">
                {stats.done} of {items.length} done · {stats.ok} good · {stats.check} to check · {stats.failed} failed
              </p>
            </>
          )}
          {modelNote && <p className="rounded-2xl bg-sun/40 p-3 text-sm">{modelNote}</p>}
          {fatal && <p className="rounded-2xl bg-rose-100 p-3 text-sm text-rose-800">{fatal}</p>}
        </section>

        {items.length > 0 && (
          <section className="space-y-3 rounded-[1.75rem] bg-white p-5">
            <h2 className="text-lg font-extrabold">4. Check the results</h2>
            <Row label="Only show problems" hint="Photos marked Check or Failed">
              <Switch checked={onlyProblems} onChange={setOnlyProblems} label="Only show problems" />
            </Row>
            <ul className="divide-y divide-ink/10">
              {shown.map((it) => (
                <li key={it.key} className="flex items-center gap-3 py-3">
                  <div className="grid h-16 w-12 shrink-0 place-items-center overflow-hidden rounded-xl bg-ink/10">
                    {it.thumb ? <img src={it.thumb} alt="" className="h-full w-full object-contain" /> : <span className="text-xs text-ink/40">—</span>}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-bold">{it.title || it.file.name}</p>
                    <p className="truncate text-sm text-ink/60">{it.file.name}{it.people > 0 ? ` · ${it.people} ${it.people === 1 ? 'person' : 'people'}` : ''}{it.ghostBytes ? ` · ${fmtBytes(it.ghostBytes)}` : ''}</p>
                    {it.note && <p className="text-sm text-ink/80">{it.note}</p>}
                  </div>
                  <span className={`shrink-0 rounded-full px-3 py-1 text-xs font-bold ${chip[it.state]}`}>{chipText[it.state]}</span>
                  <input
                    type="checkbox"
                    aria-label={`Include ${it.file.name}`}
                    className="h-6 w-6 shrink-0"
                    checked={it.include && !!it.pose}
                    disabled={!it.pose}
                    onChange={(e) => patch(it.key, { include: e.target.checked })}
                  />
                </li>
              ))}
              {shown.length === 0 && <li className="py-3 text-ink/60">Nothing to show.</li>}
            </ul>
          </section>
        )}

        {stats.chosen > 0 && (
          <section className="space-y-3 rounded-[1.75rem] bg-white p-5">
            <h2 className="text-lg font-extrabold">5. Export</h2>
            <p>
              <b>{stats.chosen}</b> poses selected · cut-outs about <b>{fmtBytes(stats.ghostBytes)}</b> (average {fmtBytes(Math.round(stats.ghostBytes / stats.chosen))} per pose).
            </p>
            {stats.ghostBytes / stats.chosen > 120 * 1024 && <p className="text-sm text-rose-800">That is heavy per pose. Try a smaller cut-out size.</p>}
            <button onClick={() => void exportZip()} disabled={busyZip} className="btn-primary w-full disabled:opacity-40">{busyZip ? 'Making the zip…' : 'Download pack (.zip)'}</button>
            <button onClick={exportReport} className="btn-quiet w-full">Download report (.csv)</button>
            <p className="text-sm text-ink/60">Unzip into your project's <b>public</b> folder so you get <b>public/packs/{mode}/…</b>, then build and deploy as usual. Failed photos are left out. Fix or replace them and run again.</p>
          </section>
        )}
      </div>
    </div>
  );
}
