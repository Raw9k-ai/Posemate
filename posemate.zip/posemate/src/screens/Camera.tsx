import { useEffect, useRef, useState } from 'react';
import { getPose } from '../data/poses';
import { back } from '../lib/route';
import { takeBestPhoto } from '../lib/camera';
import { ACCURACY_INFO, type Accuracy } from '../lib/accuracy';
import type { Person } from '../lib/draw';
import { matchLabel, matchScore } from '../lib/match';
import { buzz, primeAudio, shutterSound, tickSound, useLowBattery, useTilt, useWakeLock } from '../lib/device';
import { LIGHT_TIPS } from '../lib/light';
import { pushRecent, setPref, usePrefs } from '../lib/prefs';
import { BURST_FRAMES_LIGHT, BURST_MAX_EDGE_LIGHT } from '../lib/perf';
import { useLightMode } from '../lib/useLightMode';
import Icon from '../components/Icon';
import LevelLine from '../components/LevelLine';
import HeartButton from '../components/HeartButton';
import PoseArt from '../components/PoseArt';
import Preview, { type Shot } from '../components/Preview';
import BurstPicker from '../components/BurstPicker';
import { BURST_COUNT, bestIndex, captureBurst, scoreFrames, type BurstFrame } from '../lib/burst';
import { GHOST, type LiveState } from '../camera/constants';
import { useGuideGestures } from '../camera/useGuideGestures';
import { IDENTITY, type GuideAdjust } from '../lib/guideAdjust';
import { useEditing } from '../ui/editing';
import { useIconOverride } from '../lib/ui';
import { useCameraStream } from '../camera/useCameraStream';
import { useDetector } from '../camera/useDetector';
import { useGuideOptions } from '../camera/useGuideOptions';
import { useDetectionLoop } from '../camera/useDetectionLoop';
import GuideSettings from '../camera/GuideSettings';
import PoseSheet from '../camera/PoseSheet';
import LightDebugPanel from '../camera/LightDebugPanel';

const LIVE_DEFAULTS: LiveState = { showSkeleton: true, showGuide: true, showDetail: true, follow: false, ghost: GHOST[2], ghostPhotos: undefined, figures: undefined, outlines: undefined, details: undefined, paused: false, autoSnap: false, sound: true, idle: true, saver: false, light: false, lightTips: true, lightDebug: false, poseTips: true };

export default function CameraScreen({ poseId }: { poseId?: string }) {
  const pose = getPose(poseId);
  const prefs = usePrefs();
  const light = useLightMode(); // slower phone: fewer burst frames, smaller frames, lighter visuals
  const autoOk = !!pose && pose.figures.length === 1; // match score exists for solo poses only
  useWakeLock(prefs.keepAwake);
  const battery = useLowBattery();
  const saverOn = prefs.saver === 'on' || (prefs.saver === 'auto' && battery.low);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const peopleRef = useRef<Person[]>([]);
  const busyRef = useRef(false);
  const captureRef = useRef<() => void>(() => {});
  const adjRef = useRef<GuideAdjust>(IDENTITY); // the person's own move/resize of the guide
  const redrawRef = useRef<(() => void) | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const [adjusted, setAdjusted] = useState(false);
  const editing = useEditing();
  const shutterIcon = useIconOverride('shutter') !== null; // the person gave the shutter their own picture
  // Latest values for the animation loop, which must not restart on every change.
  const live = useRef<LiveState>(LIVE_DEFAULTS);

  // Remember the pose so Home can offer it again.
  useEffect(() => {
    if (pose) pushRecent(pose.id);
    adjRef.current = IDENTITY; // a new pose starts in its default place
    setAdjusted(false);
  }, [pose?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const cam = useCameraStream(pose?.mode === 'solo' ? 'user' : 'environment');
  const { videoRef, sessionRef, facing, setFacing, status, camError, camDetail, info } = cam;
  const tiltInfo = useTilt(prefs.levelLine, facing); // the phone's tilt, for the level line

  // Battery saver always uses the Lite model; otherwise the Accuracy setting decides.
  const wantAcc: Accuracy = saverOn ? 'lite' : prefs.accuracy;
  const d = useDetector(wantAcc, pose);
  const { detRef, det, detMsg, loadingAcc } = d;
  const g = useGuideOptions(pose, live);

  const timer = prefs.timer; // remembered between visits
  const setTimer = (f: (t: 0 | 3 | 5 | 10) => 0 | 3 | 5 | 10) => setPref('timer', f(prefs.timer));
  const [countdown, setCountdown] = useState<number | null>(null);
  const [flash, setFlash] = useState(0);
  const [sheet, setSheet] = useState(false);
  const [tune, setTune] = useState(false);
  const [steps, setSteps] = useState(false);
  const [shot, setShot] = useState<Shot | null>(null);
  const [burstProg, setBurstProg] = useState<number | null>(null); // frames taken so far while a burst runs
  const [burst, setBurst] = useState<{ frames: BurstFrame[]; scores: number[]; best: number; mirrored: boolean; at: number } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  live.current = {
    showSkeleton: g.showSkeleton, showGuide: g.showGuide, showDetail: g.showDetail, ghost: GHOST[g.ghostLevel],
    ghostPhotos: g.photoGhost ? g.ghostBitmaps : undefined,
    figures: pose?.figures, outlines: pose?.outlines, details: pose?.details,
    paused: shot !== null || burst !== null,
    autoSnap: autoOk && prefs.autoSnap && burst === null,
    sound: prefs.sound,
    idle: countdown === null && shot === null && burst === null && burstProg === null,
    follow: prefs.follow, saver: saverOn, light, lightTips: prefs.lightTips, lightDebug: prefs.lightDebug, poseTips: prefs.poseTips,
  };

  const { peopleCount, match, hold, fps, eased, lightTip, lightReading, lightLog, poseHint, dismissLightTip } = useDetectionLoop({
    status, videoRef, canvasRef, detRef, peopleRef, live, captureRef, adjRef, redrawRef, onDetectorFailed: d.fail,
  });

  useGuideGestures({
    enabled: !!pose && g.showGuide && prefs.guideMove && !editing && shot === null && burst === null,
    boxRef, videoRef, adjRef, redrawRef, mirrored: info?.mirrored ?? facing === 'user', onAdjusted: setAdjusted,
  });

  const resetGuide = () => {
    adjRef.current = IDENTITY;
    setAdjusted(false);
    redrawRef.current?.();
  };

  // ---- capture ----
  const capture = async () => {
    const v = videoRef.current;
    const s = sessionRef.current;
    if (!v || !s || busyRef.current) return;
    busyRef.current = true;
    setNotice(null);
    try {
      if (prefs.burst) {
        if (prefs.sound) { shutterSound(); buzz(); }
        setFlash((n) => n + 1);
        setBurstProg(0);
        const fig = pose && pose.figures.length === 1 ? pose.figures[0] : null;
        const frames = await captureBurst(
          v,
          () => {
            const people = peopleRef.current;
            const m = fig && people.length === 1 ? matchScore(people[0], fig, v.videoWidth, v.videoHeight) : null;
            return { people, match: m };
          },
          setBurstProg,
          light ? BURST_FRAMES_LIGHT : undefined,
          undefined,
          light ? BURST_MAX_EDGE_LIGHT : undefined,
        );
        const scores = scoreFrames(frames.map((f) => ({ sharp: f.sharp, match: f.match, people: f.people.length })), pose?.figures.length);
        setBurst({ frames, scores, best: bestIndex(scores), mirrored: s.facing === 'user', at: Date.now() });
        return;
      }
      const people = peopleRef.current;
      const res = await takeBestPhoto(s, v);
      const frameAspect = v.videoWidth / v.videoHeight;
      // The overlay only lines up if the photo has the same framing as the preview.
      const overlayValid = Math.abs(res.width / res.height - frameAspect) < 0.03;
      if (prefs.sound) { shutterSound(); buzz(); }
      setFlash((n) => n + 1);
      setShot({
        blob: res.blob,
        url: URL.createObjectURL(res.blob),
        width: res.width,
        height: res.height,
        method: res.method,
        people,
        overlayValid,
        poseId: pose?.id ?? null,
        mirrored: s.facing === 'user',
        createdAt: Date.now(),
      });
    } catch (e) {
      setNotice(e instanceof Error ? e.message : 'The photo could not be taken. Try again.');
    } finally {
      busyRef.current = false;
      setBurstProg(null);
    }
  };

  const useBurstFrame = (i: number) => {
    if (!burst) return;
    const f = burst.frames[i];
    setShot({
      blob: f.blob,
      url: URL.createObjectURL(f.blob),
      width: f.width,
      height: f.height,
      method: 'Burst frame',
      people: f.people,
      overlayValid: true, // a burst frame is the live video frame, so the overlay lines up
      poseId: pose?.id ?? null,
      mirrored: burst.mirrored,
      createdAt: burst.at + i * 220,
    });
    setBurst(null);
  };

  captureRef.current = () => void capture();

  const onShutter = () => {
    primeAudio();
    if (countdown !== null) {
      setCountdown(null); // tap again to cancel
      return;
    }
    if (timer === 0) void capture();
    else setCountdown(timer);
  };

  useEffect(() => {
    if (countdown === null) return;
    if (countdown === 0) {
      setCountdown(null);
      void capture();
      return;
    }
    if (prefs.sound) tickSound(countdown === 1);
    const id = setTimeout(() => setCountdown((c) => (c === null ? null : c - 1)), 1000);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [countdown]);

  const retake = () => {
    if (shot) URL.revokeObjectURL(shot.url);
    setShot(null);
  };
  useEffect(() => () => { if (shot) URL.revokeObjectURL(shot.url); }, [shot]);

  const mirrored = info?.mirrored ?? facing === 'user';

  const chip =
    loadingAcc && det === 'ready' ? `Loading ${ACCURACY_INFO[loadingAcc].label} model…`
    : det === 'loading' ? 'Loading pose model…'
    : det === 'error' ? 'Pose detection off'
    : peopleCount === 0 ? 'Step into the frame'
    : `${peopleCount} ${peopleCount === 1 ? 'person' : 'people'} tracked`;

  return (
    <div className="fixed inset-0 flex flex-col bg-black text-white" onPointerDown={primeAudio}>
      {/* top controls: kept to four things; everything about the guide lives in one panel */}
      <div className="z-10 flex items-center gap-2 px-3 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <button data-ui="cam-back" onClick={() => back('')} aria-label="Close camera" className="cam-btn"><Icon name="back" /></button>
        <div className="min-w-0 flex-1 px-1">
          <p className="truncate text-base font-extrabold leading-tight">{pose ? pose.title : 'Free camera'}</p>
          <p className="truncate text-xs text-white/70">{chip}</p>
        </div>
        <button data-ui="cam-timer" onClick={() => setTimer((t) => (t === 0 ? 3 : t === 3 ? 5 : t === 5 ? 10 : 0))} aria-pressed={timer !== 0} aria-label={`Self-timer ${timer === 0 ? 'off' : timer + ' seconds'}`} className="cam-btn relative">
          <Icon name="timer" />
          {timer !== 0 && <span className="absolute -bottom-1 -right-1 rounded-full bg-ink px-1.5 text-[10px] font-bold text-volt">{timer}s</span>}
        </button>
        <button data-ui="cam-settings" onClick={() => setTune(true)} aria-label="Guide settings" className="cam-btn"><Icon name="sliders" /></button>
      </div>

      {det === 'error' && detMsg && (
        <p role="alert" className="z-10 mx-3 mb-2 rounded-2xl bg-amber-300 px-4 py-2 text-sm font-medium text-ink">
          {detMsg} You can still take photos.
        </p>
      )}

      {/* viewfinder: the whole frame is shown (no cropping) so the photo matches what you see */}
      <div className="relative min-h-0 flex-1">
        <div className="absolute inset-0" style={mirrored ? { transform: 'scaleX(-1)' } : undefined}>
          <video ref={videoRef} playsInline muted autoPlay className="h-full w-full object-contain" />
          <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full" />
        </div>
        {/* catches finger drags and pinches that move and resize the guide */}
        <div ref={boxRef} aria-hidden="true" className="absolute inset-0" style={{ touchAction: pose && g.showGuide && prefs.guideMove && !editing ? 'none' : 'auto' }} />

        {prefs.levelLine && tiltInfo.tilt && <LevelLine roll={tiltInfo.tilt.roll} pitch={tiltInfo.tilt.pitch} />}

        {status === 'starting' && <p className="absolute inset-0 grid place-items-center text-white/80">Starting camera…</p>}

        {status === 'error' && (
          <div role="alert" className="absolute inset-0 grid place-items-center p-6">
            <div className="max-w-sm rounded-3xl bg-white p-5 text-ink">
              <p className="text-lg font-extrabold">Camera unavailable</p>
              <p className="mt-1">{camError}</p>
              {camDetail && <p className="mt-2 text-xs text-ink/60">{camDetail}</p>}
              <div className="mt-4 flex gap-2">
                <button onClick={cam.retry} className="btn flex-1 bg-ink text-white">Try again</button>
                <button onClick={() => back('')} className="btn bg-ink/10">Back</button>
              </div>
            </div>
          </div>
        )}

        {countdown !== null && countdown > 0 && (
          <p className="pointer-events-none absolute inset-0 grid place-items-center text-[9rem] font-black text-white drop-shadow-lg" aria-live="assertive">{countdown}</p>
        )}

        {flash > 0 && <div key={flash} className="flash pointer-events-none absolute inset-0 bg-white" />}

        {/* status chips share one stack so they never sit on top of each other */}
        <div className={`pointer-events-none absolute left-3 flex max-w-[60%] flex-col items-start gap-1.5 ${notice ? 'top-16' : 'top-3'}`}>
          {hold !== null && (
            <p className="relative overflow-hidden rounded-full bg-volt px-3 py-1.5 text-sm font-bold text-ink" role="status">
              Hold it…
              <span aria-hidden="true" className="absolute inset-x-0 bottom-0 h-1 origin-left bg-ink/60 transition-transform duration-300 ease-linear" style={{ transform: `scaleX(${hold})` }} />
            </p>
          )}
          {hold === null && match !== null && pose && pose.figures.length === 1 && (
            <p className={`relative overflow-hidden rounded-full px-3 py-1.5 text-sm font-bold ${match >= 70 ? 'bg-volt text-ink' : 'bg-black/60 text-white'}`} role="status">
              {match}% {matchLabel(match / 100).toLowerCase()}
              <span aria-hidden="true" className="absolute inset-x-0 bottom-0 h-0.5 origin-left bg-current opacity-60" style={{ transform: `scaleX(${Math.min(1, match / 100)})` }} />
            </p>
          )}
          {autoOk && prefs.autoSnap && hold === null && <p className="rounded-full bg-black/60 px-3 py-1 text-xs">Auto-snap on</p>}
          {pose && pose.figures.length > 1 && g.showGuide && <p className="rounded-full bg-black/60 px-3 py-1.5 text-xs">Match score works for solo poses</p>}
        </div>

        {poseHint && !steps && hold === null && countdown === null && (
          <p className="pointer-events-none absolute inset-x-0 bottom-10 flex justify-center px-4" role="status">
            <span className="rounded-full bg-black/70 px-4 py-2 text-base font-bold text-white shadow">{poseHint}</span>
          </p>
        )}

        {lightTip && (
          <button
            onClick={dismissLightTip}
            aria-label={`${LIGHT_TIPS[lightTip]} Tap to hide.`}
            className="absolute right-3 top-3 max-w-[52%] rounded-2xl bg-sun px-3 py-1.5 text-left text-sm font-bold leading-snug text-ink shadow"
          >
            {LIGHT_TIPS[lightTip]}
          </button>
        )}

        {notice && <p role="alert" className="absolute inset-x-3 top-3 rounded-2xl bg-rose-600 px-4 py-2 text-sm">{notice}</p>}

        {steps && pose && (
          <div className="absolute inset-x-3 bottom-3 rounded-3xl bg-white/95 p-4 text-ink shadow-lg">
            <div className="flex items-start justify-between gap-2">
              <p className="font-extrabold">{pose.title}</p>
              <div className="-mt-1 flex items-center gap-1">
                <HeartButton poseId={pose.id} title={pose.title} className="h-9 w-9" />
                <button onClick={() => setSteps(false)} aria-label="Hide steps" className="grid h-9 w-9 place-items-center rounded-full bg-ink/10"><Icon name="close" className="h-5 w-5" /></button>
              </div>
            </div>
            <ol className="mt-1 list-decimal space-y-0.5 pl-5 text-sm">{pose.steps.map((s) => <li key={s}>{s}</li>)}</ol>
            <p className="mt-2 text-sm text-ink/70"><b>Tip:</b> {pose.tip}</p>
          </div>
        )}

        {burstProg !== null && (
          <p className="pointer-events-none absolute inset-x-0 top-14 flex justify-center" role="status">
            <span className="rounded-full bg-volt px-4 py-2 text-base font-black text-ink">Burst {burstProg}/{light ? BURST_FRAMES_LIGHT : BURST_COUNT}, keep posing</span>
          </p>
        )}

        {prefs.lightDebug && !steps && <LightDebugPanel reading={lightReading} log={lightLog} people={peopleCount} />}

        {!steps && status === 'ready' && (
          <div className="absolute bottom-2 left-3 flex flex-wrap gap-2">
            <button
              onClick={() => setPref('burst', !prefs.burst)}
              aria-pressed={prefs.burst}
              aria-label={`Burst mode ${prefs.burst ? 'on' : 'off'}`}
              className={`rounded-full px-3 py-1.5 text-xs font-extrabold ${prefs.burst ? 'bg-volt text-ink' : 'bg-black/60 text-white'}`}
            >
              Burst {prefs.burst ? 'on' : 'off'}
            </button>
            {pose && g.showGuide && (
              <button
                onClick={() => setPref('follow', !prefs.follow)}
                aria-pressed={prefs.follow}
                aria-label={`Fit guide to me ${prefs.follow ? 'on' : 'off'}`}
                className={`rounded-full px-3 py-1.5 text-xs font-extrabold ${prefs.follow ? 'bg-volt text-ink' : 'bg-black/60 text-white'}`}
              >
                Fit to me {prefs.follow ? 'on' : 'off'}
              </button>
            )}
            {adjusted && (
              <button onClick={resetGuide} aria-label="Put the guide back" className="rounded-full bg-black/60 px-3 py-1.5 text-xs font-extrabold text-white">
                Reset guide
              </button>
            )}
          </div>
        )}

        {info && status === 'ready' && (
          <div className="pointer-events-none absolute bottom-2 right-3 text-right text-[11px] text-white/60">
            <p>{info.w} × {info.h} live{fps > 0 ? `, ${fps} fps` : ''}</p>
            {saverOn ? <p>Battery saver on</p> : eased && <p className="text-amber-300">Slowed down to keep up</p>}
          </div>
        )}
      </div>

      {/* bottom controls */}
      <div className="z-10 grid grid-cols-3 items-center px-5 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3">
        <div className="flex items-center gap-2">
          <button data-ui="cam-poses" onClick={() => setSheet(true)} className="flex h-14 items-center gap-2 rounded-2xl bg-white/15 px-3 text-sm font-bold active:scale-95" aria-label="Choose a pose">
            {pose ? <PoseArt figures={pose.figures} outlines={pose.outlines} detail={false} className="h-9 w-9 rounded-lg bg-volt" /> : <Icon name="poses" />}
            <span>Pose</span>
          </button>
          {pose && (
            <button data-ui="cam-steps" onClick={() => setSteps((v) => !v)} aria-pressed={steps} aria-label="Show pose steps" className="cam-btn"><Icon name="info" /></button>
          )}
        </div>

        <button
          data-ui="cam-shutter"
          onClick={onShutter}
          disabled={status !== 'ready'}
          aria-label={countdown !== null ? 'Cancel timer' : 'Take photo'}
          className="keep-round mx-auto grid h-20 w-20 place-items-center rounded-full border-4 border-white transition active:scale-95 disabled:opacity-40"
        >
          {shutterIcon && countdown === null ? (
            <Icon name="shutter" className="h-14 w-14" />
          ) : (
            <span data-ui-fill className={`block rounded-full bg-white transition-all ${countdown !== null ? 'h-8 w-8 rounded-lg' : 'h-14 w-14'}`} />
          )}
        </button>

        <button data-ui="cam-flip" onClick={() => setFacing((f) => (f === 'user' ? 'environment' : 'user'))} aria-label="Switch between front and rear camera" className="cam-btn ml-auto h-14 w-14 bg-white/15">
          <Icon name="flip" className="h-7 w-7" />
        </button>
      </div>

      {tune && <GuideSettings pose={pose} g={g} d={d} tilt={tiltInfo} autoOk={autoOk} saverOn={saverOn} battery={battery} onClose={() => setTune(false)} />}

      {sheet && <PoseSheet pose={pose} onClose={() => setSheet(false)} />}

      {burst && <BurstPicker frames={burst.frames} scores={burst.scores} best={burst.best} onUse={useBurstFrame} onCancel={() => setBurst(null)} />}
      {shot && <Preview shot={shot} onRetake={retake} />}
    </div>
  );
}
