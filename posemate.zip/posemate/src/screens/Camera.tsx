import { useEffect, useRef, useState } from 'react';
import { MODES, MOODS, getAllPoses, getPose, getPoses, type Mode, type Mood } from '../data/poses';
import { back, replace } from '../lib/route';
import { cameraPermissionState, errorName, explainCameraError, openCamera, type PermState, takeBestPhoto, type CameraSession, type Facing } from '../lib/camera';
import { loadDetector, releaseDetector, type Detector } from '../lib/pose';
import { ACCURACIES, ACCURACY_INFO, withFallback, type Accuracy } from '../lib/accuracy';
import { drawOverlay, type GhostBitmap, type Person } from '../lib/draw';
import { HintKeeper, matchHint, matchLabel, matchScore } from '../lib/match';
import { PoseSmoother } from '../lib/smooth';
import { lockSound, primeAudio, requestTiltPermission, shutterSound, tickSound, useLowBattery, useTilt, useWakeLock } from '../lib/device';
import { FrameGovernor, IDLE_AFTER_MS, IDLE_FPS } from '../lib/perf';
import { LIGHT_TIPS, LightWatcher, analyzeLight, lightIssue, subjectBox, type LightIssue } from '../lib/light';
import { setPref, usePrefs } from '../lib/prefs';
import Icon from '../components/Icon';
import LevelLine from '../components/LevelLine';
import HeartButton from '../components/HeartButton';
import PoseArt from '../components/PoseArt';
import { Row, Segmented, Switch } from '../components/Controls';
import Preview, { type Shot } from '../components/Preview';

// ghost figure opacity per strength level: off (outline only), light, medium, strong
const GHOST = [0, 0.22, 0.4, 0.6] as const;

// Auto-snap: the match score must reach SNAP_ENTER, then stay above SNAP_RELEASE for SNAP_HOLD_MS.
// These are first guesses; tune them on a real phone.
const SNAP_ENTER = 0.8;
const SNAP_RELEASE = 0.65;
const SNAP_HOLD_MS = 1500;

type CamStatus = 'starting' | 'ready' | 'error';
type DetState = 'loading' | 'ready' | 'error';

export default function CameraScreen({ poseId }: { poseId?: string }) {
  const pose = getPose(poseId);
  const prefs = usePrefs();
  const autoOk = !!pose && pose.figures.length === 1; // match score exists for solo poses only
  useWakeLock(prefs.keepAwake);
  const battery = useLowBattery();
  const saverOn = prefs.saver === 'on' || (prefs.saver === 'auto' && battery.low);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<CameraSession | null>(null);
  const detRef = useRef<Detector | null>(null);
  const peopleRef = useRef<Person[]>([]);
  const busyRef = useRef(false);
  const captureRef = useRef<() => void>(() => {});

  const [facing, setFacing] = useState<Facing>(pose?.mode === 'solo' ? 'user' : 'environment');
  const tiltInfo = useTilt(prefs.levelLine, facing); // the phone's tilt, for the level line
  const [attempt, setAttempt] = useState(0);
  const [status, setStatus] = useState<CamStatus>('starting');
  const [camError, setCamError] = useState<string | null>(null);
  const [camDetail, setCamDetail] = useState<string | null>(null);
  const [info, setInfo] = useState<{ w: number; h: number; mirrored: boolean } | null>(null);

  const [det, setDet] = useState<DetState>('loading');
  const [detMsg, setDetMsg] = useState<string | null>(null);
  const [delegate, setDelegate] = useState<string>('');
  const [activeAcc, setActiveAcc] = useState<Accuracy | null>(null); // the model actually running
  const [loadingAcc, setLoadingAcc] = useState<Accuracy | null>(null); // a model being switched to
  const [accNote, setAccNote] = useState<string | null>(null); // why a different model is running
  const [peopleCount, setPeopleCount] = useState(0);
  const [match, setMatch] = useState<number | null>(null);

  const [showSkeleton, setShowSkeleton] = useState(true);
  const [showGuide, setShowGuide] = useState(true);
  const [showDetail, setShowDetail] = useState(true);
  const [ghostLevel, setGhostLevel] = useState<0 | 1 | 2 | 3>(2);
  const [photoGhost, setPhotoGhost] = useState(true);
  const [ghostBitmaps, setGhostBitmaps] = useState<(GhostBitmap | null)[] | undefined>(undefined);
  const [timer, setTimer] = useState<0 | 3 | 5 | 10>(0);
  const [hold, setHold] = useState<number | null>(null); // auto-snap progress 0..1
  const [fps, setFps] = useState(0); // detections per second, measured
  const [eased, setEased] = useState(false); // slowed down because the phone could not keep up
  const [lightTip, setLightTip] = useState<LightIssue | null>(null);
  const watcher = useRef(new LightWatcher()).current;
  const [poseHint, setPoseHint] = useState<string | null>(null);
  const hintKeeper = useRef(new HintKeeper()).current;
  const [favOnly, setFavOnly] = useState(false);
  const [sheetMood, setSheetMood] = useState<Mood | 'all'>('all');
  const [countdown, setCountdown] = useState<number | null>(null);
  const [flash, setFlash] = useState(0);
  const [sheet, setSheet] = useState(false);
  const [tune, setTune] = useState(false);
  const [sheetMode, setSheetMode] = useState<Mode>(pose?.mode ?? 'solo');
  const [steps, setSteps] = useState(false);
  const [shot, setShot] = useState<Shot | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Latest values for the animation loop, which must not restart on every change.
  const live = useRef({ showSkeleton, showGuide, showDetail, ghost: GHOST[ghostLevel], ghostPhotos: photoGhost ? ghostBitmaps : undefined, figures: pose?.figures, outlines: pose?.outlines, details: pose?.details, paused: false, autoSnap: false, sound: true, idle: true, saver: false, lightTips: true, poseTips: true });
  live.current = { showSkeleton, showGuide, showDetail, ghost: GHOST[ghostLevel], ghostPhotos: photoGhost ? ghostBitmaps : undefined, figures: pose?.figures, outlines: pose?.outlines, details: pose?.details, paused: shot !== null, autoSnap: autoOk && prefs.autoSnap, sound: prefs.sound, idle: countdown === null && shot === null, saver: saverOn, lightTips: prefs.lightTips, poseTips: prefs.poseTips };
  const favPoses = (() => {
    const everything = getAllPoses();
    return prefs.favorites.map((id) => everything.find((p) => p.id === id)).filter((p): p is NonNullable<typeof p> => !!p);
  })();
  const sheetBase = favOnly ? favPoses : getPoses(sheetMode);
  const sheetMoods = MOODS.filter((m) => sheetBase.some((p) => p.moods?.includes(m.id)));
  // A chosen mood that this list does not have (after switching Solo/Couple/Group) shows everything.
  const moodFilter = sheetMoods.some((m) => m.id === sheetMood) ? sheetMood : 'all';
  const sheetPoses = moodFilter === 'all' ? sheetBase : sheetBase.filter((p) => p.moods?.includes(moodFilter));

  // ---- decode the pose's photo ghost (only exists if the user opted in when creating it) ----
  const ghostSrc = pose?.ghostPhotos;
  useEffect(() => {
    if (!ghostSrc?.some(Boolean)) {
      setGhostBitmaps(undefined);
      return;
    }
    let alive = true;
    const made: ImageBitmap[] = [];
    void Promise.all(
      ghostSrc.map(async (g): Promise<GhostBitmap | null> => {
        if (!g) return null;
        try {
          const bitmap = await createImageBitmap(g.blob);
          made.push(bitmap);
          return { bitmap, box: g.box, mirrored: g.mirrored };
        } catch {
          return null; // undecodable: that figure falls back to the shape ghost
        }
      }),
    ).then((list) => {
      if (alive) setGhostBitmaps(list);
      else made.forEach((b) => b.close());
    });
    return () => {
      alive = false;
      live.current.ghostPhotos = undefined; // stop the draw loop using bitmaps we are about to release
      setGhostBitmaps(undefined);
      made.forEach((b) => b.close());
    };
  }, [ghostSrc]);

  // ---- open the camera (this is the moment the permission prompt appears) ----
  useEffect(() => {
    let cancelled = false;
    setStatus('starting');
    setCamError(null);
    setCamDetail(null);
    (async () => {
      try {
        const session = await openCamera(facing);
        if (cancelled) {
          session.stream.getTracks().forEach((t) => t.stop());
          return;
        }
        sessionRef.current = session;
        const v = videoRef.current!;
        v.srcObject = session.stream;
        await v.play();
        if (cancelled) return;
        const s = session.track.getSettings();
        setInfo({
          w: v.videoWidth || s.width || 0,
          h: v.videoHeight || s.height || 0,
          mirrored: session.facing === 'user',
        });
        setStatus('ready');
      } catch (e) {
        if (!cancelled) {
          setCamError(explainCameraError(e));
          setStatus('error');
          const name = errorName(e);
          void cameraPermissionState().then((st: PermState) => {
            if (!cancelled) setCamDetail(`Error: ${name}. Site permission: ${st}`);
          });
        }
      }
    })();
    return () => {
      cancelled = true;
      sessionRef.current?.stream.getTracks().forEach((t) => t.stop());
      sessionRef.current = null;
      if (videoRef.current) videoRef.current.srcObject = null;
    };
  }, [facing, attempt]);

  // Restart if the browser ended the camera while the tab was in the background.
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible' && sessionRef.current?.track.readyState === 'ended') {
        setAttempt((n) => n + 1);
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, []);

  // ---- load MediaPipe (on-device) ----
  // Battery saver always uses the Lite model; otherwise the Accuracy setting decides. While a new
  // model loads, the old one keeps tracking, so switching never freezes the camera.
  const wantAcc: Accuracy = saverOn ? 'lite' : prefs.accuracy;
  const maxPeopleRef = useRef(2);
  maxPeopleRef.current = Math.min(5, Math.max(1, pose ? pose.figures.length : 2));
  useEffect(() => {
    let alive = true;
    setLoadingAcc(detRef.current && detRef.current.accuracy === wantAcc ? null : wantAcc);
    withFallback(wantAcc, loadDetector)
      .then(({ value: d, used, failed }) => {
        if (!alive) return;
        detRef.current = d;
        d.setMaxPeople(maxPeopleRef.current);
        setDelegate(d.delegate);
        setActiveAcc(used);
        setLoadingAcc(null);
        setAccNote(failed ? `${ACCURACY_INFO[failed.accuracy].label} model unavailable, using Lite. ${failed.message}` : null);
        setDet('ready');
        // free every other model (a Heavy model holds a lot of memory)
        ACCURACIES.forEach((a) => a !== used && releaseDetector(a));
      })
      .catch((e) => {
        if (!alive) return;
        setLoadingAcc(null);
        setDet('error');
        setDetMsg(e instanceof Error ? e.message : 'The pose model failed to load.');
      });
    return () => {
      alive = false;
    };
  }, [wantAcc]);

  useEffect(() => {
    if (det === 'ready') detRef.current?.setMaxPeople(maxPeopleRef.current);
  }, [det, pose]);

  // Leaving the camera frees the larger models; Lite stays loaded so reopening is instant.
  useEffect(
    () => () => {
      releaseDetector('full');
      releaseDetector('heavy');
    },
    [],
  );

  // ---- detection + overlay loop (up to 20 per second, adapts to the phone) ----
  useEffect(() => {
    if (status !== 'ready') return;
    const off = document.createElement('canvas'); // small copy of the frame for the model
    const octx = off.getContext('2d');
    let raf = 0;
    let last = 0;
    let lastMatch = 0;
    let errors = 0;
    let stopped = false;
    const smoother = new PoseSmoother();
    const gov = new FrameGovernor();
    let lastSeen = 0; // last time someone was in the frame
    let fpsCount = 0;
    let fpsT = 0;
    const lightCanvas = document.createElement('canvas'); // 64 x 36 copy, only used to measure brightness
    lightCanvas.width = 64;
    lightCanvas.height = 36;
    const lctx = lightCanvas.getContext('2d', { willReadFrequently: true });
    let lastLight = 0;
    let holdStart: number | null = null;
    let armed = true; // after a snap, the person must move out of the pose before it can fire again

    const tick = (t: number) => {
      raf = requestAnimationFrame(tick);
      const v = videoRef.current;
      const c = canvasRef.current;
      if (stopped || live.current.paused || !v || !c || !octx || v.readyState < 2 || !v.videoWidth) return;
      if (!lastSeen) lastSeen = fpsT = t;
      gov.setSaver(live.current.saver);
      // With nobody in the frame there is nothing to track: only check now and then.
      const idle = t - lastSeen > IDLE_AFTER_MS;
      if (t - last < (idle ? Math.max(gov.interval, 1000 / IDLE_FPS) : gov.interval)) return;
      last = t;
      const work0 = performance.now();

      const d = detRef.current;
      if (d) {
        try {
          // The model resizes to about 256 px itself, so a smaller copy loses little and costs less.
          const k = (live.current.saver ? 320 : 480) / Math.max(v.videoWidth, v.videoHeight);
          const w = Math.max(1, Math.round(v.videoWidth * k));
          const h = Math.max(1, Math.round(v.videoHeight * k));
          if (off.width !== w || off.height !== h) {
            off.width = w;
            off.height = h;
          }
          octx.drawImage(v, 0, 0, w, h);
          peopleRef.current = smoother.apply(d.detect(off), t);
          if (peopleRef.current.length > 0) lastSeen = t;
          errors = 0;
        } catch {
          if (++errors > 5) {
            detRef.current = null;
            peopleRef.current = [];
            setDet('error');
            setDetMsg('Pose detection stopped unexpectedly. Reload the page to try again.');
          }
        }
      }

      const people = peopleRef.current;

      // Lighting check, twice a second.
      if (t - lastLight > 500) {
        lastLight = t;
        if (!live.current.lightTips || !lctx) {
          watcher.reset();
          setLightTip(null);
        } else {
          try {
            lctx.drawImage(v, 0, 0, 64, 36);
            const stats = analyzeLight(lctx.getImageData(0, 0, 64, 36).data, 64, 36, subjectBox(people));
            setLightTip(watcher.update(lightIssue(stats), t));
          } catch {
            /* the frame could not be read this time; try again next time */
          }
        }
      }

      const { showSkeleton: sk, showGuide: gd, showDetail: sd, ghost, ghostPhotos, figures, outlines, details } = live.current;
      drawOverlay(c, {
        vw: v.videoWidth,
        vh: v.videoHeight,
        persons: sk ? people : [],
        reference: gd ? figures : undefined,
        outlines: gd ? outlines : undefined,
        details: gd ? details : undefined,
        showDetail: sd,
        ghost,
        ghostPhotos: gd ? ghostPhotos : undefined,
      });

      gov.record(performance.now() - work0, t);
      fpsCount++;
      if (t - fpsT >= 1000) {
        setFps(Math.round((fpsCount * 1000) / (t - fpsT)));
        setEased(gov.eased);
        fpsCount = 0;
        fpsT = t;
      }

      if (t - lastMatch > 250) {
        lastMatch = t;
        setPeopleCount((n) => (n === people.length ? n : people.length));
        // A match score is only meaningful for a single-person reference.
        let s: number | null = null;
        if (figures?.length === 1 && people.length > 0) {
          s = matchScore(people[0], figures[0], v.videoWidth, v.videoHeight);
        }
        setMatch(s === null ? null : Math.round(s * 100));

        // One short piece of advice about the limb that is furthest off (not once the pose is nailed).
        const wantHint = live.current.poseTips && s !== null && s < 0.85 && figures?.length === 1 && people.length > 0;
        setPoseHint(hintKeeper.update(wantHint ? matchHint(people[0], figures[0], v.videoWidth, v.videoHeight) : null, t));

        // Auto-snap: hold the pose for a moment and the photo is taken.
        const L = live.current;
        if (s === null || s < SNAP_RELEASE) armed = true;
        if (L.autoSnap && L.idle && armed && s !== null && s >= (holdStart === null ? SNAP_ENTER : SNAP_RELEASE)) {
          if (holdStart === null) {
            holdStart = t;
            if (L.sound) lockSound();
          }
          const progress = Math.min(1, (t - holdStart) / SNAP_HOLD_MS);
          if (progress >= 1) {
            holdStart = null;
            armed = false;
            setHold(null);
            captureRef.current();
          } else {
            setHold(progress);
          }
        } else {
          holdStart = null;
          setHold(null);
        }
      }
    };
    raf = requestAnimationFrame(tick);
    return () => {
      stopped = true;
      cancelAnimationFrame(raf);
    };
  }, [status]);

  // ---- capture ----
  const capture = async () => {
    const v = videoRef.current;
    const s = sessionRef.current;
    if (!v || !s || busyRef.current) return;
    busyRef.current = true;
    setNotice(null);
    try {
      const people = peopleRef.current;
      const res = await takeBestPhoto(s, v);
      const frameAspect = v.videoWidth / v.videoHeight;
      // The overlay only lines up if the photo has the same framing as the preview.
      const overlayValid = Math.abs(res.width / res.height - frameAspect) < 0.03;
      if (prefs.sound) shutterSound();
      setFlash((n) => n + 1);
      setShot({
        blob: res.blob,
        url: URL.createObjectURL(res.blob),
        width: res.width,
        height: res.height,
        method: res.method,
        people,
        overlayValid,
        poseId: pose?.id ?? null,
        mirrored: s.facing === 'user',
        createdAt: Date.now(),
      });
    } catch (e) {
      setNotice(e instanceof Error ? e.message : 'The photo could not be taken. Try again.');
    } finally {
      busyRef.current = false;
    }
  };

  captureRef.current = () => void capture();

  const onShutter = () => {
    primeAudio();
    if (countdown !== null) {
      setCountdown(null); // tap again to cancel
      return;
    }
    if (timer === 0) void capture();
    else setCountdown(timer);
  };

  useEffect(() => {
    if (countdown === null) return;
    if (countdown === 0) {
      setCountdown(null);
      void capture();
      return;
    }
    if (prefs.sound) tickSound(countdown === 1);
    const id = setTimeout(() => setCountdown((c) => (c === null ? null : c - 1)), 1000);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [countdown]);

  const retake = () => {
    if (shot) URL.revokeObjectURL(shot.url);
    setShot(null);
  };
  useEffect(() => () => { if (shot) URL.revokeObjectURL(shot.url); }, [shot]);

  const mirrored = info?.mirrored ?? facing === 'user';

  const chip =
    loadingAcc && det === 'ready' ? `Loading ${ACCURACY_INFO[loadingAcc].label} model…`
    : det === 'loading' ? 'Loading pose model…'
    : det === 'error' ? 'Pose detection off'
    : peopleCount === 0 ? 'Step into the frame'
    : `${peopleCount} ${peopleCount === 1 ? 'person' : 'people'} tracked`;

  return (
    <div className="fixed inset-0 flex flex-col bg-black text-white" onPointerDown={primeAudio}>
      {/* top controls: kept to four things; everything about the guide lives in one panel */}
      <div className="z-10 flex items-center gap-2 px-3 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <button onClick={() => back('')} aria-label="Close camera" className="cam-btn"><Icon name="back" /></button>
        <div className="min-w-0 flex-1 px-1">
          <p className="truncate text-base font-extrabold leading-tight">{pose ? pose.title : 'Free camera'}</p>
          <p className="truncate text-xs text-white/70">{chip}</p>
        </div>
        <button onClick={() => setTimer((t) => (t === 0 ? 3 : t === 3 ? 5 : t === 5 ? 10 : 0))} aria-pressed={timer !== 0} aria-label={`Self-timer ${timer === 0 ? 'off' : timer + ' seconds'}`} className="cam-btn relative">
          <Icon name="timer" />
          {timer !== 0 && <span className="absolute -bottom-1 -right-1 rounded-full bg-ink px-1.5 text-[10px] font-bold text-volt">{timer}s</span>}
        </button>
        <button onClick={() => setTune(true)} aria-label="Guide settings" className="cam-btn"><Icon name="sliders" /></button>
      </div>

      {det === 'error' && detMsg && (
        <p role="alert" className="z-10 mx-3 mb-2 rounded-2xl bg-amber-300 px-4 py-2 text-sm font-medium text-ink">
          {detMsg} You can still take photos.
        </p>
      )}

      {/* viewfinder: the whole frame is shown (no cropping) so the photo matches what you see */}
      <div className="relative min-h-0 flex-1">
        <div className="absolute inset-0" style={mirrored ? { transform: 'scaleX(-1)' } : undefined}>
          <video ref={videoRef} playsInline muted autoPlay className="h-full w-full object-contain" />
          <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full" />
        </div>

        {prefs.levelLine && tiltInfo.tilt && <LevelLine roll={tiltInfo.tilt.roll} pitch={tiltInfo.tilt.pitch} />}

        {status === 'starting' && <p className="absolute inset-0 grid place-items-center text-white/80">Starting camera…</p>}

        {status === 'error' && (
          <div role="alert" className="absolute inset-0 grid place-items-center p-6">
            <div className="max-w-sm rounded-3xl bg-white p-5 text-ink">
              <p className="text-lg font-extrabold">Camera unavailable</p>
              <p className="mt-1">{camError}</p>
              {camDetail && <p className="mt-2 text-xs text-ink/60">{camDetail}</p>}
              <div className="mt-4 flex gap-2">
                <button onClick={() => setAttempt((n) => n + 1)} className="btn flex-1 bg-ink text-white">Try again</button>
                <button onClick={() => back('')} className="btn bg-ink/10">Back</button>
              </div>
            </div>
          </div>
        )}

        {countdown !== null && countdown > 0 && (
          <p className="pointer-events-none absolute inset-0 grid place-items-center text-[9rem] font-black text-white drop-shadow-lg" aria-live="assertive">{countdown}</p>
        )}

        {flash > 0 && <div key={flash} className="flash pointer-events-none absolute inset-0 bg-white" />}

        {hold !== null && (
          <p className="absolute left-3 top-3 overflow-hidden rounded-full bg-volt px-3 py-1.5 text-sm font-bold text-ink" role="status">
            Hold it…
            <span aria-hidden="true" className="absolute inset-x-0 bottom-0 h-1 origin-left bg-ink/60 transition-transform duration-300 ease-linear" style={{ transform: `scaleX(${hold})` }} />
          </p>
        )}

        {hold === null && match !== null && pose && pose.figures.length === 1 && (
          <p className={`absolute left-3 top-3 rounded-full px-3 py-1.5 text-sm font-bold ${match >= 70 ? 'bg-volt text-ink' : 'bg-black/60 text-white'}`} role="status">
            {match}% {matchLabel(match / 100).toLowerCase()}
          </p>
        )}

        {poseHint && !steps && hold === null && countdown === null && (
          <p className="pointer-events-none absolute inset-x-0 bottom-10 flex justify-center px-4" role="status">
            <span className="rounded-full bg-black/70 px-4 py-2 text-base font-bold text-white shadow">{poseHint}</span>
          </p>
        )}

        {lightTip && (
          <button
            onClick={() => {
              watcher.dismiss();
              setLightTip(null);
            }}
            aria-label={`${LIGHT_TIPS[lightTip]} Tap to hide.`}
            className="absolute right-3 top-3 max-w-[52%] rounded-2xl bg-sun px-3 py-1.5 text-left text-sm font-bold leading-snug text-ink shadow"
          >
            {LIGHT_TIPS[lightTip]}
          </button>
        )}

        {autoOk && prefs.autoSnap && hold === null && (
          <p className="absolute left-3 top-12 rounded-full bg-black/60 px-3 py-1 text-xs">Auto-snap on</p>
        )}

        {pose && pose.figures.length > 1 && showGuide && (
          <p className="absolute left-3 top-3 rounded-full bg-black/60 px-3 py-1.5 text-xs">Match score works for solo poses</p>
        )}

        {notice && <p role="alert" className="absolute inset-x-3 top-3 rounded-2xl bg-rose-600 px-4 py-2 text-sm">{notice}</p>}

        {steps && pose && (
          <div className="absolute inset-x-3 bottom-3 rounded-3xl bg-white/95 p-4 text-ink shadow-lg">
            <div className="flex items-start justify-between gap-2">
              <p className="font-extrabold">{pose.title}</p>
              <div className="-mt-1 flex items-center gap-1">
                <HeartButton poseId={pose.id} title={pose.title} className="h-9 w-9" />
                <button onClick={() => setSteps(false)} aria-label="Hide steps" className="grid h-9 w-9 place-items-center rounded-full bg-ink/10"><Icon name="close" className="h-5 w-5" /></button>
              </div>
            </div>
            <ol className="mt-1 list-decimal space-y-0.5 pl-5 text-sm">{pose.steps.map((s) => <li key={s}>{s}</li>)}</ol>
            <p className="mt-2 text-sm text-ink/70"><b>Tip:</b> {pose.tip}</p>
          </div>
        )}

        {info && status === 'ready' && (
          <div className="pointer-events-none absolute bottom-2 right-3 text-right text-[11px] text-white/60">
            <p>{info.w} × {info.h} live{fps > 0 ? `, ${fps} fps` : ''}</p>
            {saverOn ? <p>Battery saver on</p> : eased && <p className="text-amber-300">Slowed down to keep up</p>}
          </div>
        )}
      </div>

      {/* bottom controls */}
      <div className="z-10 grid grid-cols-3 items-center px-5 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3">
        <div className="flex items-center gap-2">
          <button onClick={() => setSheet(true)} className="flex h-14 items-center gap-2 rounded-2xl bg-white/15 px-3 text-sm font-bold active:scale-95" aria-label="Choose a pose">
            {pose ? <PoseArt figures={pose.figures} outlines={pose.outlines} detail={false} className="h-9 w-9 rounded-lg bg-volt" /> : <Icon name="poses" />}
            <span>Pose</span>
          </button>
          {pose && (
            <button onClick={() => setSteps((v) => !v)} aria-pressed={steps} aria-label="Show pose steps" className="cam-btn"><Icon name="info" /></button>
          )}
        </div>

        <button
          onClick={onShutter}
          disabled={status !== 'ready'}
          aria-label={countdown !== null ? 'Cancel timer' : 'Take photo'}
          className="mx-auto grid h-20 w-20 place-items-center rounded-full border-4 border-white transition active:scale-95 disabled:opacity-40"
        >
          <span className={`block rounded-full bg-white transition-all ${countdown !== null ? 'h-8 w-8 rounded-lg' : 'h-14 w-14'}`} />
        </button>

        <button onClick={() => setFacing((f) => (f === 'user' ? 'environment' : 'user'))} aria-label="Switch between front and rear camera" className="cam-btn ml-auto h-14 w-14 bg-white/15">
          <Icon name="flip" className="h-7 w-7" />
        </button>
      </div>

      {/* guide settings */}
      {tune && (
        <div className="fixed inset-0 z-30 flex flex-col justify-end bg-black/60" onClick={() => setTune(false)}>
          <div className="sheet max-h-[80dvh] overflow-y-auto rounded-t-[2rem] bg-paper p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] text-ink" onClick={(e) => e.stopPropagation()}>
            <div className="mb-5 flex items-center justify-between">
              <p className="text-xl font-black tracking-tight">Guide settings</p>
              <button onClick={() => setTune(false)} aria-label="Close" className="grid h-10 w-10 place-items-center rounded-full bg-ink/10"><Icon name="close" className="h-5 w-5" /></button>
            </div>
            <div className="space-y-5">
              <Row label="Pose guide" hint={pose ? 'The outline and ghost to line up with' : 'Pick a pose to use the guide'}>
                <Switch checked={!!pose && showGuide} disabled={!pose} onChange={setShowGuide} label="Pose guide" />
              </Row>
              {pose && showGuide && (
                <>
                  <div>
                    <p className="mb-2 font-bold">Ghost strength</p>
                    <Segmented label="Ghost strength" value={ghostLevel} onChange={(v) => setGhostLevel(v as 0 | 1 | 2 | 3)} options={[['Off', 0], ['Light', 1], ['Medium', 2], ['Strong', 3]] as const} />
                  </div>
                  {ghostBitmaps?.some(Boolean) && (
                    <div>
                      <p className="mb-2 font-bold">Ghost style</p>
                      <Segmented label="Ghost style" value={photoGhost ? 'photo' : 'shape'} onChange={(v) => setPhotoGhost(v === 'photo')} options={[['Shape', 'shape'], ['Photo', 'photo']] as const} />
                    </div>
                  )}
                  {pose.outlines?.some(Boolean) && (
                    <Row label="Body-part lines and skeleton" hint="Shows where arms, legs and head go">
                      <Switch checked={showDetail} onChange={setShowDetail} label="Body-part lines and skeleton" />
                    </Row>
                  )}
                </>
              )}
              <Row label="Live skeleton" hint="Your own body, as the camera sees it">
                <Switch checked={showSkeleton} onChange={setShowSkeleton} label="Live skeleton" />
              </Row>
              <Row
                label="Level line"
                hint={
                  prefs.levelLine && tiltInfo.status === 'unavailable'
                    ? 'No tilt readings. Allow Motion sensors for this site in your browser settings.'
                    : 'Shows how the phone is tilted so the horizon stays straight'
                }
              >
                <Switch
                  checked={prefs.levelLine}
                  onChange={async (v) => {
                    if (v) await requestTiltPermission(); // iPhones ask; Android does not
                    setPref('levelLine', v);
                  }}
                  label="Level line"
                />
              </Row>
              <div className="space-y-5 border-t border-ink/10 pt-5">
                <Row label="Auto-snap" hint={autoOk ? 'Takes the photo when you hold the pose' : 'Works with solo poses'}>
                  <Switch checked={autoOk && prefs.autoSnap} disabled={!autoOk} onChange={(v) => { primeAudio(); setPref('autoSnap', v); }} label="Auto-snap" />
                </Row>
                <Row label="Sounds" hint="Timer ticks and shutter click">
                  <Switch checked={prefs.sound} onChange={(v) => { primeAudio(); setPref('sound', v); }} label="Sounds" />
                </Row>
                <div>
                  <p className="font-bold">Accuracy</p>
                  <p className="mb-2 text-sm text-ink/60">
                    {saverOn
                      ? 'Battery saver is on, so the Lite model is used'
                      : `${ACCURACY_INFO[prefs.accuracy].blurb}.${prefs.accuracy === 'lite' ? '' : ` Saved on this phone the first time (about ${ACCURACY_INFO[prefs.accuracy].mb} MB).`}`}
                  </p>
                  <Segmented label="Accuracy" value={prefs.accuracy} onChange={(v) => setPref('accuracy', v)} options={ACCURACIES.map((a) => [ACCURACY_INFO[a].label, a] as const)} />
                  {accNote && !saverOn && <p role="status" className="mt-2 text-sm text-amber-700">{accNote}</p>}
                  {activeAcc && !saverOn && activeAcc !== prefs.accuracy && !accNote && loadingAcc === null && (
                    <p className="mt-2 text-sm text-ink/60">Running {ACCURACY_INFO[activeAcc].label}.</p>
                  )}
                </div>
                <div>
                  <p className="font-bold">Battery saver</p>
                  <p className="mb-2 text-sm text-ink/60">
                    {prefs.saver === 'on'
                      ? 'Tracks up to 10 times a second to use less power'
                      : prefs.saver === 'off'
                        ? 'Tracks up to 20 times a second, and slows down by itself if your phone cannot keep up'
                        : battery.supported
                          ? 'Switches on at 20% battery or less when unplugged'
                          : 'This browser does not share battery level, so Auto stays off'}
                  </p>
                  <Segmented label="Battery saver" value={prefs.saver} onChange={(v) => setPref('saver', v)} options={[['Off', 'off'], ['Auto', 'auto'], ['On', 'on']] as const} />
                </div>
                <Row label="Pose tips" hint="Short advice such as Lift your left arm when a limb is off">
                  <Switch checked={prefs.poseTips} onChange={(v) => setPref('poseTips', v)} label="Pose tips" />
                </Row>
                <Row label="Lighting tips" hint="Warns when it is too dark, too bright, or the light is behind you">
                  <Switch checked={prefs.lightTips} onChange={(v) => setPref('lightTips', v)} label="Lighting tips" />
                </Row>
                <Row label="Keep screen on" hint="Stops the screen from dimming here">
                  <Switch checked={prefs.keepAwake} onChange={(v) => setPref('keepAwake', v)} label="Keep screen on" />
                </Row>
              </div>
            </div>
            {det === 'ready' && delegate && <p className="mt-5 text-xs text-ink/50">Detection runs on this device ({delegate}).</p>}
          </div>
        </div>
      )}

      {/* pose picker */}
      {sheet && (
        <div className="fixed inset-0 z-30 flex flex-col justify-end bg-black/60" onClick={() => setSheet(false)}>
          <div className="sheet max-h-[75dvh] overflow-y-auto rounded-t-[2rem] bg-paper p-4 text-ink" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center gap-2">
              {favOnly ? (
                <p className="flex-1 px-2 text-lg font-black tracking-tight">Favorites</p>
              ) : (
                <div className="flex flex-1 gap-1 rounded-full bg-ink/10 p-1">
                  {MODES.map((m) => (
                    <button key={m.id} onClick={() => setSheetMode(m.id)} aria-pressed={sheetMode === m.id} className={`flex-1 rounded-full py-2 text-sm font-bold ${sheetMode === m.id ? 'bg-ink text-white' : ''}`}>{m.name}</button>
                  ))}
                </div>
              )}
              <button onClick={() => setSheet(false)} aria-label="Close" className="grid h-10 w-10 place-items-center rounded-full bg-ink/10"><Icon name="close" className="h-5 w-5" /></button>
            </div>
            <div className="mb-2 flex gap-2">
              <button onClick={() => { replace('camera'); setSheet(false); }} className="min-w-0 flex-1 rounded-2xl bg-ink/5 p-3 text-left font-bold">No guide (free camera)</button>
              <button onClick={() => setFavOnly((v) => !v)} aria-pressed={favOnly} className={`flex items-center gap-1.5 rounded-2xl px-3 font-bold ${favOnly ? 'bg-bubble' : 'bg-ink/5'}`}>
                <Icon name="heart" className="h-5 w-5" filled={favOnly} /> Favorites
              </button>
            </div>
            {sheetMoods.length > 1 && (
              <div role="group" aria-label="Filter poses by mood" className="mb-2 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                {[{ id: 'all' as const, name: 'All' }, ...sheetMoods].map((m) => (
                  <button key={m.id} onClick={() => setSheetMood(m.id)} aria-pressed={moodFilter === m.id} className={`shrink-0 rounded-full px-3.5 py-1.5 text-sm font-bold ${moodFilter === m.id ? 'bg-ink text-white' : 'bg-ink/10'}`}>{m.name}</button>
                ))}
              </div>
            )}
            {favOnly && sheetPoses.length === 0 && <p className="p-3 text-ink/70">Tap the heart on a pose to save it here.</p>}
            <ul className="grid grid-cols-2 gap-2">
              {sheetPoses.map((p) => (
                <li key={p.id} className="relative">
                  <button onClick={() => { replace('camera/' + p.id); setSheet(false); }} aria-pressed={p.id === pose?.id} className={`w-full rounded-2xl p-2 text-left ring-2 ${p.id === pose?.id ? 'ring-cobalt' : 'ring-transparent'} bg-white`}>
                    <PoseArt figures={p.figures} outlines={p.outlines} details={p.details} className="h-24 w-full rounded-xl bg-volt/60" />
                    <span className="mt-1 block text-sm font-bold leading-tight">{p.title}</span>
                  </button>
                  <div className="absolute right-3 top-3"><HeartButton poseId={p.id} title={p.title} className="h-9 w-9" /></div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {shot && <Preview shot={shot} onRetake={retake} />}
    </div>
  );
}
