import { useEffect, useRef, useState } from 'react';
import { MODES, getPose, getPoses, type Mode } from '../data/poses';
import { back, replace } from '../lib/route';
import { cameraPermissionState, errorName, explainCameraError, openCamera, type PermState, takeBestPhoto, type CameraSession, type Facing } from '../lib/camera';
import { loadDetector, type Detector } from '../lib/pose';
import { drawOverlay, type Person } from '../lib/draw';
import { matchLabel, matchScore } from '../lib/match';
import Icon from '../components/Icon';
import PoseArt from '../components/PoseArt';
import Preview, { type Shot } from '../components/Preview';

// ghost figure opacity per strength level: off (outline only), light, medium, strong
const GHOST = [0, 0.22, 0.4, 0.6] as const;
const GHOST_NAMES = ['Off', 'Light', 'Medium', 'Strong'] as const;

type CamStatus = 'starting' | 'ready' | 'error';
type DetState = 'loading' | 'ready' | 'error';

export default function CameraScreen({ poseId }: { poseId?: string }) {
  const pose = getPose(poseId);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<CameraSession | null>(null);
  const detRef = useRef<Detector | null>(null);
  const peopleRef = useRef<Person[]>([]);
  const busyRef = useRef(false);

  const [facing, setFacing] = useState<Facing>(pose?.mode === 'solo' ? 'user' : 'environment');
  const [attempt, setAttempt] = useState(0);
  const [status, setStatus] = useState<CamStatus>('starting');
  const [camError, setCamError] = useState<string | null>(null);
  const [camDetail, setCamDetail] = useState<string | null>(null);
  const [info, setInfo] = useState<{ w: number; h: number; mirrored: boolean } | null>(null);

  const [det, setDet] = useState<DetState>('loading');
  const [detMsg, setDetMsg] = useState<string | null>(null);
  const [delegate, setDelegate] = useState<string>('');
  const [peopleCount, setPeopleCount] = useState(0);
  const [match, setMatch] = useState<number | null>(null);

  const [showSkeleton, setShowSkeleton] = useState(true);
  const [showGuide, setShowGuide] = useState(true);
  const [showDetail, setShowDetail] = useState(true);
  const [ghostLevel, setGhostLevel] = useState<0 | 1 | 2 | 3>(2);
  const [timer, setTimer] = useState<0 | 3 | 10>(0);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [flash, setFlash] = useState(0);
  const [sheet, setSheet] = useState(false);
  const [sheetMode, setSheetMode] = useState<Mode>(pose?.mode ?? 'solo');
  const [steps, setSteps] = useState(false);
  const [shot, setShot] = useState<Shot | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Latest values for the animation loop, which must not restart on every change.
  const live = useRef({ showSkeleton, showGuide, showDetail, ghost: GHOST[ghostLevel], figures: pose?.figures, outlines: pose?.outlines, details: pose?.details, paused: false });
  live.current = { showSkeleton, showGuide, showDetail, ghost: GHOST[ghostLevel], figures: pose?.figures, outlines: pose?.outlines, details: pose?.details, paused: shot !== null };
  const sheetPoses = getPoses(sheetMode);

  // ---- open the camera (this is the moment the permission prompt appears) ----
  useEffect(() => {
    let cancelled = false;
    setStatus('starting');
    setCamError(null);
    setCamDetail(null);
    (async () => {
      try {
        const session = await openCamera(facing);
        if (cancelled) {
          session.stream.getTracks().forEach((t) => t.stop());
          return;
        }
        sessionRef.current = session;
        const v = videoRef.current!;
        v.srcObject = session.stream;
        await v.play();
        if (cancelled) return;
        const s = session.track.getSettings();
        setInfo({
          w: v.videoWidth || s.width || 0,
          h: v.videoHeight || s.height || 0,
          mirrored: session.facing === 'user',
        });
        setStatus('ready');
      } catch (e) {
        if (!cancelled) {
          setCamError(explainCameraError(e));
          setStatus('error');
          const name = errorName(e);
          void cameraPermissionState().then((st: PermState) => {
            if (!cancelled) setCamDetail(`Error: ${name} · site permission: ${st}`);
          });
        }
      }
    })();
    return () => {
      cancelled = true;
      sessionRef.current?.stream.getTracks().forEach((t) => t.stop());
      sessionRef.current = null;
      if (videoRef.current) videoRef.current.srcObject = null;
    };
  }, [facing, attempt]);

  // Restart if the browser ended the camera while the tab was in the background.
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible' && sessionRef.current?.track.readyState === 'ended') {
        setAttempt((n) => n + 1);
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, []);

  // ---- load MediaPipe (on-device) ----
  useEffect(() => {
    let alive = true;
    loadDetector()
      .then((d) => {
        if (!alive) return;
        detRef.current = d;
        setDelegate(d.delegate);
        setDet('ready');
      })
      .catch((e) => {
        if (!alive) return;
        setDet('error');
        setDetMsg(e instanceof Error ? e.message : 'The pose model failed to load.');
      });
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (det === 'ready') detRef.current?.setMaxPeople(Math.min(5, Math.max(1, pose ? pose.figures.length : 2)));
  }, [det, pose]);

  // ---- detection + overlay loop (about 20 frames per second) ----
  useEffect(() => {
    if (status !== 'ready') return;
    const off = document.createElement('canvas'); // small copy of the frame for the model
    const octx = off.getContext('2d');
    let raf = 0;
    let last = 0;
    let lastMatch = 0;
    let errors = 0;
    let stopped = false;

    const tick = (t: number) => {
      raf = requestAnimationFrame(tick);
      const v = videoRef.current;
      const c = canvasRef.current;
      if (stopped || live.current.paused || !v || !c || !octx || v.readyState < 2 || !v.videoWidth) return;
      if (t - last < 50) return;
      last = t;

      const d = detRef.current;
      if (d) {
        try {
          const k = 480 / Math.max(v.videoWidth, v.videoHeight);
          const w = Math.max(1, Math.round(v.videoWidth * k));
          const h = Math.max(1, Math.round(v.videoHeight * k));
          if (off.width !== w || off.height !== h) {
            off.width = w;
            off.height = h;
          }
          octx.drawImage(v, 0, 0, w, h);
          peopleRef.current = d.detect(off);
          errors = 0;
        } catch {
          if (++errors > 5) {
            detRef.current = null;
            peopleRef.current = [];
            setDet('error');
            setDetMsg('Pose detection stopped unexpectedly. Reload the page to try again.');
          }
        }
      }

      const people = peopleRef.current;
      const { showSkeleton: sk, showGuide: gd, showDetail: sd, ghost, figures, outlines, details } = live.current;
      drawOverlay(c, {
        vw: v.videoWidth,
        vh: v.videoHeight,
        persons: sk ? people : [],
        reference: gd ? figures : undefined,
        outlines: gd ? outlines : undefined,
        details: gd ? details : undefined,
        showDetail: sd,
        ghost,
      });

      if (t - lastMatch > 250) {
        lastMatch = t;
        setPeopleCount((n) => (n === people.length ? n : people.length));
        // A match score is only meaningful for a single-person reference.
        if (figures?.length === 1 && people.length > 0) {
          const s = matchScore(people[0], figures[0], v.videoWidth, v.videoHeight);
          setMatch(s === null ? null : Math.round(s * 100));
        } else {
          setMatch(null);
        }
      }
    };
    raf = requestAnimationFrame(tick);
    return () => {
      stopped = true;
      cancelAnimationFrame(raf);
    };
  }, [status]);

  // ---- capture ----
  const capture = async () => {
    const v = videoRef.current;
    const s = sessionRef.current;
    if (!v || !s || busyRef.current) return;
    busyRef.current = true;
    setNotice(null);
    try {
      const people = peopleRef.current;
      const res = await takeBestPhoto(s, v);
      const frameAspect = v.videoWidth / v.videoHeight;
      // The overlay only lines up if the photo has the same framing as the preview.
      const overlayValid = Math.abs(res.width / res.height - frameAspect) < 0.03;
      setFlash((n) => n + 1);
      setShot({
        blob: res.blob,
        url: URL.createObjectURL(res.blob),
        width: res.width,
        height: res.height,
        method: res.method,
        people,
        overlayValid,
        poseId: pose?.id ?? null,
        mirrored: s.facing === 'user',
        createdAt: Date.now(),
      });
    } catch (e) {
      setNotice(e instanceof Error ? e.message : 'The photo could not be taken. Try again.');
    } finally {
      busyRef.current = false;
    }
  };

  const onShutter = () => {
    if (countdown !== null) {
      setCountdown(null); // tap again to cancel
      return;
    }
    if (timer === 0) void capture();
    else setCountdown(timer);
  };

  useEffect(() => {
    if (countdown === null) return;
    if (countdown === 0) {
      setCountdown(null);
      void capture();
      return;
    }
    const id = setTimeout(() => setCountdown((c) => (c === null ? null : c - 1)), 1000);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [countdown]);

  const retake = () => {
    if (shot) URL.revokeObjectURL(shot.url);
    setShot(null);
  };
  useEffect(() => () => { if (shot) URL.revokeObjectURL(shot.url); }, [shot]);

  const mirrored = info?.mirrored ?? facing === 'user';

  const chip =
    det === 'loading' ? 'Loading pose model…'
    : det === 'error' ? 'Pose detection off'
    : peopleCount === 0 ? 'Step into the frame'
    : `${peopleCount} ${peopleCount === 1 ? 'person' : 'people'} tracked`;

  return (
    <div className="fixed inset-0 flex flex-col bg-black text-white">
      {/* top controls */}
      <div className="z-10 flex items-center gap-2 px-3 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <button onClick={() => back('')} aria-label="Close camera" className="cam-btn"><Icon name="back" /></button>
        <div className="min-w-0 flex-1 text-center">
          <p className="truncate text-sm font-bold">{pose ? pose.title : 'Free camera'}</p>
          <p className="truncate text-xs text-white/70">{chip}{det === 'ready' && delegate ? ` · ${delegate}` : ''}</p>
        </div>
        <button onClick={() => setShowSkeleton((v) => !v)} aria-pressed={showSkeleton} aria-label="Toggle skeleton overlay" className="cam-btn"><Icon name="skeleton" /></button>
        <button onClick={() => setShowGuide((v) => !v)} aria-pressed={showGuide} aria-label="Toggle pose guide" disabled={!pose} className="cam-btn disabled:opacity-40"><Icon name="guide" /></button>
        <button onClick={() => setTimer((t) => (t === 0 ? 3 : t === 3 ? 10 : 0))} aria-pressed={timer !== 0} aria-label={`Self-timer ${timer === 0 ? 'off' : timer + ' seconds'}`} className="cam-btn relative">
          <Icon name="timer" />
          {timer !== 0 && <span className="absolute -bottom-1 -right-1 rounded-full bg-ink px-1.5 text-[10px] font-bold text-volt">{timer}s</span>}
        </button>
      </div>

      {det === 'error' && detMsg && (
        <p role="alert" className="z-10 mx-3 mb-2 rounded-2xl bg-amber-300 px-4 py-2 text-sm font-medium text-ink">
          {detMsg} You can still take photos.
        </p>
      )}

      {/* viewfinder: the whole frame is shown (no cropping) so the photo matches what you see */}
      <div className="relative min-h-0 flex-1">
        <div className="absolute inset-0" style={mirrored ? { transform: 'scaleX(-1)' } : undefined}>
          <video ref={videoRef} playsInline muted autoPlay className="h-full w-full object-contain" />
          <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full" />
        </div>

        {status === 'starting' && <p className="absolute inset-0 grid place-items-center text-white/80">Starting camera…</p>}

        {status === 'error' && (
          <div role="alert" className="absolute inset-0 grid place-items-center p-6">
            <div className="max-w-sm rounded-3xl bg-white p-5 text-ink">
              <p className="text-lg font-extrabold">Camera unavailable</p>
              <p className="mt-1">{camError}</p>
              {camDetail && <p className="mt-2 text-xs text-ink/60">{camDetail}</p>}
              <div className="mt-4 flex gap-2">
                <button onClick={() => setAttempt((n) => n + 1)} className="btn flex-1 bg-ink text-white">Try again</button>
                <button onClick={() => back('')} className="btn bg-ink/10">Back</button>
              </div>
            </div>
          </div>
        )}

        {countdown !== null && countdown > 0 && (
          <p className="pointer-events-none absolute inset-0 grid place-items-center text-[9rem] font-black text-white drop-shadow-lg" aria-live="assertive">{countdown}</p>
        )}

        {flash > 0 && <div key={flash} className="flash pointer-events-none absolute inset-0 bg-white" />}

        {match !== null && pose && pose.figures.length === 1 && (
          <p className={`absolute left-3 top-3 rounded-full px-3 py-1.5 text-sm font-bold ${match >= 70 ? 'bg-volt text-ink' : 'bg-black/60 text-white'}`} role="status">
            {match}% · {matchLabel(match / 100)}
          </p>
        )}

        {pose && pose.figures.length > 1 && showGuide && (
          <p className="absolute left-3 top-3 rounded-full bg-black/60 px-3 py-1.5 text-xs">Match score works for solo poses</p>
        )}

        {pose && showGuide && (
          <div className="absolute right-3 top-3 flex flex-col items-end gap-2">
            <button
              onClick={() => setGhostLevel((l) => ((l + 1) % 4) as 0 | 1 | 2 | 3)}
              aria-label={`Ghost pose strength: ${GHOST_NAMES[ghostLevel]}. Tap to change`}
              className={`rounded-full px-3 py-1.5 text-sm font-bold backdrop-blur ${ghostLevel > 0 ? 'bg-volt text-ink' : 'bg-black/60 text-white'}`}
            >
              Ghost: {GHOST_NAMES[ghostLevel]}
            </button>
            {pose.outlines?.some(Boolean) && (
              <button
                onClick={() => setShowDetail((v) => !v)}
                aria-pressed={showDetail}
                className={`rounded-full px-3 py-1.5 text-sm font-bold backdrop-blur ${showDetail ? 'bg-volt text-ink' : 'bg-black/60 text-white'}`}
              >
                Guide details {showDetail ? 'on' : 'off'}
              </button>
            )}
          </div>
        )}

        {notice && <p role="alert" className="absolute inset-x-3 top-3 rounded-2xl bg-rose-600 px-4 py-2 text-sm">{notice}</p>}

        {steps && pose && (
          <div className="absolute inset-x-3 bottom-3 rounded-3xl bg-white/95 p-4 text-ink shadow-lg">
            <div className="flex items-start justify-between gap-2">
              <p className="font-extrabold">{pose.title}</p>
              <button onClick={() => setSteps(false)} aria-label="Hide steps" className="-m-1 p-1"><Icon name="close" className="h-5 w-5" /></button>
            </div>
            <ol className="mt-1 list-decimal space-y-0.5 pl-5 text-sm">{pose.steps.map((s) => <li key={s}>{s}</li>)}</ol>
            <p className="mt-2 text-sm text-ink/70"><b>Tip:</b> {pose.tip}</p>
          </div>
        )}

        {info && status === 'ready' && (
          <p className="pointer-events-none absolute bottom-2 right-3 text-[11px] text-white/60">{info.w} × {info.h} live</p>
        )}
      </div>

      {/* bottom controls */}
      <div className="z-10 grid grid-cols-3 items-center px-5 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3">
        <div className="flex items-center gap-2">
          <button onClick={() => setSheet(true)} className="flex h-14 items-center gap-2 rounded-2xl bg-white/15 px-3 text-sm font-bold active:scale-95" aria-label="Choose a pose">
            {pose ? <PoseArt figures={pose.figures} outlines={pose.outlines} detail={false} className="h-9 w-9 rounded-lg bg-volt" /> : <Icon name="poses" />}
            <span>Pose</span>
          </button>
          {pose && (
            <button onClick={() => setSteps((v) => !v)} aria-pressed={steps} aria-label="Show pose steps" className="cam-btn"><Icon name="info" /></button>
          )}
        </div>

        <button
          onClick={onShutter}
          disabled={status !== 'ready'}
          aria-label={countdown !== null ? 'Cancel timer' : 'Take photo'}
          className="mx-auto grid h-20 w-20 place-items-center rounded-full border-4 border-white transition active:scale-95 disabled:opacity-40"
        >
          <span className={`block rounded-full bg-white transition-all ${countdown !== null ? 'h-8 w-8 rounded-lg' : 'h-14 w-14'}`} />
        </button>

        <button onClick={() => setFacing((f) => (f === 'user' ? 'environment' : 'user'))} aria-label="Switch between front and rear camera" className="cam-btn ml-auto h-14 w-14 bg-white/15">
          <Icon name="flip" className="h-7 w-7" />
        </button>
      </div>

      {/* pose picker */}
      {sheet && (
        <div className="fixed inset-0 z-30 flex flex-col justify-end bg-black/60" onClick={() => setSheet(false)}>
          <div className="max-h-[75dvh] overflow-y-auto rounded-t-[2rem] bg-paper p-4 text-ink" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center gap-2">
              <div className="flex flex-1 gap-1 rounded-full bg-ink/10 p-1">
                {MODES.map((m) => (
                  <button key={m.id} onClick={() => setSheetMode(m.id)} aria-pressed={sheetMode === m.id} className={`flex-1 rounded-full py-2 text-sm font-bold ${sheetMode === m.id ? 'bg-ink text-white' : ''}`}>{m.name}</button>
                ))}
              </div>
              <button onClick={() => setSheet(false)} aria-label="Close" className="grid h-10 w-10 place-items-center rounded-full bg-ink/10"><Icon name="close" className="h-5 w-5" /></button>
            </div>
            <button onClick={() => { replace('camera'); setSheet(false); }} className="mb-2 w-full rounded-2xl bg-ink/5 p-3 text-left font-bold">No guide (free camera)</button>
            <ul className="grid grid-cols-2 gap-2">
              {sheetPoses.map((p) => (
                <li key={p.id}>
                  <button onClick={() => { replace('camera/' + p.id); setSheet(false); }} aria-pressed={p.id === pose?.id} className={`w-full rounded-2xl p-2 text-left ring-2 ${p.id === pose?.id ? 'ring-cobalt' : 'ring-transparent'} bg-white`}>
                    <PoseArt figures={p.figures} outlines={p.outlines} details={p.details} className="h-24 w-full rounded-xl bg-volt/60" />
                    <span className="mt-1 block text-sm font-bold leading-tight">{p.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {shot && <Preview shot={shot} onRetake={retake} />}
    </div>
  );
}
