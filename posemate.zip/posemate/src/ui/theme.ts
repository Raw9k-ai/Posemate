import { COLOR_KEYS, CUSTOM_FONT_FAMILY, CUSTOM_FONT_ID, DEFAULT_COLORS, FONTS, getCustomFontData, hexToTriplet, type UiState } from '../lib/ui';

let loadedFont: string | null = null; // the data URL of the font currently registered

async function ensureCustomFont(): Promise<boolean> {
  const data = getCustomFontData();
  if (!data || typeof FontFace === 'undefined') return false;
  if (loadedFont === data) return true;
  try {
    const face = new FontFace(CUSTOM_FONT_FAMILY, `url(${data})`);
    await face.load();
    document.fonts.add(face);
    loadedFont = data;
    return true;
  } catch {
    return false; // not a usable font file: fall back to the phone default
  }
}

/** Puts colours, font, text size and corner style on the page. Safe to call as often as the settings change. */
export function applyTheme(s: UiState) {
  const el = document.documentElement;
  for (const k of COLOR_KEYS) el.style.setProperty(`--c-${k}`, hexToTriplet(s.colors[k] ?? DEFAULT_COLORS[k]));
  el.style.setProperty('--ui-scale', String(s.textScale));
  if (s.corner === 'round') delete el.dataset.corner;
  else el.dataset.corner = s.corner;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', s.colors.paper ?? DEFAULT_COLORS.paper);

  const stack = FONTS.find((f) => f.id === s.font)?.stack ?? FONTS[0].stack;
  el.style.setProperty('--ui-font', stack);
  if (s.font === CUSTOM_FONT_ID) {
    void ensureCustomFont().then((ok) => {
      if (ok) el.style.setProperty('--ui-font', `'${CUSTOM_FONT_FAMILY}', ${FONTS[0].stack}`);
    });
  }
}

/** Reads a font file chosen by the person; null if it is too large or not a font. */
export async function readFontFile(file: File): Promise<string | null> {
  if (file.size > 2_000_000 || !/\.(ttf|otf|woff2?)$/i.test(file.name)) return null;
  const buf = await file.arrayBuffer();
  let bin = '';
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  const mime = /\.woff2$/i.test(file.name) ? 'font/woff2' : /\.woff$/i.test(file.name) ? 'font/woff' : /\.otf$/i.test(file.name) ? 'font/otf' : 'font/ttf';
  const url = `data:${mime};base64,${btoa(bin)}`;
  try {
    const face = new FontFace('PoseMateTest', `url(${url})`);
    await face.load(); // rejects when the file is not a real font
  } catch {
    return null;
  }
  return url;
}

/** Shrinks a picture the person chose so it is small enough to keep. `icon` keeps transparency (PNG); otherwise a JPEG. */
export async function readImage(file: File, kind: 'icon' | 'bg'): Promise<string | null> {
  if (!file.type.startsWith('image/')) return null;
  let bmp: ImageBitmap;
  try {
    bmp = await createImageBitmap(file);
  } catch {
    return null;
  }
  const edge = kind === 'icon' ? 128 : 480;
  const k = Math.min(1, edge / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(bmp.width * k));
  c.height = Math.max(1, Math.round(bmp.height * k));
  c.getContext('2d')!.drawImage(bmp, 0, 0, c.width, c.height);
  bmp.close();
  const url = kind === 'icon' ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', 0.82);
  return url.length <= 300_000 ? url : kind === 'icon' ? c.toDataURL('image/webp', 0.8) : c.toDataURL('image/jpeg', 0.6);
}
