import { getUi, normKey, subscribeUi, type ElRule, type UiState } from '../lib/ui';

// Applies the person's changes to what is on screen: renamed text, and colour / image / hidden
// tweaks on buttons and headings. It edits the page in place after React draws it, and does nothing
// at all (no observer, no work) while there are no changes saved. Everything it sets is tracked so
// it can be put back exactly.

export const EDIT_UI = '[data-edit-ui]';
export const CANDIDATES = 'button, a, [role="button"], h1, h2, h3, h4, p, li, label, [data-ui]';
const BTN = 'button, a, [role="button"]';

// ---------- text ----------

interface TextRec { orig: string; out: string }
const written = new WeakMap<Text, TextRec>();

const skipText = (n: Text) => {
  const p = n.parentElement;
  return !p || /^(SCRIPT|STYLE|TEXTAREA|INPUT)$/.test(p.tagName) || !!p.closest(EDIT_UI);
};

/** What React drew for this text node, before any rename. */
export function originalOf(n: Text): string {
  const rec = written.get(n);
  const cur = n.nodeValue ?? '';
  return rec && cur === rec.out ? rec.orig : cur;
}

export function applyText(n: Text, texts: Record<string, string>) {
  if (skipText(n)) return;
  const rec = written.get(n);
  const cur = n.nodeValue ?? '';
  const orig = rec && cur === rec.out ? rec.orig : cur;
  const key = normKey(orig);
  const to = key ? texts[key] : undefined;
  if (to !== undefined) {
    const trimmed = orig.trim();
    const out = trimmed ? orig.replace(trimmed, () => to) : orig; // keep the spaces around the text
    if (cur !== out) n.nodeValue = out;
    written.set(n, { orig, out });
  } else if (rec) {
    if (cur === rec.out) n.nodeValue = rec.orig;
    written.delete(n);
  }
}

function walkText(root: Node, fn: (n: Text) => void) {
  if (root.nodeType === 3) return fn(root as Text);
  if (root.nodeType !== 1) return;
  const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let n: Node | null;
  while ((n = tw.nextNode())) fn(n as Text);
}

// ---------- elements ----------

/** The text of an element as React drew it (renames undone), so its key does not change when it is renamed. */
function originalContent(el: Element): string {
  let out = '';
  walkText(el, (n) => {
    out += originalOf(n);
  });
  return out;
}

/** A stable key for a button or text block: its data-ui name, else its aria-label, else its text. */
export function elementKey(el: Element): string {
  const named = (el as HTMLElement).dataset?.ui || el.getAttribute('aria-label') || '';
  return (el.matches(BTN) ? 'b:' : 't:') + normKey(named || originalContent(el));
}

const FLAGS = 'data-ui-k';

function clearEl(el: HTMLElement) {
  const flags = el.getAttribute(FLAGS);
  if (flags === null) return;
  el.removeAttribute(FLAGS);
  if (flags.includes('bg')) el.style.backgroundColor = '';
  if (flags.includes('fg')) el.style.color = '';
  if (flags.includes('hid')) el.style.display = '';
  const fills = el.matches('[data-ui-img]') ? [el, ...el.querySelectorAll<HTMLElement>('[data-ui-img]')] : [...el.querySelectorAll<HTMLElement>('[data-ui-img]')];
  for (const f of fills) {
    f.style.backgroundImage = '';
    f.style.backgroundSize = '';
    f.style.backgroundPosition = '';
    f.removeAttribute('data-ui-img');
  }
  el.querySelectorAll<SVGElement>('[data-ui-svg]').forEach((s) => {
    s.style.visibility = '';
    s.removeAttribute('data-ui-svg');
  });
}

function applyEl(el: HTMLElement, rule: ElRule) {
  clearEl(el);
  const flags: string[] = [];
  if (rule.bg) {
    el.style.backgroundColor = rule.bg;
    flags.push('bg');
  }
  if (rule.fg) {
    el.style.color = rule.fg;
    flags.push('fg');
  }
  if (rule.image) {
    const target = el.querySelector<HTMLElement>('[data-ui-fill]') ?? el; // the shutter's inner disc, for example
    target.style.backgroundImage = `url("${rule.image}")`;
    target.style.backgroundSize = 'cover';
    target.style.backgroundPosition = 'center';
    target.setAttribute('data-ui-img', '1');
    flags.push('img');
    if (!el.textContent?.trim()) {
      // an icon-only button: the picture takes the icon's place
      el.querySelectorAll<SVGElement>(':scope > svg').forEach((s) => {
        s.style.visibility = 'hidden';
        s.setAttribute('data-ui-svg', '1');
      });
    }
  }
  if (rule.hidden && !el.closest('[data-no-hide]') && !el.querySelector(EDIT_UI)) {
    el.style.display = 'none';
    flags.push('hid');
  }
  el.setAttribute(FLAGS, flags.join(' '));
}

function applyElements(root: Element | Document, s: UiState) {
  const list: Element[] = [];
  if (root instanceof Element && root.matches(CANDIDATES)) list.push(root);
  root.querySelectorAll(CANDIDATES).forEach((e) => list.push(e));
  for (const el of list) {
    if (!(el instanceof HTMLElement) || el.closest(EDIT_UI)) continue;
    const rule = s.els[elementKey(el)];
    if (rule) applyEl(el, rule);
    else clearEl(el);
  }
}

// ---------- finding what was tapped (used by edit mode) ----------

/** The text node under a tap, if there is one inside `within`. */
export function textNodeAt(x: number, y: number, within: Element): Text | null {
  const d = document as Document & {
    caretRangeFromPoint?: (x: number, y: number) => Range | null;
    caretPositionFromPoint?: (x: number, y: number) => { offsetNode: Node } | null;
  };
  const node = d.caretRangeFromPoint?.(x, y)?.startContainer ?? d.caretPositionFromPoint?.(x, y)?.offsetNode ?? null;
  if (node && node.nodeType === 3 && within.contains(node) && (node.nodeValue ?? '').trim()) return node as Text;
  let found: Text | null = null;
  walkText(within, (n) => {
    if (!found && (n.nodeValue ?? '').trim() && !skipText(n)) found = n;
  });
  return found;
}

// ---------- running it ----------

export function startUiEngine(): () => void {
  let obs: MutationObserver | null = null;
  let hadRules = false;
  let raf = 0;
  const pending = new Set<Node>();

  const full = () => {
    const s = getUi();
    walkText(document.body, (n) => applyText(n, s.texts));
    applyElements(document.body, s);
  };

  const flush = () => {
    raf = 0;
    const s = getUi();
    for (const n of pending) {
      if (!n.isConnected) continue;
      walkText(n, (t) => applyText(t, s.texts));
      const el = n.nodeType === 1 ? (n as Element) : n.parentElement;
      if (el) {
        applyElements(el, s);
        const owner = el.closest(CANDIDATES); // a changed label can change its button's key
        if (owner && owner !== el) applyElements(owner, s);
      }
    }
    pending.clear();
  };

  const onMutations = (records: MutationRecord[]) => {
    for (const r of records) {
      if (r.type === 'characterData') pending.add(r.target);
      else r.addedNodes.forEach((n) => pending.add(n));
    }
    if (!raf) raf = requestAnimationFrame(flush);
  };

  const sync = () => {
    const s = getUi();
    const on = Object.keys(s.texts).length > 0 || Object.keys(s.els).length > 0;
    if (on || hadRules) full(); // one last pass puts everything back when the last change is removed
    hadRules = on;
    if (on && !obs) {
      obs = new MutationObserver(onMutations);
      obs.observe(document.body, { subtree: true, childList: true, characterData: true });
    } else if (!on && obs) {
      obs.disconnect();
      obs = null;
    }
  };

  sync();
  const off = subscribeUi(sync);
  return () => {
    off();
    obs?.disconnect();
    if (raf) cancelAnimationFrame(raf);
  };
}
