import { useSyncExternalStore } from 'react';

// Whether "tap anything to change it" mode is on. Not saved: it is always off when the app opens.
let editing = false;
const listeners = new Set<() => void>();

export const isEditing = () => editing;
export function setEditing(on: boolean) {
  if (editing === on) return;
  editing = on;
  listeners.forEach((l) => l());
}
const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => void listeners.delete(l);
};
export const useEditing = () => useSyncExternalStore(subscribe, () => editing, () => false);
