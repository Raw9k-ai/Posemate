import { useEffect, useState } from 'react';
import { go } from '../lib/route';
import { getUi, normKey, updateUi, useUi, withEl, withIcon, withText, type IconOverride } from '../lib/ui';
import { CANDIDATES, EDIT_UI, elementKey, originalOf, textNodeAt } from './engine';
import { readImage } from './theme';
import { setEditing, useEditing } from './editing';

interface Pick {
  el: HTMLElement;
  key: string;
  label: string;
  text: { orig: string; current: string } | null;
  icon: string | null;
  canHide: boolean;
}

const ROUTES: [string, string][] = [['', 'Home'], ['camera', 'Camera'], ['create', 'Make a pose'], ['gallery', 'My photos'], ['favorites', 'Favorites'], ['privacy', 'Privacy'], ['customize', 'Customize']];

const toHex = (css: string) => {
  const m = css.match(/\d+(\.\d+)?/g);
  if (!m || m.length < 3) return '#ffffff';
  return '#' + m.slice(0, 3).map((v) => Math.round(Number(v)).toString(16).padStart(2, '0')).join('');
};

function pickAt(target: Element, x: number, y: number): Pick | null {
  const el = (target.closest(CANDIDATES) as HTMLElement | null) ?? (target as HTMLElement);
  if (!el || el === document.body || el.id === 'root') return null;
  const node = textNodeAt(x, y, el);
  const iconEl = target.closest('[data-icon]') ?? el.querySelector('[data-icon]');
  const label = el.getAttribute('aria-label') || normKey(el.textContent) || 'This item';
  return {
    el,
    key: elementKey(el),
    label: label.slice(0, 40),
    text: node ? { orig: originalOf(node), current: (node.nodeValue ?? '').trim() } : null,
    icon: iconEl?.getAttribute('data-icon') ?? null,
    canHide: !el.closest('[data-no-hide]'),
  };
}

/** "Tap anything to change it": a bar at the top and, after a tap, a sheet to rename, recolour, add a picture, or hide. */
export default function EditMode() {
  const editing = useEditing();
  const ui = useUi();
  const [pick, setPick] = useState<Pick | null>(null);

  useEffect(() => {
    if (!editing) {
      setPick(null);
      return;
    }
    const inEditUi = (e: Event) => !!(e.target as Element | null)?.closest?.(EDIT_UI);
    const click = (e: MouseEvent) => {
      if (inEditUi(e)) return;
      e.preventDefault();
      e.stopPropagation();
      const t = e.target as Element | null;
      if (t) setPick(pickAt(t, e.clientX, e.clientY));
    };
    // taps must not reach the app's own handlers (taking a photo, dragging the guide, ...)
    const mute = (e: Event) => {
      if (!inEditUi(e)) e.stopPropagation();
    };
    document.addEventListener('click', click, true);
    for (const t of ['pointerdown', 'pointerup', 'pointermove', 'touchstart', 'touchend']) document.addEventListener(t, mute, true);
    return () => {
      document.removeEventListener('click', click, true);
      for (const t of ['pointerdown', 'pointerup', 'pointermove', 'touchstart', 'touchend']) document.removeEventListener(t, mute, true);
    };
  }, [editing]);

  if (!editing) return null;
  return (
    <>
      <div data-edit-ui className="fixed inset-x-0 top-0 z-[60] flex items-center gap-2 bg-ink px-3 pb-2 pt-[max(0.5rem,env(safe-area-inset-top))] text-white">
        <p className="min-w-0 flex-1 text-sm font-bold leading-tight">Tap anything to change it</p>
        <select
          aria-label="Go to screen"
          defaultValue=""
          onChange={(e) => {
            setPick(null);
            go(e.target.value);
            e.target.value = '';
          }}
          className="rounded-full bg-white/15 px-2 py-1.5 text-sm font-bold text-white"
        >
          <option value="" disabled className="text-ink">Go to…</option>
          {ROUTES.map(([path, name]) => <option key={name} value={path} className="text-ink">{name}</option>)}
        </select>
        <button onClick={() => setEditing(false)} className="rounded-full bg-volt px-4 py-1.5 text-sm font-extrabold text-ink">Done</button>
      </div>
      {pick && <Sheet key={pick.key + (pick.text?.orig ?? '')} pick={pick} onClose={() => setPick(null)} rule={ui.els[pick.key]} iconOv={pick.icon ? ui.icons[pick.icon] : undefined} />}
    </>
  );
}

function Sheet({ pick, rule, iconOv, onClose }: { pick: Pick; rule: ReturnType<typeof getUi>['els'][string] | undefined; iconOv: IconOverride | undefined; onClose: () => void }) {
  const [text, setText] = useState(pick.text?.current ?? '');
  const [bg, setBg] = useState(rule?.bg ?? toHex(getComputedStyle(pick.el).backgroundColor));
  const [fg, setFg] = useState(rule?.fg ?? toHex(getComputedStyle(pick.el).color));
  const [bgOn, setBgOn] = useState(!!rule?.bg);
  const [fgOn, setFgOn] = useState(!!rule?.fg);
  const [emoji, setEmoji] = useState(iconOv?.kind === 'emoji' ? iconOv.text : '');
  const [msg, setMsg] = useState<string | null>(null);
  const fail = () => setMsg('There is not enough space to save that. Try a smaller picture.');

  const save = () => {
    const ok = updateUi((s) => {
      let n = s;
      if (pick.text) n = withText(n, pick.text.orig, text);
      n = withEl(n, pick.key, { bg: bgOn ? bg : undefined, fg: fgOn ? fg : undefined });
      return n;
    });
    if (ok) onClose();
    else fail();
  };

  const chooseImage = async (kind: 'icon' | 'bg', apply: (url: string) => void) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async () => {
      const f = input.files?.[0];
      if (!f) return;
      const url = await readImage(f, kind);
      if (!url) return setMsg('That file could not be used as a picture.');
      apply(url);
    };
    input.click();
  };

  const section = 'space-y-2 border-t border-ink/10 pt-3';
  return (
    <div data-edit-ui className="fixed inset-x-0 bottom-0 z-[60] max-h-[70dvh] overflow-y-auto rounded-t-[2rem] bg-paper p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] text-ink shadow-2xl">
      <div className="mb-3 flex items-center justify-between gap-2">
        <p className="min-w-0 truncate text-lg font-black">{pick.label}</p>
        <button onClick={onClose} aria-label="Close" className="rounded-full bg-ink/10 px-3 py-1.5 text-sm font-bold">Close</button>
      </div>
      <div className="space-y-3">
        {pick.text && (
          <label className="block">
            <span className="text-sm font-bold">Text</span>
            <input value={text} onChange={(e) => setText(e.target.value)} maxLength={120} className="mt-1 w-full rounded-xl bg-white px-3 py-2.5 text-base" />
            <span className="text-xs text-ink/60">Changes this wording everywhere it appears. Leave it as it was to undo.</span>
          </label>
        )}

        <div className={section}>
          <div className="flex items-center gap-3">
            <input type="color" value={bg} onChange={(e) => { setBg(e.target.value); setBgOn(true); }} aria-label="Background colour" className="h-10 w-12 rounded-lg" />
            <span className="flex-1 font-bold">Background</span>
            {bgOn && <button onClick={() => setBgOn(false)} className="text-sm font-bold text-ink/70 underline">Clear</button>}
          </div>
          <div className="flex items-center gap-3">
            <input type="color" value={fg} onChange={(e) => { setFg(e.target.value); setFgOn(true); }} aria-label="Text colour" className="h-10 w-12 rounded-lg" />
            <span className="flex-1 font-bold">Text colour</span>
            {fgOn && <button onClick={() => setFgOn(false)} className="text-sm font-bold text-ink/70 underline">Clear</button>}
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => chooseImage('bg', (url) => { if (!updateUi((s) => withEl(s, pick.key, { image: url }))) fail(); else setMsg('Picture added'); })} className="rounded-full bg-ink/10 px-4 py-2 text-sm font-bold">
              {rule?.image ? 'Change picture' : 'Add a picture'}
            </button>
            {rule?.image && <button onClick={() => updateUi((s) => withEl(s, pick.key, { image: undefined }))} className="rounded-full bg-ink/10 px-4 py-2 text-sm font-bold">Remove picture</button>}
            {pick.canHide && <button onClick={() => { updateUi((s) => withEl(s, pick.key, { hidden: true })); onClose(); }} className="rounded-full bg-ink/10 px-4 py-2 text-sm font-bold">Hide it</button>}
          </div>
          {!pick.canHide && <p className="text-xs text-ink/60">This one cannot be hidden, so you can always get back to Customize.</p>}
        </div>

        {pick.icon && (
          <div className={section}>
            <p className="font-bold">Icon (changes every place it is used)</p>
            <div className="flex flex-wrap items-center gap-2">
              <button onClick={() => chooseImage('icon', (url) => { if (!updateUi((s) => withIcon(s, pick.icon!, { kind: 'image', src: url }))) fail(); else setMsg('Icon changed'); })} className="rounded-full bg-ink/10 px-4 py-2 text-sm font-bold">Use my picture</button>
              <input value={emoji} onChange={(e) => setEmoji(e.target.value)} maxLength={4} placeholder="or an emoji" aria-label="Emoji" className="w-28 rounded-xl bg-white px-3 py-2 text-base" />
              <button disabled={!emoji.trim()} onClick={() => { updateUi((s) => withIcon(s, pick.icon!, { kind: 'emoji', text: emoji.trim() })); setMsg('Icon changed'); }} className="rounded-full bg-ink/10 px-4 py-2 text-sm font-bold disabled:opacity-40">Use emoji</button>
              {iconOv && <button onClick={() => { updateUi((s) => withIcon(s, pick.icon!, null)); setEmoji(''); }} className="rounded-full bg-ink/10 px-4 py-2 text-sm font-bold">Original icon</button>}
            </div>
          </div>
        )}

        {msg && <p role="status" className="text-sm font-bold text-cobalt">{msg}</p>}
        <div className="flex gap-2 pt-1">
          <button onClick={() => { updateUi((s) => withEl(pick.text ? withText(s, pick.text.orig, '') : s, pick.key, null)); onClose(); }} className="btn-quiet flex-1">Undo changes here</button>
          <button onClick={save} className="btn-primary flex-1">Save</button>
        </div>
      </div>
    </div>
  );
}
