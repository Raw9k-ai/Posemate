import { useCallback, useEffect, useRef, useState } from 'react';
import type { Pose } from '../data/poses';
import { ACCURACIES, ACCURACY_INFO, withFallback, type Accuracy } from '../lib/accuracy';
import { loadDetector, releaseDetector, type Detector } from '../lib/pose';

export type DetState = 'loading' | 'ready' | 'error';

/** Loads the on-device pose model for the wanted accuracy and keeps the old one running while a new one loads. */
export function useDetector(wantAcc: Accuracy, pose: Pose | undefined) {
  const detRef = useRef<Detector | null>(null);
  const [det, setDet] = useState<DetState>('loading');
  const [detMsg, setDetMsg] = useState<string | null>(null);
  const [delegate, setDelegate] = useState<string>('');
  const [activeAcc, setActiveAcc] = useState<Accuracy | null>(null); // the model actually running
  const [loadingAcc, setLoadingAcc] = useState<Accuracy | null>(null); // a model being switched to
  const [accNote, setAccNote] = useState<string | null>(null); // why a different model is running
  const fail = useCallback((msg: string) => {
    detRef.current = null;
    setDet('error');
    setDetMsg(msg);
  }, []);

  // Battery saver always uses the Lite model; otherwise the Accuracy setting decides. While a new
  // model loads, the old one keeps tracking, so switching never freezes the camera.
  const maxPeopleRef = useRef(2);
  maxPeopleRef.current = Math.min(5, Math.max(1, pose ? pose.figures.length : 2));
  useEffect(() => {
    let alive = true;
    setLoadingAcc(detRef.current && detRef.current.accuracy === wantAcc ? null : wantAcc);
    withFallback(wantAcc, loadDetector)
      .then(({ value: d, used, failed }) => {
        if (!alive) return;
        detRef.current = d;
        d.setMaxPeople(maxPeopleRef.current);
        setDelegate(d.delegate);
        setActiveAcc(used);
        setLoadingAcc(null);
        setAccNote(failed ? `${ACCURACY_INFO[failed.accuracy].label} model unavailable, using Lite. ${failed.message}` : null);
        setDet('ready');
        // free every other model (a Heavy model holds a lot of memory)
        ACCURACIES.forEach((a) => a !== used && releaseDetector(a));
      })
      .catch((e) => {
        if (!alive) return;
        setLoadingAcc(null);
        setDet('error');
        setDetMsg(e instanceof Error ? e.message : 'The pose model failed to load.');
      });
    return () => {
      alive = false;
    };
  }, [wantAcc]);

  useEffect(() => {
    if (det === 'ready') detRef.current?.setMaxPeople(maxPeopleRef.current);
  }, [det, pose]);

  // Leaving the camera frees the larger models; Lite stays loaded so reopening is instant.
  useEffect(
    () => () => {
      releaseDetector('full');
      releaseDetector('heavy');
    },
    [],
  );

  return { detRef, det, detMsg, delegate, activeAcc, loadingAcc, accNote, fail };
}
