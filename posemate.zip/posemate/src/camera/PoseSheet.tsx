import { useState } from 'react';
import { MODES, MOODS, getAllPoses, getPoses, type Mode, type Mood, type Pose } from '../data/poses';
import { replace } from '../lib/route';
import { usePrefs } from '../lib/prefs';
import Icon from '../components/Icon';
import HeartButton from '../components/HeartButton';
import PoseArt from '../components/PoseArt';

/** Bottom sheet for choosing a pose while the camera is open. */
export default function PoseSheet({ pose, onClose }: { pose: Pose | undefined; onClose: () => void }) {
  const prefs = usePrefs();
  const [favOnly, setFavOnly] = useState(false);
  const [sheetMood, setSheetMood] = useState<Mood | 'all'>('all');
  const [sheetMode, setSheetMode] = useState<Mode>(pose?.mode ?? 'solo');
  const favPoses = (() => {
    const everything = getAllPoses();
    return prefs.favorites.map((id) => everything.find((p) => p.id === id)).filter((p): p is NonNullable<typeof p> => !!p);
  })();
  const sheetBase = favOnly ? favPoses : getPoses(sheetMode);
  const sheetMoods = MOODS.filter((m) => sheetBase.some((p) => p.moods?.includes(m.id)));
  // A chosen mood that this list does not have (after switching Solo/Couple/Group) shows everything.
  const moodFilter = sheetMoods.some((m) => m.id === sheetMood) ? sheetMood : 'all';
  const sheetPoses = moodFilter === 'all' ? sheetBase : sheetBase.filter((p) => p.moods?.includes(moodFilter));

  return (
    <div className="fixed inset-0 z-30 flex flex-col justify-end bg-black/60" onClick={() => onClose()}>
      <div className="sheet max-h-[75dvh] overflow-y-auto rounded-t-[2rem] bg-paper p-4 text-ink" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center gap-2">
          {favOnly ? (
            <p className="flex-1 px-2 text-lg font-black tracking-tight">Favorites</p>
          ) : (
            <div className="flex flex-1 gap-1 rounded-full bg-ink/10 p-1">
              {MODES.map((m) => (
                <button key={m.id} onClick={() => setSheetMode(m.id)} aria-pressed={sheetMode === m.id} className={`flex-1 rounded-full py-2 text-sm font-bold ${sheetMode === m.id ? 'bg-ink text-white' : ''}`}>{m.name}</button>
              ))}
            </div>
          )}
          <button onClick={() => onClose()} aria-label="Close" className="grid h-10 w-10 place-items-center rounded-full bg-ink/10"><Icon name="close" className="h-5 w-5" /></button>
        </div>
        <div className="mb-2 flex gap-2">
          <button onClick={() => { replace('camera'); onClose(); }} className="min-w-0 flex-1 rounded-2xl bg-ink/5 p-3 text-left font-bold">No guide (free camera)</button>
          <button onClick={() => setFavOnly((v) => !v)} aria-pressed={favOnly} className={`flex items-center gap-1.5 rounded-2xl px-3 font-bold ${favOnly ? 'bg-bubble' : 'bg-ink/5'}`}>
            <Icon name="heart" className="h-5 w-5" filled={favOnly} /> Favorites
          </button>
        </div>
        {sheetMoods.length > 1 && (
          <div role="group" aria-label="Filter poses by mood" className="mb-2 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {[{ id: 'all' as const, name: 'All' }, ...sheetMoods].map((m) => (
              <button key={m.id} onClick={() => setSheetMood(m.id)} aria-pressed={moodFilter === m.id} className={`shrink-0 rounded-full px-3.5 py-1.5 text-sm font-bold ${moodFilter === m.id ? 'bg-ink text-white' : 'bg-ink/10'}`}>{m.name}</button>
            ))}
          </div>
        )}
        {favOnly && sheetPoses.length === 0 && <p className="p-3 text-ink/70">Tap the heart on a pose to save it here.</p>}
        <ul className="grid grid-cols-2 gap-2">
          {sheetPoses.map((p) => (
            <li key={p.id} className="relative">
              <button onClick={() => { replace('camera/' + p.id); onClose(); }} aria-pressed={p.id === pose?.id} className={`w-full rounded-2xl p-2 text-left ring-2 ${p.id === pose?.id ? 'ring-cobalt' : 'ring-transparent'} bg-white`}>
                <PoseArt figures={p.figures} outlines={p.outlines} details={p.details} className="h-24 w-full rounded-xl bg-volt/60" />
                <span className="mt-1 block text-sm font-bold leading-tight">{p.title}</span>
              </button>
              <div className="absolute right-3 top-3"><HeartButton poseId={p.id} title={p.title} className="h-9 w-9" /></div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
