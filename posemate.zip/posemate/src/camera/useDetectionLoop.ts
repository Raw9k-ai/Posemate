import { useEffect, useRef, useState, type MutableRefObject, type RefObject } from 'react';
import { drawOverlay, type Person } from '../lib/draw';
import { computeFit, type Fit } from '../lib/fit';
import { composeFit, smoothFit, type GuideAdjust } from '../lib/guideAdjust';
import { HintKeeper, matchHint, matchScore } from '../lib/match';
import { PoseSmoother } from '../lib/smooth';
import { lockSound } from '../lib/device';
import { FrameGovernor, IDLE_AFTER_MS, IDLE_FPS } from '../lib/perf';
import { LightLog, LightWatcher, analyzeLight, lightIssue, subjectBox, type LightIssue, type LightStats } from '../lib/light';
import type { Detector } from '../lib/pose';
import { SNAP_ENTER, SNAP_HOLD_MS, SNAP_RELEASE, type LiveState } from './constants';
import type { CamStatus } from './useCameraStream';

export interface LightReading {
  stats: LightStats;
  issue: LightIssue | null; // what the check says right now
  shown: LightIssue | null; // what is shown after the hold time
}

/**
 * Runs pose detection and draws the overlay (up to 20 times a second, adapting to the phone),
 * measures the light, scores the match, and handles auto-snap. Reads settings from `live` so the
 * loop never restarts when a setting changes.
 */
export function useDetectionLoop(o: {
  status: CamStatus;
  videoRef: RefObject<HTMLVideoElement | null>;
  canvasRef: RefObject<HTMLCanvasElement | null>;
  detRef: MutableRefObject<Detector | null>;
  peopleRef: MutableRefObject<Person[]>;
  live: MutableRefObject<LiveState>;
  captureRef: MutableRefObject<() => void>;
  adjRef: MutableRefObject<GuideAdjust>; // the person's own move/resize of the guide
  redrawRef: MutableRefObject<(() => void) | null>; // lets a finger drag redraw between detections
  onDetectorFailed: (msg: string) => void;
}) {
  const { status, videoRef, canvasRef, detRef, peopleRef, live, captureRef, adjRef, redrawRef, onDetectorFailed } = o;
  const [peopleCount, setPeopleCount] = useState(0);
  const [match, setMatch] = useState<number | null>(null);
  const [hold, setHold] = useState<number | null>(null); // auto-snap progress 0..1
  const [fps, setFps] = useState(0); // detections per second, measured
  const [eased, setEased] = useState(false); // slowed down because the phone could not keep up
  const [lightTip, setLightTip] = useState<LightIssue | null>(null);
  const [lightReading, setLightReading] = useState<LightReading | null>(null);
  const [poseHint, setPoseHint] = useState<string | null>(null);
  const watcher = useRef(new LightWatcher()).current;
  const hintKeeper = useRef(new HintKeeper()).current;
  const lightLog = useRef(new LightLog()).current;

  useEffect(() => {
    if (status !== 'ready') return;
    const off = document.createElement('canvas'); // small copy of the frame for the model
    const octx = off.getContext('2d');
    let raf = 0;
    let last = 0;
    let lastMatch = 0;
    let errors = 0;
    let stopped = false;
    const smoother = new PoseSmoother();
    const gov = new FrameGovernor();
    let lastSeen = 0; // last time someone was in the frame
    let fpsCount = 0;
    let fpsT = 0;
    const lightCanvas = document.createElement('canvas'); // 64 x 36 copy, only used to measure brightness
    lightCanvas.width = 64;
    lightCanvas.height = 36;
    const lctx = lightCanvas.getContext('2d', { willReadFrequently: true });
    let lastLight = 0;
    let holdStart: number | null = null;
    let armed = true; // after a snap, the person must move out of the pose before it can fire again

    let autoFit: Fit | null = null;
    let fitSeen = 0;
    const draw = () => {
      const v = videoRef.current;
      const c = canvasRef.current;
      if (!v || !c || !v.videoWidth) return;
      const { showSkeleton: sk, showGuide: gd, showDetail: sd, ghost, ghostPhotos, figures, outlines, details } = live.current;
      drawOverlay(c, {
        vw: v.videoWidth,
        vh: v.videoHeight,
        persons: sk ? peopleRef.current : [],
        reference: gd ? figures : undefined,
        outlines: gd ? outlines : undefined,
        details: gd ? details : undefined,
        showDetail: sd,
        ghost,
        ghostPhotos: gd ? ghostPhotos : undefined,
        fit: gd && figures ? composeFit(autoFit, adjRef.current, v.videoWidth, v.videoHeight) : null,
      });
    };
    redrawRef.current = draw;

    const tick = (t: number) => {
      raf = requestAnimationFrame(tick);
      const v = videoRef.current;
      const c = canvasRef.current;
      if (stopped || live.current.paused || !v || !c || !octx || v.readyState < 2 || !v.videoWidth) return;
      if (!lastSeen) lastSeen = fpsT = t;
      gov.setSaver(live.current.saver);
      gov.setLight(live.current.light);
      // With nobody in the frame there is nothing to track: only check now and then.
      const idle = t - lastSeen > IDLE_AFTER_MS;
      if (t - last < (idle ? Math.max(gov.interval, 1000 / IDLE_FPS) : gov.interval)) return;
      last = t;
      const work0 = performance.now();

      const d = detRef.current;
      if (d) {
        try {
          // The model resizes to about 256 px itself, so a smaller copy loses little and costs less.
          const k = (live.current.saver || live.current.light ? 320 : 480) / Math.max(v.videoWidth, v.videoHeight);
          const w = Math.max(1, Math.round(v.videoWidth * k));
          const h = Math.max(1, Math.round(v.videoHeight * k));
          if (off.width !== w || off.height !== h) {
            off.width = w;
            off.height = h;
          }
          octx.drawImage(v, 0, 0, w, h);
          peopleRef.current = smoother.apply(d.detect(off), t);
          if (peopleRef.current.length > 0) lastSeen = t;
          errors = 0;
        } catch {
          if (++errors > 5) {
            peopleRef.current = [];
            onDetectorFailed('Pose detection stopped unexpectedly. Reload the page to try again.');
          }
        }
      }

      const people = peopleRef.current;

      // Lighting check, twice a second.
      if (t - lastLight > 500) {
        lastLight = t;
        if (!lctx || (!live.current.lightTips && !live.current.lightDebug)) {
          watcher.reset();
          setLightTip(null);
          setLightReading(null);
        } else {
          try {
            lctx.drawImage(v, 0, 0, 64, 36);
            const stats = analyzeLight(lctx.getImageData(0, 0, 64, 36).data, 64, 36, subjectBox(people));
            const issue = lightIssue(stats);
            const shown = watcher.update(issue, t);
            setLightTip(live.current.lightTips ? shown : null);
            if (live.current.lightDebug) {
              lightLog.add({ t, stats, issue, shown, people: people.length });
              setLightReading({ stats, issue, shown });
            } else {
              setLightReading(null);
            }
          } catch {
            /* the frame could not be read this time; try again next time */
          }
        }
      }

      // "Fit to me": ease the guide onto the person's size and position; hold the last fit briefly if they step out.
      const Lv = live.current;
      const figures = Lv.figures;
      if (Lv.follow && Lv.showGuide && Lv.figures && people.length > 0) {
        const f = computeFit(people, Lv.figures, v.videoWidth, v.videoHeight);
        if (f) {
          autoFit = smoothFit(autoFit, f);
          fitSeen = t;
        } else if (t - fitSeen > 800) autoFit = null;
      } else if (!Lv.follow || t - fitSeen > 800) {
        autoFit = null;
      }
      draw();

      gov.record(performance.now() - work0, t);
      fpsCount++;
      if (t - fpsT >= 1000) {
        setFps(Math.round((fpsCount * 1000) / (t - fpsT)));
        setEased(gov.eased);
        fpsCount = 0;
        fpsT = t;
      }

      if (t - lastMatch > 250) {
        lastMatch = t;
        setPeopleCount((n) => (n === people.length ? n : people.length));
        // A match score is only meaningful for a single-person reference.
        let s: number | null = null;
        if (figures?.length === 1 && people.length > 0) {
          s = matchScore(people[0], figures[0], v.videoWidth, v.videoHeight);
        }
        setMatch(s === null ? null : Math.round(s * 100));

        // One short piece of advice about the limb that is furthest off (not once the pose is nailed).
        const wantHint = live.current.poseTips && s !== null && s < 0.85 && figures?.length === 1 && people.length > 0;
        setPoseHint(hintKeeper.update(wantHint ? matchHint(people[0], figures[0], v.videoWidth, v.videoHeight) : null, t));

        // Auto-snap: hold the pose for a moment and the photo is taken.
        const L = live.current;
        if (s === null || s < SNAP_RELEASE) armed = true;
        if (L.autoSnap && L.idle && armed && s !== null && s >= (holdStart === null ? SNAP_ENTER : SNAP_RELEASE)) {
          if (holdStart === null) {
            holdStart = t;
            if (L.sound) lockSound();
          }
          const progress = Math.min(1, (t - holdStart) / SNAP_HOLD_MS);
          if (progress >= 1) {
            holdStart = null;
            armed = false;
            setHold(null);
            captureRef.current();
          } else {
            setHold(progress);
          }
        } else {
          holdStart = null;
          setHold(null);
        }
      }
    };
    raf = requestAnimationFrame(tick);
    return () => {
      stopped = true;
      redrawRef.current = null;
      cancelAnimationFrame(raf);
    };
  }, [status]);

  const dismissLightTip = () => {
    watcher.dismiss();
    setLightTip(null);
  };

  return { peopleCount, match, hold, fps, eased, lightTip, lightReading, lightLog, poseHint, dismissLightTip };
}
