import { useState } from 'react';
import { LIGHT_THRESHOLDS, type LightLog } from '../lib/light';
import type { LightReading } from './useDetectionLoop';

const n1 = (n: number | null) => (n === null ? '-' : String(Math.round(n)));
const pc = (n: number | null) => (n === null ? '-' : Math.round(n * 100) + '%');

/** Small readout of the light measurements for tuning the tips on a real phone. Not shown unless switched on. */
export default function LightDebugPanel({ reading, log, people }: { reading: LightReading | null; log: LightLog; people: number }) {
  const [msg, setMsg] = useState<string | null>(null);
  const flash = (m: string) => {
    setMsg(m);
    setTimeout(() => setMsg(null), 2000);
  };
  const copy = async () => {
    if (log.size === 0) return flash('Nothing recorded yet');
    try {
      await navigator.clipboard.writeText(log.toCsv());
      flash(`Copied ${log.size} readings`);
    } catch {
      flash('Copy was blocked by the browser');
    }
  };
  const s = reading?.stats;
  const T = LIGHT_THRESHOLDS;
  return (
    <div className="absolute bottom-12 left-3 max-w-[78%] rounded-2xl bg-black/75 p-2 font-mono text-[11px] leading-snug text-white" role="status">
      {s ? (
        <>
          <p>frame {n1(s.mean)} bright, {pc(s.clipped)} blown out ({people} {people === 1 ? 'person' : 'people'})</p>
          <p>person {n1(s.subject)} (dark under {T.darkSubject}), {pc(s.subjectClipped)} blown out (bright over {pc(T.brightSubject)})</p>
          <p>behind {n1(s.background)} (backlit if person is under {pc(T.backlitRatio)} of it and it is over {T.backlitBgMin})</p>
          <p>check says: {reading?.issue ?? 'ok'} | shown: {reading?.shown ?? 'nothing'}</p>
        </>
      ) : (
        <p>Waiting for a reading…</p>
      )}
      <div className="mt-1.5 flex flex-wrap gap-1.5 font-sans">
        <button onClick={() => (log.mark('tip wrong') ? flash('Marked: tip was wrong') : flash('Nothing recorded yet'))} className="rounded-full bg-white/20 px-2.5 py-1 text-xs font-bold">Tip wrong</button>
        <button onClick={() => (log.mark('missed') ? flash('Marked: missed a problem') : flash('Nothing recorded yet'))} className="rounded-full bg-white/20 px-2.5 py-1 text-xs font-bold">Missed it</button>
        <button onClick={copy} className="rounded-full bg-volt px-2.5 py-1 text-xs font-bold text-ink">Copy log</button>
        <button onClick={() => { log.clear(); flash('Cleared'); }} className="rounded-full bg-white/20 px-2.5 py-1 text-xs font-bold">Clear</button>
      </div>
      {msg && <p className="mt-1 font-sans font-bold text-volt">{msg}</p>}
    </div>
  );
}
