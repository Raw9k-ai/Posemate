import { useEffect, useState, type MutableRefObject } from 'react';
import type { Pose } from '../data/poses';
import type { GhostBitmap } from '../lib/draw';
import { setPref, usePrefs } from '../lib/prefs';
import type { LiveState } from './constants';

/** What is drawn on the camera view: guide, skeleton, ghost strength and style, and the decoded photo ghost. */
export function useGuideOptions(pose: Pose | undefined, live: MutableRefObject<LiveState>) {
  const prefs = usePrefs(); // skeleton, detail lines and ghost strength are remembered between visits
  const showSkeleton = prefs.showSkeleton;
  const showDetail = prefs.showDetail;
  const ghostLevel = prefs.ghostLevel;
  const setShowSkeleton = (v: boolean) => setPref('showSkeleton', v);
  const setShowDetail = (v: boolean) => setPref('showDetail', v);
  const setGhostLevel = (v: 0 | 1 | 2 | 3) => setPref('ghostLevel', v);
  const [showGuide, setShowGuide] = useState(true);
  const [photoGhost, setPhotoGhost] = useState(true);
  const [ghostBitmaps, setGhostBitmaps] = useState<(GhostBitmap | null)[] | undefined>(undefined);

  // ---- decode the pose's photo ghost (only exists if the user opted in when creating it) ----
  const ghostSrc = pose?.ghostPhotos;
  useEffect(() => {
    if (!ghostSrc?.some(Boolean)) {
      setGhostBitmaps(undefined);
      return;
    }
    let alive = true;
    const made: ImageBitmap[] = [];
    void Promise.all(
      ghostSrc.map(async (g): Promise<GhostBitmap | null> => {
        if (!g) return null;
        try {
          const bitmap = await createImageBitmap(g.blob);
          made.push(bitmap);
          return { bitmap, box: g.box, mirrored: g.mirrored };
        } catch {
          return null; // undecodable: that figure falls back to the shape ghost
        }
      }),
    ).then((list) => {
      if (alive) setGhostBitmaps(list);
      else made.forEach((b) => b.close());
    });
    return () => {
      alive = false;
      live.current.ghostPhotos = undefined; // stop the draw loop using bitmaps we are about to release
      setGhostBitmaps(undefined);
      made.forEach((b) => b.close());
    };
  }, [ghostSrc]);

  return { showSkeleton, setShowSkeleton, showGuide, setShowGuide, showDetail, setShowDetail, ghostLevel, setGhostLevel, photoGhost, setPhotoGhost, ghostBitmaps };
}
