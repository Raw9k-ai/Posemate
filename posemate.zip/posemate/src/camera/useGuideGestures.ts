import { useEffect, useRef, type MutableRefObject, type RefObject } from 'react';
import { fitRect } from '../lib/draw';
import { IDENTITY, clampAdjust, dragBy, isIdentity, pinchBy, type GuideAdjust } from '../lib/guideAdjust';

/**
 * One finger moves the guide, two fingers resize it (and move it with their midpoint).
 * The box must cover the viewfinder; it only listens when `enabled`.
 */
export function useGuideGestures(o: {
  enabled: boolean;
  boxRef: RefObject<HTMLDivElement | null>;
  videoRef: RefObject<HTMLVideoElement | null>;
  adjRef: MutableRefObject<GuideAdjust>;
  redrawRef: MutableRefObject<(() => void) | null>;
  mirrored: boolean;
  onAdjusted: (adjusted: boolean) => void;
}) {
  const { enabled, boxRef, videoRef, adjRef, redrawRef, mirrored, onAdjusted } = o;
  const mirroredRef = useRef(mirrored);
  mirroredRef.current = mirrored;

  useEffect(() => {
    const box = boxRef.current;
    if (!enabled || !box) return;
    const pts = new Map<number, { x: number; y: number }>();
    let raf = 0;
    const redraw = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        redrawRef.current?.();
      });
    };
    const scaleK = () => {
      const v = videoRef.current;
      if (!v || !v.videoWidth) return null;
      const r = fitRect(box.clientWidth, box.clientHeight, v.videoWidth, v.videoHeight);
      return { k: r.w / v.videoWidth, vw: v.videoWidth, vh: v.videoHeight };
    };
    const spread = () => {
      const [a, b] = [...pts.values()];
      return Math.hypot(a.x - b.x, a.y - b.y);
    };

    const down = (e: PointerEvent) => {
      if (pts.size >= 2) return;
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      try {
        box.setPointerCapture(e.pointerId);
      } catch {
        /* capture is optional */
      }
    };
    const move = (e: PointerEvent) => {
      const prev = pts.get(e.pointerId);
      const s = scaleK();
      if (!prev || !s) return;
      const before = pts.size === 2 ? spread() : 0;
      const beforeMid = pts.size === 2 ? [...pts.values()].reduce((m, p) => ({ x: m.x + p.x / 2, y: m.y + p.y / 2 }), { x: 0, y: 0 }) : prev;
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      let a = adjRef.current;
      if (pts.size === 2) {
        const now = spread();
        if (before > 10) a = pinchBy(a, now / before);
        const mid = [...pts.values()].reduce((m, p) => ({ x: m.x + p.x / 2, y: m.y + p.y / 2 }), { x: 0, y: 0 });
        a = dragBy(a, mid.x - beforeMid.x, mid.y - beforeMid.y, s.k, mirroredRef.current);
      } else {
        a = dragBy(a, e.clientX - prev.x, e.clientY - prev.y, s.k, mirroredRef.current);
      }
      adjRef.current = clampAdjust(a, s.vw, s.vh);
      redraw();
    };
    const up = (e: PointerEvent) => {
      pts.delete(e.pointerId);
      onAdjusted(!isIdentity(adjRef.current));
    };

    box.addEventListener('pointerdown', down);
    box.addEventListener('pointermove', move);
    box.addEventListener('pointerup', up);
    box.addEventListener('pointercancel', up);
    return () => {
      box.removeEventListener('pointerdown', down);
      box.removeEventListener('pointermove', move);
      box.removeEventListener('pointerup', up);
      box.removeEventListener('pointercancel', up);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [enabled, boxRef, videoRef, adjRef, redrawRef, onAdjusted]);
}

export { IDENTITY };
