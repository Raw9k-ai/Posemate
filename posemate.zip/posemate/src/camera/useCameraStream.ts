import { useEffect, useRef, useState } from 'react';
import { cameraPermissionState, errorName, explainCameraError, openCamera, type CameraSession, type Facing, type PermState } from '../lib/camera';

export type CamStatus = 'starting' | 'ready' | 'error';

/** Opens the camera (this is the moment the permission prompt appears) and restarts it if the browser ended it. */
export function useCameraStream(initialFacing: Facing) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const sessionRef = useRef<CameraSession | null>(null);
  const [facing, setFacing] = useState<Facing>(initialFacing);
  const [attempt, setAttempt] = useState(0);
  const [status, setStatus] = useState<CamStatus>('starting');
  const [camError, setCamError] = useState<string | null>(null);
  const [camDetail, setCamDetail] = useState<string | null>(null);
  const [info, setInfo] = useState<{ w: number; h: number; mirrored: boolean } | null>(null);

  useEffect(() => {
    let cancelled = false;
    setStatus('starting');
    setCamError(null);
    setCamDetail(null);
    (async () => {
      try {
        const session = await openCamera(facing);
        if (cancelled) {
          session.stream.getTracks().forEach((t) => t.stop());
          return;
        }
        sessionRef.current = session;
        const v = videoRef.current!;
        v.srcObject = session.stream;
        await v.play();
        if (cancelled) return;
        const s = session.track.getSettings();
        setInfo({
          w: v.videoWidth || s.width || 0,
          h: v.videoHeight || s.height || 0,
          mirrored: session.facing === 'user',
        });
        setStatus('ready');
      } catch (e) {
        if (!cancelled) {
          setCamError(explainCameraError(e));
          setStatus('error');
          const name = errorName(e);
          void cameraPermissionState().then((st: PermState) => {
            if (!cancelled) setCamDetail(`Error: ${name}. Site permission: ${st}`);
          });
        }
      }
    })();
    return () => {
      cancelled = true;
      sessionRef.current?.stream.getTracks().forEach((t) => t.stop());
      sessionRef.current = null;
      if (videoRef.current) videoRef.current.srcObject = null;
    };
  }, [facing, attempt]);

  // Restart if the browser ended the camera while the tab was in the background.
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible' && sessionRef.current?.track.readyState === 'ended') {
        setAttempt((n) => n + 1);
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, []);

  return { videoRef, sessionRef, facing, setFacing, status, camError, camDetail, info, retry: () => setAttempt((n) => n + 1) };
}
