import { ACCURACIES, ACCURACY_INFO } from '../lib/accuracy';
import { primeAudio, requestTiltPermission, type useLowBattery, type useTilt } from '../lib/device';
import { setPref, usePrefs } from '../lib/prefs';
import { BURST_COUNT } from '../lib/burst';
import Icon from '../components/Icon';
import { go } from '../lib/route';
import { Row, Segmented, Switch } from '../components/Controls';
import { BURST_FRAMES_LIGHT } from '../lib/perf';
import { deviceLooksLowEnd } from '../lib/useLightMode';
import type { Pose } from '../data/poses';
import type { useDetector } from './useDetector';
import type { useGuideOptions } from './useGuideOptions';

/** The guide settings sheet: what is drawn, and the camera's behaviour. */
export default function GuideSettings({
  pose, g, d, tilt, autoOk, saverOn, battery, onClose,
}: {
  pose: Pose | undefined;
  g: ReturnType<typeof useGuideOptions>;
  d: ReturnType<typeof useDetector>;
  tilt: ReturnType<typeof useTilt>;
  autoOk: boolean;
  saverOn: boolean;
  battery: ReturnType<typeof useLowBattery>;
  onClose: () => void;
}) {
  const prefs = usePrefs();
  const { showSkeleton, setShowSkeleton, showGuide, setShowGuide, showDetail, setShowDetail, ghostLevel, setGhostLevel, photoGhost, setPhotoGhost, ghostBitmaps } = g;
  const { det, delegate, accNote, activeAcc, loadingAcc } = d;

  return (
    <div className="fixed inset-0 z-30 flex flex-col justify-end bg-black/60" onClick={() => onClose()}>
      <div className="sheet max-h-[80dvh] overflow-y-auto rounded-t-[2rem] bg-paper p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] text-ink" onClick={(e) => e.stopPropagation()}>
        <div className="mb-5 flex items-center justify-between">
          <p className="text-xl font-black tracking-tight">Guide settings</p>
          <button onClick={() => onClose()} aria-label="Close" className="grid h-10 w-10 place-items-center rounded-full bg-ink/10"><Icon name="close" className="h-5 w-5" /></button>
        </div>
        <div className="space-y-5">
          <Row label="Pose guide" hint={pose ? 'The outline and ghost to line up with' : 'Pick a pose to use the guide'}>
            <Switch checked={!!pose && showGuide} disabled={!pose} onChange={setShowGuide} label="Pose guide" />
          </Row>
          {pose && showGuide && (
            <>
              <div>
                <p className="mb-2 font-bold">Ghost strength</p>
                <Segmented label="Ghost strength" value={ghostLevel} onChange={(v) => setGhostLevel(v as 0 | 1 | 2 | 3)} options={[['Off', 0], ['Light', 1], ['Medium', 2], ['Strong', 3]] as const} />
              </div>
              {ghostBitmaps?.some(Boolean) && (
                <div>
                  <p className="mb-2 font-bold">Ghost style</p>
                  <Segmented label="Ghost style" value={photoGhost ? 'photo' : 'shape'} onChange={(v) => setPhotoGhost(v === 'photo')} options={[['Shape', 'shape'], ['Photo', 'photo']] as const} />
                </div>
              )}
              {pose.outlines?.some(Boolean) && (
                <Row label="Body-part lines and skeleton" hint="Shows where arms, legs and head go">
                  <Switch checked={showDetail} onChange={setShowDetail} label="Body-part lines and skeleton" />
                </Row>
              )}
            </>
          )}
          {pose && showGuide && (
            <>
              <Row label="Fit guide to me" hint="The guide scales and moves onto your body, so you only compare the pose">
                <Switch checked={prefs.follow} onChange={(v) => setPref('follow', v)} label="Fit guide to me" />
              </Row>
              <Row label="Move guide with fingers" hint="Drag with one finger, pinch with two. Reset guide appears on the camera">
                <Switch checked={prefs.guideMove} onChange={(v) => setPref('guideMove', v)} label="Move guide with fingers" />
              </Row>
            </>
          )}
          <Row label="Live skeleton" hint="Your own body, as the camera sees it">
            <Switch checked={showSkeleton} onChange={setShowSkeleton} label="Live skeleton" />
          </Row>
          <Row
            label="Level line"
            hint={
              prefs.levelLine && tilt.status === 'unavailable'
                ? 'No tilt readings. Allow Motion sensors for this site in your browser settings.'
                : 'Shows how the phone is tilted so the horizon stays straight'
            }
          >
            <Switch
              checked={prefs.levelLine}
              onChange={async (v) => {
                if (v) await requestTiltPermission(); // iPhones ask; Android does not
                setPref('levelLine', v);
              }}
              label="Level line"
            />
          </Row>
          <div className="space-y-5 border-t border-ink/10 pt-5">
            <Row label="Auto-snap" hint={autoOk ? 'Takes the photo when you hold the pose' : 'Works with solo poses'}>
              <Switch checked={autoOk && prefs.autoSnap} disabled={!autoOk} onChange={(v) => { primeAudio(); setPref('autoSnap', v); }} label="Auto-snap" />
            </Row>
            <Row label="Candid burst" hint={`Takes ${BURST_COUNT} frames in a row (${BURST_FRAMES_LIGHT} in light mode), then you pick one. Frames are the live view size, not full sensor.`}>
              <Switch checked={prefs.burst} onChange={(v) => setPref('burst', v)} label="Candid burst" />
            </Row>
            <Row label="Sounds and vibration" hint="Timer ticks, shutter click and a small buzz">
              <Switch checked={prefs.sound} onChange={(v) => { primeAudio(); setPref('sound', v); }} label="Sounds" />
            </Row>
            <div>
              <p className="font-bold">Performance</p>
              <p className="mb-2 text-sm text-ink/60">
                {prefs.perf === 'light'
                  ? 'Light mode: tracks up to 15 times a second from a smaller image, no blur or entrance animations, smaller burst frames'
                  : prefs.perf === 'full'
                    ? 'Full: no limits besides the Battery saver and automatic slowing down'
                    : deviceLooksLowEnd
                      ? 'Auto: this phone looks like an older one, so light mode is on'
                      : 'Auto: light mode switches on by itself for older phones. This phone runs in full mode'}
              </p>
              <Segmented label="Performance" value={prefs.perf} onChange={(v) => setPref('perf', v)} options={[['Auto', 'auto'], ['Light', 'light'], ['Full', 'full']] as const} />
            </div>
            <div>
              <p className="font-bold">Accuracy</p>
              <p className="mb-2 text-sm text-ink/60">
                {saverOn
                  ? 'Battery saver is on, so the Lite model is used'
                  : `${ACCURACY_INFO[prefs.accuracy].blurb}.${prefs.accuracy === 'lite' ? '' : ` Saved on this phone the first time (about ${ACCURACY_INFO[prefs.accuracy].mb} MB).`}`}
              </p>
              <Segmented label="Accuracy" value={prefs.accuracy} onChange={(v) => setPref('accuracy', v)} options={ACCURACIES.map((a) => [ACCURACY_INFO[a].label, a] as const)} />
              {accNote && !saverOn && <p role="status" className="mt-2 text-sm text-amber-700">{accNote}</p>}
              {activeAcc && !saverOn && activeAcc !== prefs.accuracy && !accNote && loadingAcc === null && (
                <p className="mt-2 text-sm text-ink/60">Running {ACCURACY_INFO[activeAcc].label}.</p>
              )}
            </div>
            <div>
              <p className="font-bold">Battery saver</p>
              <p className="mb-2 text-sm text-ink/60">
                {prefs.saver === 'on'
                  ? 'Tracks up to 10 times a second to use less power'
                  : prefs.saver === 'off'
                    ? 'Tracks up to 20 times a second, and slows down by itself if your phone cannot keep up'
                    : battery.supported
                      ? 'Switches on at 20% battery or less when unplugged'
                      : 'This browser does not share battery level, so Auto stays off'}
              </p>
              <Segmented label="Battery saver" value={prefs.saver} onChange={(v) => setPref('saver', v)} options={[['Off', 'off'], ['Auto', 'auto'], ['On', 'on']] as const} />
            </div>
            <Row label="Pose tips" hint="Short advice such as Lift your left arm when a limb is off">
              <Switch checked={prefs.poseTips} onChange={(v) => setPref('poseTips', v)} label="Pose tips" />
            </Row>
            <Row label="Lighting tips" hint="Warns when it is too dark, too bright, or the light is behind you">
              <Switch checked={prefs.lightTips} onChange={(v) => setPref('lightTips', v)} label="Lighting tips" />
            </Row>
            <Row label="Lighting readout" hint="Shows the measured light numbers on the camera, to help tune the tips">
                  <Switch checked={prefs.lightDebug} onChange={(v) => setPref('lightDebug', v)} label="Lighting readout" />
                </Row>
                <Row label="Keep screen on" hint="Stops the screen from dimming here">
              <Switch checked={prefs.keepAwake} onChange={(v) => setPref('keepAwake', v)} label="Keep screen on" />
            </Row>
          </div>
        </div>
        <button data-no-hide onClick={() => go('customize')} className="btn-quiet mt-5 w-full">Customize look and icons</button>
        {det === 'ready' && delegate && <p className="mt-5 text-xs text-ink/50">Detection runs on this device ({delegate}).</p>}
      </div>
    </div>
  );
}
