import type { Pose } from '../data/poses';
import type { GhostBitmap } from '../lib/draw';

// ghost figure opacity per strength level: off (outline only), light, medium, strong
export const GHOST = [0, 0.22, 0.4, 0.6] as const;

// Auto-snap: the match score must reach SNAP_ENTER, then stay above SNAP_RELEASE for SNAP_HOLD_MS.
// These are first guesses; tune them on a real phone.
export const SNAP_ENTER = 0.8;
export const SNAP_RELEASE = 0.65;
export const SNAP_HOLD_MS = 1500;

/** Latest values for the animation loop, which must not restart on every change. */
export interface LiveState {
  showSkeleton: boolean;
  showGuide: boolean;
  showDetail: boolean;
  ghost: number;
  ghostPhotos: (GhostBitmap | null)[] | undefined;
  figures: Pose['figures'] | undefined;
  outlines: Pose['outlines'];
  details: Pose['details'];
  paused: boolean;
  autoSnap: boolean;
  sound: boolean;
  idle: boolean;
  saver: boolean;
  follow: boolean; // the guide eases onto the person (Fit to me)
  light: boolean; // light mode for slower phones
  lightTips: boolean;
  lightDebug: boolean;
  poseTips: boolean;
}
