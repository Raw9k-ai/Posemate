// Pose library.
//
// Each pose has one or more "figures". A figure is 13 joints in a square
// 0..1 box, drawn as seen from the camera (the person's LEFT side is on the
// image RIGHT, same convention MediaPipe uses). The same data drives:
//   - the card illustrations (PoseArt)
//   - the live guide on the camera screen
//   - the match score (solo poses)

export type JointName =
  | 'nose' | 'lSh' | 'rSh' | 'lEl' | 'rEl' | 'lWr' | 'rWr'
  | 'lHip' | 'rHip' | 'lKn' | 'rKn' | 'lAn' | 'rAn';

export type Figure = Record<JointName, [number, number]>;
export type Mode = 'solo' | 'couple' | 'group';
export type SceneId = 'campus' | 'cafe' | 'bedroom' | 'beach' | 'tourist';

/** A closed body outline in the same 0..1 square as the figure joints. */
export type Outline = [number, number][];

/** A thin body-part contour (border between arm / torso / leg etc.) in the same 0..1 square. */
export type Stroke = [number, number][];

/** A faded cut-out of the reference person (opt-in, stored on this device) shown as the camera ghost. */
export interface GhostPhoto {
  blob: Blob;
  /** Where the image sits in the 0..1 guide square: x0, y0, x1, y1. */
  box: [number, number, number, number];
  /** True when the pose was flipped left/right, so the image is drawn mirrored. */
  mirrored: boolean;
}

export interface Pose {
  id: string;
  title: string;
  mode: Mode;
  scenes: SceneId[];
  steps: string[];
  tip: string;
  figures: Figure[];
  /** Optional traced body outline per figure (same order). null = draw from joints. */
  outlines?: (Outline | null)[];
  /** Optional inner detail lines per figure (same order), drawn inside the outline. */
  details?: (Stroke[] | null)[];
  /** Optional photo ghost per figure (same order). Only present if the user opted in. */
  ghostPhotos?: (GhostPhoto | null)[];
  custom?: boolean;
  createdAt?: number;
}

export const BONES: [JointName, JointName][] = [
  ['lSh', 'rSh'], ['lSh', 'lEl'], ['lEl', 'lWr'], ['rSh', 'rEl'], ['rEl', 'rWr'],
  ['lSh', 'lHip'], ['rSh', 'rHip'], ['lHip', 'rHip'],
  ['lHip', 'lKn'], ['lKn', 'lAn'], ['rHip', 'rKn'], ['rKn', 'rAn'],
];

export interface ModeMeta { id: Mode; name: string; blurb: string; bg: string }
export const MODES: ModeMeta[] = [
  { id: 'solo', name: 'Solo', blurb: 'Just you, looking great', bg: 'bg-volt' },
  { id: 'couple', name: 'Couple', blurb: 'Two people, one frame', bg: 'bg-bubble' },
  { id: 'group', name: 'Group', blurb: 'Friends, family, the whole crew', bg: 'bg-aqua' },
];

export interface SceneMeta { id: SceneId; name: string; emoji: string; bg: string }
export const SCENES: SceneMeta[] = [
  { id: 'campus', name: 'College Campus', emoji: '🎓', bg: 'bg-volt' },
  { id: 'cafe', name: 'Cafe', emoji: '☕', bg: 'bg-sun' },
  { id: 'bedroom', name: 'Bedroom', emoji: '🛏️', bg: 'bg-lilac' },
  { id: 'beach', name: 'Beach', emoji: '🏖️', bg: 'bg-aqua' },
  { id: 'tourist', name: 'Tourist Places', emoji: '🗺️', bg: 'bg-bubble' },
];

export const isMode = (v: unknown): v is Mode => MODES.some((m) => m.id === v);
export const isScene = (v: unknown): v is SceneId => SCENES.some((s) => s.id === v);

// ---------- figure building helpers ----------

const STAND: Figure = {
  nose: [0.5, 0.1],
  lSh: [0.6, 0.22], rSh: [0.4, 0.22],
  lEl: [0.65, 0.38], rEl: [0.35, 0.38],
  lWr: [0.66, 0.52], rWr: [0.34, 0.52],
  lHip: [0.55, 0.52], rHip: [0.45, 0.52],
  lKn: [0.56, 0.73], rKn: [0.44, 0.73],
  lAn: [0.56, 0.95], rAn: [0.44, 0.95],
};

const SIT: Figure = {
  nose: [0.5, 0.16],
  lSh: [0.6, 0.28], rSh: [0.4, 0.28],
  lEl: [0.65, 0.43], rEl: [0.35, 0.43],
  lWr: [0.56, 0.6], rWr: [0.44, 0.6],
  lHip: [0.55, 0.58], rHip: [0.45, 0.58],
  lKn: [0.58, 0.72], rKn: [0.42, 0.72],
  lAn: [0.58, 0.95], rAn: [0.42, 0.95],
};

const mk = (base: Figure, o: Partial<Figure> = {}): Figure => ({ ...base, ...o });

const PAIRS: [JointName, JointName][] = [
  ['lSh', 'rSh'], ['lEl', 'rEl'], ['lWr', 'rWr'], ['lHip', 'rHip'], ['lKn', 'rKn'], ['lAn', 'rAn'],
];

/** Left/right mirror image of a figure. */
const mirror = (f: Figure): Figure => {
  const o: Figure = { ...f };
  o.nose = [1 - f.nose[0], f.nose[1]];
  for (const [l, r] of PAIRS) {
    o[l] = [1 - f[r][0], f[r][1]];
    o[r] = [1 - f[l][0], f[l][1]];
  }
  return o;
};

export const mirrorFigure = mirror;

/** Put a figure into the shared 0..1 box: centre x, size, and floor line. */
const place = (f: Figure, cx: number, scale = 1, bottom = 0.97): Figure => {
  const out = {} as Figure;
  (Object.keys(f) as JointName[]).forEach((k) => {
    const [x, y] = f[k];
    out[k] = [cx + (x - 0.5) * scale, bottom - (0.95 - y) * scale];
  });
  return out;
};

const pair = (a: Figure, b: Figure, sa = 0.92, bottom = 0.97): Figure[] => [
  place(a, 0.38, sa, bottom),
  place(b, 0.62, sa, bottom),
];

const row = (f: Figure, xs: number[], scale: number, bottom = 0.97): Figure[] =>
  xs.map((x) => place(f, x, scale, bottom));

// ---------- reusable body shapes ----------

const LEGS_APART: Partial<Figure> = {
  lKn: [0.6, 0.73], lAn: [0.65, 0.95], rKn: [0.4, 0.73], rAn: [0.35, 0.95],
};
const STRIDE: Partial<Figure> = {
  lKn: [0.6, 0.72], lAn: [0.66, 0.94], rKn: [0.43, 0.73], rAn: [0.4, 0.95],
};

const ARMS_UP = mk(STAND, {
  lEl: [0.7, 0.14], lWr: [0.78, 0.03], rEl: [0.3, 0.14], rWr: [0.22, 0.03], ...LEGS_APART,
});

const SIDE_HUG = mk(STAND, { lEl: [0.68, 0.34], lWr: [0.7, 0.24] });
const HUG_ROW = mk(STAND, { lEl: [0.7, 0.34], lWr: [0.74, 0.25], rEl: [0.3, 0.34], rWr: [0.26, 0.25] });

// ---------- the library ----------

export const POSES: Pose[] = [
  // ===== SOLO =====
  {
    id: 'solo-easy-pocket', title: 'Easy pocket', mode: 'solo',
    scenes: ['campus', 'cafe', 'tourist'],
    steps: ['Stand tall with your weight on one leg', 'Slide one hand into your pocket', 'Let the other arm hang and look just off-camera'],
    tip: 'Soft knees and a small smile beat a stiff pose.',
    figures: [place(mk(STAND, { lEl: [0.63, 0.4], lWr: [0.57, 0.54], rEl: [0.36, 0.38], rWr: [0.35, 0.53], lKn: [0.57, 0.73], rKn: [0.43, 0.72], rAn: [0.4, 0.95] }), 0.5)],
  },
  {
    id: 'solo-hand-on-hip', title: 'Hand on hip', mode: 'solo',
    scenes: ['campus', 'beach', 'tourist'],
    steps: ['Plant your feet a little apart', 'Rest one hand on your hip, elbow out', 'Turn your chin slightly and relax your shoulders'],
    tip: 'The elbow gap makes your waist look defined.',
    figures: [place(mk(STAND, { lEl: [0.72, 0.38], lWr: [0.58, 0.51], ...LEGS_APART, lAn: [0.62, 0.95], rAn: [0.38, 0.95] }), 0.5)],
  },
  {
    id: 'solo-mid-stride', title: 'Mid-stride', mode: 'solo',
    scenes: ['campus', 'beach', 'tourist'],
    steps: ['Take a slow, natural step toward the camera', 'Swing your arms loosely', 'Take the photo as your foot lands'],
    tip: 'Burst-walk a few times; one frame will be perfect.',
    figures: [place(mk(STAND, { ...STRIDE, lEl: [0.68, 0.38], lWr: [0.7, 0.5], rEl: [0.33, 0.38], rWr: [0.31, 0.5] }), 0.5)],
  },
  {
    id: 'solo-backpack-straps', title: 'Backpack straps', mode: 'solo',
    scenes: ['campus'],
    steps: ['Hold both backpack straps near your chest', 'Stand with feet hip-width apart', 'Look toward the building behind you, then back at the camera'],
    tip: 'Great with a library or lecture hall in the background.',
    figures: [place(mk(STAND, { lEl: [0.67, 0.36], lWr: [0.6, 0.3], rEl: [0.33, 0.36], rWr: [0.4, 0.3] }), 0.5)],
  },
  {
    id: 'solo-book-hug', title: 'Book hug', mode: 'solo',
    scenes: ['campus', 'cafe'],
    steps: ['Hold a book or notebook against your chest', 'Cross your forearms over it', 'Tilt your head and smile softly'],
    tip: 'Angle the cover slightly toward the camera.',
    figures: [place(mk(STAND, { lEl: [0.58, 0.4], lWr: [0.45, 0.33], rEl: [0.42, 0.4], rWr: [0.55, 0.33] }), 0.5)],
  },
  {
    id: 'solo-coffee-sip', title: 'Coffee sip', mode: 'solo',
    scenes: ['cafe'],
    steps: ['Hold your cup with both hands near your chin', 'Keep elbows close to your body', 'Look at the camera over the rim'],
    tip: 'Hold it just below your lips so your smile stays visible.',
    figures: [place(mk(STAND, { lEl: [0.62, 0.38], lWr: [0.54, 0.27], rEl: [0.4, 0.4], rWr: [0.49, 0.34] }), 0.5)],
  },
  {
    id: 'solo-chin-rest', title: 'Chin rest', mode: 'solo',
    scenes: ['cafe', 'bedroom'],
    steps: ['Sit and rest one elbow on the table or knee', 'Lightly rest your chin on your hand', 'Lower your gaze, then look up at the lens'],
    tip: 'Do not press into your cheek; keep it light.',
    figures: [place(mk(SIT, { lEl: [0.62, 0.44], lWr: [0.55, 0.21], rEl: [0.36, 0.44], rWr: [0.45, 0.58] }), 0.5)],
  },
  {
    id: 'solo-hair-tuck', title: 'Hair tuck', mode: 'solo',
    scenes: ['cafe', 'bedroom', 'beach'],
    steps: ['Raise one hand to the side of your head', 'Tuck or brush your hair behind your ear', 'Keep the other hand relaxed at your side'],
    tip: 'Move slowly and shoot mid-motion for a candid look.',
    figures: [place(mk(STAND, { lEl: [0.68, 0.2], lWr: [0.58, 0.08], rWr: [0.36, 0.52] }), 0.5)],
  },
  {
    id: 'solo-cozy-sit', title: 'Cozy sit', mode: 'solo',
    scenes: ['bedroom', 'cafe'],
    steps: ['Sit on the edge of the bed or chair', 'Rest your hands loosely in your lap', 'Lean in a little and look toward the light'],
    tip: 'Face a window for soft, flattering light.',
    figures: [place(mk(SIT, { nose: [0.52, 0.16], lWr: [0.53, 0.61], rWr: [0.47, 0.61], lEl: [0.62, 0.44], rEl: [0.38, 0.44], lKn: [0.56, 0.72], rKn: [0.44, 0.72], lAn: [0.57, 0.95], rAn: [0.43, 0.95] }), 0.5)],
  },
  {
    id: 'solo-morning-stretch', title: 'Morning stretch', mode: 'solo',
    scenes: ['bedroom', 'beach'],
    steps: ['Stand or kneel and reach both arms overhead', 'Interlace your fingers or keep palms together', 'Lift your chin and take a deep breath'],
    tip: 'Shoot from slightly below for a taller look.',
    figures: [place(mk(STAND, { lEl: [0.6, 0.1], lWr: [0.54, 0.01], rEl: [0.4, 0.1], rWr: [0.46, 0.01] }), 0.5)],
  },
  {
    id: 'solo-arms-wide', title: 'Embrace the view', mode: 'solo',
    scenes: ['beach', 'tourist'],
    steps: ['Stand with feet shoulder-width apart', 'Open both arms wide to the sides', 'Tilt your face up and let the scene fill the frame'],
    tip: 'Shoot wide and from a bit lower to include the sky.',
    figures: [place(mk(STAND, { lEl: [0.74, 0.23], lWr: [0.9, 0.24], rEl: [0.26, 0.23], rWr: [0.1, 0.24], ...LEGS_APART, lAn: [0.62, 0.95], rAn: [0.38, 0.95] }), 0.5)],
  },
  {
    id: 'solo-jump-for-joy', title: 'Jump for joy', mode: 'solo',
    scenes: ['beach', 'tourist'],
    steps: ['Raise both arms in a big V', 'Bend your knees, then jump', 'Shoot in burst mode right as you leave the ground'],
    tip: 'Try five jumps; the third is usually the best.',
    figures: [place(ARMS_UP, 0.5)],
  },
  {
    id: 'solo-point-out', title: 'Point it out', mode: 'solo',
    scenes: ['tourist'],
    steps: ['Stretch one arm up and out toward the landmark', 'Keep the other arm relaxed', 'Look at what you are pointing to'],
    tip: 'Stand so the landmark is in the direction you point.',
    figures: [place(mk(STAND, { lEl: [0.69, 0.17], lWr: [0.8, 0.07] }), 0.5)],
  },
  {
    id: 'solo-sun-shade', title: 'Sun shade', mode: 'solo',
    scenes: ['beach', 'tourist'],
    steps: ['Raise one hand flat above your eyes', 'Put the other hand on your hip', 'Squint softly toward the horizon'],
    tip: 'Keep your fingers together so the hand shape looks clean.',
    figures: [place(mk(STAND, { rEl: [0.34, 0.17], rWr: [0.45, 0.08], lEl: [0.7, 0.38], lWr: [0.58, 0.51] }), 0.5)],
  },

  // ===== COUPLE =====
  {
    id: 'couple-side-hug', title: 'Side hug', mode: 'couple',
    scenes: ['campus', 'cafe', 'bedroom', 'beach', 'tourist'],
    steps: ['Stand shoulder to shoulder', 'Wrap the inside arm around each other', 'Lean your heads gently together'],
    tip: 'Step in closer than feels natural; cameras flatten distance.',
    figures: [place(SIDE_HUG, 0.4, 0.92), place(mirror(SIDE_HUG), 0.6, 0.92)],
  },
  {
    id: 'couple-hand-in-hand', title: 'Hand in hand walk', mode: 'couple',
    scenes: ['campus', 'beach', 'tourist'],
    steps: ['Hold the inside hands', 'Walk slowly toward the camera', 'Look at each other, then at the lens'],
    tip: 'Let the photographer walk backwards for a candid feel.',
    figures: (() => {
      const a = mk(STAND, { ...STRIDE, lEl: [0.64, 0.4], lWr: [0.63, 0.54] });
      return pair(a, mirror(a));
    })(),
  },
  {
    id: 'couple-cheers', title: 'Cheers', mode: 'couple',
    scenes: ['cafe', 'campus'],
    steps: ['Each hold a cup in your inside hand', 'Raise them until they almost touch', 'Smile at each other mid-toast'],
    tip: 'Keep the cups below your eyes so faces stay clear.',
    figures: (() => {
      const a = mk(STAND, { lEl: [0.66, 0.36], lWr: [0.63, 0.2] });
      return pair(a, mirror(a));
    })(),
  },
  {
    id: 'couple-lean-in', title: 'Lean in', mode: 'couple',
    scenes: ['cafe', 'bedroom'],
    steps: ['Stand close, facing the camera', 'Tilt your heads toward each other until they almost touch', 'Close your eyes or smile for a quiet moment'],
    tip: 'Tilt, do not slouch. Keep your backs straight.',
    figures: (() => {
      const a = mk(STAND, { nose: [0.57, 0.11], lEl: [0.66, 0.4], lWr: [0.6, 0.54] });
      return [place(a, 0.4, 0.92), place(mirror(a), 0.6, 0.92)];
    })(),
  },
  {
    id: 'couple-sit-together', title: 'Sit together', mode: 'couple',
    scenes: ['bedroom', 'cafe'],
    steps: ['Sit side by side, close together', 'Hold the inside hands in your laps', 'Rest your heads lightly together'],
    tip: 'Shoot from slightly above for a soft, intimate angle.',
    figures: (() => {
      const a = mk(SIT, { nose: [0.56, 0.17], lEl: [0.66, 0.44], lWr: [0.63, 0.6] });
      return pair(a, mirror(a));
    })(),
  },
  {
    id: 'couple-hands-up', title: 'Hands up together', mode: 'couple',
    scenes: ['beach', 'tourist'],
    steps: ['Join your inside hands and raise them high', 'Raise your other arms too', 'Cheer or laugh on three'],
    tip: 'Count down together so the joy is real.',
    figures: (() => {
      const a = mk(STAND, { lEl: [0.66, 0.3], lWr: [0.63, 0.06], rEl: [0.3, 0.14], rWr: [0.22, 0.03], ...LEGS_APART });
      return pair(a, mirror(a));
    })(),
  },
  {
    id: 'couple-point-together', title: 'Point together', mode: 'couple',
    scenes: ['tourist', 'beach'],
    steps: ['Stand close, both facing the camera', 'Both point the same way with your outside arm', 'Look where you are pointing'],
    tip: 'Pick one landmark so you both look the same way.',
    figures: (() => {
      const a = mk(STAND, { lEl: [0.69, 0.17], lWr: [0.8, 0.07] });
      return [place(a, 0.36, 0.92), place(a, 0.62, 0.92)];
    })(),
  },

  // ===== GROUP =====
  {
    id: 'group-line-up', title: 'Arms over shoulders', mode: 'group',
    scenes: ['campus', 'cafe', 'bedroom', 'beach', 'tourist'],
    steps: ['Stand in a tight line', 'Put your arms around the people beside you', 'Lean in so every face is visible'],
    tip: 'The photographer should hold the camera at chest height or higher.',
    figures: row(HUG_ROW, [0.2, 0.4, 0.6, 0.8], 0.8),
  },
  {
    id: 'group-v-formation', title: 'V formation', mode: 'group',
    scenes: ['campus', 'beach', 'tourist'],
    steps: ['Tallest person stands in the middle, in front', 'Everyone else steps back in a V shape', 'Hands on hips, confident look'],
    tip: 'Fewer than five people? Just make a smaller V.',
    figures: (() => {
      const h = mk(STAND, { lEl: [0.72, 0.38], lWr: [0.58, 0.51], rEl: [0.28, 0.38], rWr: [0.42, 0.51] });
      return [
        place(h, 0.12, 0.7, 0.86), place(h, 0.88, 0.7, 0.86),
        place(h, 0.3, 0.8, 0.92), place(h, 0.7, 0.8, 0.92),
        place(h, 0.5, 0.88, 0.98),
      ];
    })(),
  },
  {
    id: 'group-jump', title: 'Group jump', mode: 'group',
    scenes: ['campus', 'beach', 'tourist'],
    steps: ['Line up shoulder to shoulder', 'Raise your arms and count to three', 'Jump together while the photographer holds the shutter'],
    tip: 'Use the 3 second timer, then run into place.',
    figures: [
      place(ARMS_UP, 0.2, 0.8, 0.9), place(ARMS_UP, 0.4, 0.8, 0.95),
      place(ARMS_UP, 0.6, 0.8, 0.9), place(ARMS_UP, 0.8, 0.8, 0.95),
    ],
  },
  {
    id: 'group-huddle', title: 'Cozy huddle', mode: 'group',
    scenes: ['bedroom', 'cafe'],
    steps: ['Sit close together on the bed or sofa', 'Put your arms around each other', 'Tilt your heads toward the middle'],
    tip: 'Turn on a warm lamp instead of the overhead light.',
    figures: (() => {
      const base = mk(SIT, { lEl: [0.7, 0.42], lWr: [0.72, 0.34], rEl: [0.3, 0.42], rWr: [0.28, 0.34] });
      return [
        place(mk(base, { nose: [0.56, 0.17] }), 0.3, 0.85),
        place(mk(base, { nose: [0.5, 0.15] }), 0.5, 0.85),
        place(mk(base, { nose: [0.44, 0.17] }), 0.7, 0.85),
      ];
    })(),
  },
  {
    id: 'group-two-rows', title: 'Two rows', mode: 'group',
    scenes: ['campus', 'beach', 'tourist', 'cafe'],
    steps: ['Taller friends stand in the back row', 'Others crouch or sit in front', 'Hands on knees or shoulders, everyone smiling'],
    tip: 'Make sure you can see the lens, and it can see you.',
    figures: (() => {
      const back = mk(STAND, { lEl: [0.7, 0.34], lWr: [0.74, 0.25], rEl: [0.3, 0.34], rWr: [0.26, 0.25] });
      const front = mk(STAND, { lEl: [0.7, 0.42], lWr: [0.64, 0.62], rEl: [0.3, 0.42], rWr: [0.36, 0.62], lKn: [0.62, 0.74], rKn: [0.38, 0.74] });
      return [
        ...row(back, [0.25, 0.5, 0.75], 0.66, 0.78),
        ...row(front, [0.33, 0.67], 0.82, 0.98),
      ];
    })(),
  },
];

// Poses the user created from photos; loaded from IndexedDB by data/custom.ts.
let custom: Pose[] = [];
export const registerCustomPoses = (list: Pose[]) => {
  custom = [...list].sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0));
};
const all = () => [...custom, ...POSES];

export const getPose = (id?: string): Pose | undefined => all().find((p) => p.id === id);
export const getPoses = (mode: Mode, scene?: SceneId): Pose[] =>
  all().filter((p) => p.mode === mode && (!scene || p.scenes.includes(scene)));

export const getAllPoses = (): Pose[] => all();
