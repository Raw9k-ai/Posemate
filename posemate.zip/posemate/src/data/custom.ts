import { useSyncExternalStore } from 'react';
import { registerCustomPoses, type Pose } from './poses';
import { deleteCustomPose, listCustomPoses, saveCustomPose } from '../lib/db';

// Tiny store so screens re-render when the user's own poses change.
let version = 0;
const subs = new Set<() => void>();
const bump = () => {
  version++;
  subs.forEach((f) => f());
};

export function useLibraryVersion(): number {
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => version,
  );
}

export async function refreshCustomPoses(): Promise<void> {
  try {
    const list = await listCustomPoses();
    registerCustomPoses(list.filter((p) => p && Array.isArray(p.figures) && p.figures.length > 0));
  } catch {
    /* storage unavailable (e.g. private browsing): built-in poses still work */
  }
  bump();
}

export async function addCustomPose(p: Pose): Promise<void> {
  await saveCustomPose(p);
  await refreshCustomPoses();
}

export async function removeCustomPose(id: string): Promise<void> {
  await deleteCustomPose(id);
  await refreshCustomPoses();
}
