import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './lib/install'; // starts listening for the install prompt right away
import './index.css';
import { getUi } from './lib/ui';
import { applyTheme } from './ui/theme';

applyTheme(getUi()); // the saved look is on before the first paint, so nothing flashes in the default colors

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

// Offline support. Only in the production build (the dev server would cache stale files).
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`).catch(() => {
      /* unsupported or blocked (for example private mode): the app still works online */
    });
  });
}
