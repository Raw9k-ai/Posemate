// PoseMate service worker (generated into dist/sw.js by scripts/make-sw.mjs).
// Goal: after the first visit the app opens and works with no connection, including the
// pose model. Nothing here sends data anywhere; it only keeps this site's own files.
const CORE_CACHE = 'posemate-core-__CORE_VER__';
const HEAVY_CACHE = 'posemate-heavy-__HEAVY_VER__'; // pose model + WASM: re-downloaded only when they change
const CORE = __CORE__;
const HEAVY = __HEAVY__;

const abs = (p) => new URL(p, self.registration.scope).href;

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      // The app itself must cache completely, or this version does not install.
      await (await caches.open(CORE_CACHE)).addAll(CORE.map(abs));
      // The big files are best effort: if one fails it is cached the first time it is used.
      const heavy = await caches.open(HEAVY_CACHE);
      await Promise.allSettled(
        HEAVY.map(async (p) => {
          const url = abs(p);
          if (await heavy.match(url)) return;
          const res = await fetch(url);
          if (res.ok) await heavy.put(url, res);
        }),
      );
    })(),
  );
  // No skipWaiting: a new version waits until every open tab is closed, so an open page never
  // loses the hashed files it was built with.
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keep = new Set([CORE_CACHE, HEAVY_CACHE]);
      for (const name of await caches.keys()) {
        if (name.startsWith('posemate-') && !keep.has(name)) await caches.delete(name);
      }
      await self.clients.claim();
    })(),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET' && req.method !== 'HEAD') return;
  if (new URL(req.url).origin !== self.location.origin) return;
  if (req.headers.has('range')) return; // let the network answer partial requests
  event.respondWith(req.mode === 'navigate' ? openPage(req) : fromCacheFirst(req));
});

// Pages: try the network briefly so updates show up, fall back to the saved copy when offline.
async function openPage(req) {
  try {
    const timeout = new Promise((_, reject) => setTimeout(reject, 4000));
    return await Promise.race([fetch(req), timeout]);
  } catch {
    return (await caches.match(abs('index.html'))) || (await caches.match(abs('./'))) || Response.error();
  }
}

// Everything else (scripts, styles, icons, model, WASM): saved copy first, then the network.
// ignoreMethod lets the model check (a HEAD request in src/lib/pose.ts) be answered offline too.
async function fromCacheFirst(req) {
  const hit = await caches.match(req, { ignoreMethod: true });
  if (hit) return hit;
  const res = await fetch(req);
  if (req.method === 'GET' && res.ok && res.status === 200) {
    const cache = await caches.open(CORE_CACHE);
    cache.put(req, res.clone());
  }
  return res;
}
