// Copies the MediaPipe WASM runtime out of node_modules and downloads the
// pose model, so the deployed site serves everything from its own origin.
// Result: no third-party requests when a visitor uses the app.
//
// Runs on `npm install` and before `npm run build`. Safe to re-run.
import { cpSync, existsSync, mkdirSync, writeFileSync, statSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const wasmSrc = resolve(root, 'node_modules/@mediapipe/tasks-vision/wasm');
const wasmDest = resolve(root, 'public/mediapipe/wasm');
const modelDest = resolve(root, 'public/models/pose_landmarker_lite.task');
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task';

// 1) WASM runtime
if (existsSync(wasmSrc)) {
  mkdirSync(wasmDest, { recursive: true });
  cpSync(wasmSrc, wasmDest, { recursive: true });
  console.log('[posemate] MediaPipe WASM copied to public/mediapipe/wasm');
} else {
  console.warn('[posemate] @mediapipe/tasks-vision not installed yet; skipping WASM copy.');
}

// 2) Model file (about 6 MB, downloaded once)
if (existsSync(modelDest) && statSync(modelDest).size > 1_000_000) {
  console.log('[posemate] Pose model already present.');
} else {
  try {
    mkdirSync(dirname(modelDest), { recursive: true });
    const res = await fetch(MODEL_URL);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    writeFileSync(modelDest, Buffer.from(await res.arrayBuffer()));
    console.log('[posemate] Pose model downloaded to public/models/');
  } catch (err) {
    console.warn(
      '[posemate] Could not download the pose model (' + err.message + ').\n' +
        '           The app still runs, but skeleton detection will be unavailable.\n' +
        '           Download it manually from:\n           ' + MODEL_URL + '\n' +
        '           and save it as public/models/pose_landmarker_lite.task'
    );
  }
}
