/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: 'rgb(var(--c-ink) / <alpha-value>)',
        paper: 'rgb(var(--c-paper) / <alpha-value>)',
        volt: 'rgb(var(--c-volt) / <alpha-value>)',
        cobalt: 'rgb(var(--c-cobalt) / <alpha-value>)',
        bubble: 'rgb(var(--c-bubble) / <alpha-value>)',
        aqua: 'rgb(var(--c-aqua) / <alpha-value>)',
        lilac: 'rgb(var(--c-lilac) / <alpha-value>)',
        sun: 'rgb(var(--c-sun) / <alpha-value>)',
        mist: 'rgb(var(--c-mist) / <alpha-value>)',
        mint: 'rgb(var(--c-mint) / <alpha-value>)',
        coral: 'rgb(var(--c-coral) / <alpha-value>)',
      },
      fontFamily: {
        sans: ['var(--ui-font)'],
      },
    },
  },
  plugins: [],
};
