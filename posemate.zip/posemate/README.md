# PoseMate

A free, mobile-first photo pose coach. Pick Solo, Couple or Group, choose a place, follow a reference pose with a live camera guide, and capture. Body detection runs on the phone with MediaPipe. There is no backend, login, database, analytics or upload.

**React + Vite + TypeScript, Tailwind CSS, `@mediapipe/tasks-vision`.** No router, state, UI or icon libraries.

## Status

> This code was written without being able to install packages or run a browser, so it has **not been compiled or tested yet**. Run the steps below and test on a real Android phone before publishing. Treat anything under "Needs device testing" as unverified.

### Completed (implemented in code)

| Feature | Notes |
| --- | --- |
| Home with Solo / Couple / Group | `src/screens/Home.tsx` |
| Scenes: College Campus, Cafe, Bedroom, Beach, Tourist Places | 5 scenes per mode |
| 26 pose cards with illustrations and 3-step instructions | 14 solo, 7 couple, 5 group. Illustrations are filled body silhouettes generated from the same joint data as the live guide |
| Hash routing (Android back button works, no server rewrites) | `src/lib/route.ts` |
| Camera opens and asks permission only on the camera screen | `src/screens/Camera.tsx` |
| Front / rear switching, self-timer (3s, 10s), flash feedback | |
| Capture, preview, retake, save locally (IndexedDB), download, share, delete | Gallery at `#/gallery` |
| Highest practical resolution | Requests 4:3 at up to 4032×3024; uses `ImageCapture.takePhoto` for full-sensor stills where supported, otherwise the video frame. Real size is shown in the preview |
| Original photo kept separate from the overlay | Photo blob is never modified. Landmarks and pose id are stored as metadata; the overlay is a separate canvas you can toggle |
| Real MediaPipe Pose Landmarker | `src/lib/pose.ts`, GPU with CPU fallback, loaded on demand |
| Live skeleton from detected landmarks | Drawn from actual `PoseLandmarker` output, up to 5 people |
| Reference pose guide on the camera | Body-shaped outline with a soft tint (`src/lib/silhouette.ts`), toggleable. The live skeleton stays as lines so you can tell detected landmarks from the guide |
| Ghost figure | A translucent filled copy of the pose to line yourself up with. Tap "Ghost" on the camera to cycle Off / Light / Medium / Strong. In couple and group poses each person's ghost has its own tint. Works for built-in and custom poses (`GHOST_COLORS` in `src/lib/draw.ts`) |
| Photo ghost (opt-in) | When creating a pose you can switch on "Photo ghost". The person is cut out of the photo with the cleaned body mask (`src/lib/cutout.ts`) and saved as a small WebP (max 512px) with the pose, on this device only. On the camera it replaces the white shape ghost with a faded copy of the real photo, drawn mirrored if you flipped the pose; a "Ghost style: Photo / Shape" button switches between them, and the Ghost strength button still applies. Off by default. Deleting the pose deletes the cut-out |
| Make a pose from a photo (`#/create`) | Pick a photo; MediaPipe finds the joints and a body mask on-device, the mask is traced into a smoothed outline (`src/lib/outline.ts`), and the pose is saved on the device (IndexedDB). Handles 1 to 5 people (solo / couple / group), left/right flip, name, places, steps. The reference photo itself is never uploaded, and is not stored unless you turn on the optional photo ghost (see below). Custom poses appear in the pose lists and camera picker with a "Yours" badge and can be deleted |
| Layered guide from a photo | (1) Mask cleanup: blur, threshold, then morphological opening removes stray hair, flyaway fabric and spikes (`src/lib/outline.ts`). (2) Part-segmentation contours (`src/lib/parts.ts`): every pixel of the person mask is assigned to the nearest body part (head, torso, upper/lower arms, thighs/shins, with hands and feet) measured against the detected skeleton, and the lines are the boundaries between parts, so hands on hip and folded arms stay visible without doubling the outline. Skeleton-guided, not a trained part-segmentation network, so accuracy follows the joint detection. Off / Simple (6 regions) / Detailed (10 limb parts) / Hands & feet (14 parts) in the creator. (3) The detected skeleton is drawn over the silhouette as semi-transparent neon lines. A "Guide details" toggle on the camera hides (2) and (3). All in plain TypeScript (`src/lib/vision.ts`), no OpenCV, no extra download |
| Match score (solo poses) | Real calculation: limb directions compared with the reference |
| Error messages | Camera permission, no camera, camera busy, insecure context, missing model, unsupported browser, storage blocked |

### Needs device testing

- Full-resolution capture on your phone (some browsers reject `takePhoto` at max size; the code then falls back to the video frame).
- Overlay alignment in the preview. It is only shown when the photo has the same aspect ratio as the live view.
- Detection speed on low-end Android phones (the lite model is used and frames are downscaled to 480px).
- Front-camera photos are saved **un-mirrored** (as other people would see you). The live view is mirrored.

### Placeholders / not built

- The body outline is a generic mannequin shape built from the joints, not a real person's contour. Real traced outlines would need the pose-from-photo creator (not built).
- Match score is skipped for couple and group poses (it would need person-to-figure assignment).
- No installable PWA or offline mode (no service worker or icons yet).
- No "export with overlay baked in" (by design the original is kept clean).
- No joint-by-joint pose editor and no landscape-specific layout.

## Run it

Requires Node 18+.

```bash
npm install        # also copies the MediaPipe WASM and downloads the ~6 MB pose model into public/
npm run dev
```

If the download fails (offline install), save the model yourself as `public/models/pose_landmarker_lite.task`:
https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task
then run `npm run setup:assets`.

### Testing on a phone

Browsers only allow the camera on **HTTPS or localhost**, so `http://192.168.x.x:5173` will not work. Options:

1. USB debugging: on the phone enable Developer options → USB debugging, open `chrome://inspect/#devices` on your computer, add port forwarding `5173 → localhost:5173`, then open `http://localhost:5173` on the phone.
2. Deploy to any HTTPS host (below) and open that URL.

## Build and publish

```bash
npm run build      # type-checks, then writes the static site to dist/
npm run preview    # serve dist/ locally
```

`dist/` is plain static files with relative paths and hash routing, so it works at a domain root or in a sub-folder with no rewrite rules.

- **Netlify / Cloudflare Pages / Vercel:** connect the repo; build command `npm run build`, output directory `dist`. Or drag `dist/` onto Netlify Drop.
- **GitHub Pages:** push `dist/` to a `gh-pages` branch (or use a Pages workflow that runs `npm ci && npm run build`).
- **Any static host:** upload the contents of `dist/`. Make sure `.wasm` is served as `application/wasm` (all major hosts do this).

If you build in CI, the build needs internet access once to download the model. Alternatively commit `public/models/pose_landmarker_lite.task` and remove it from `.gitignore`.

## Privacy

> **Photo ghost is the one exception to "nothing but outlines is stored".** It is off by default. If you turn it on for a pose, a small cut-out image of each person in that photo is saved in this browser's storage (IndexedDB) next to the pose. It is never uploaded. Only use photos of yourself or people who agree, and delete the pose to remove the cut-out.

- Camera frames and photos are never uploaded. Detection runs in your browser using a WASM runtime and model served from your own site.
- The camera is requested only when the camera screen opens.
- Saved photos live in the browser's IndexedDB on that device. Clearing site data deletes them.
- No analytics, cookies, accounts or third-party requests at runtime.
- Optional hardening: add a Content-Security-Policy that restricts `connect-src` to `'self'`. Test it on a device first, because MediaPipe needs `'wasm-unsafe-eval'` in `script-src`.

## Project layout

```
src/
  data/poses.ts          pose library (joints, steps, scenes)
  lib/camera.ts          getUserMedia, errors, best-resolution capture
  lib/pose.ts            MediaPipe loader and detector
  lib/draw.ts            overlay drawing (guide + skeleton)
  lib/match.ts           pose match score
  lib/db.ts, files.ts    local storage, download, share
  screens/               Home, Scenes, Poses, Camera, Gallery
  components/            PoseArt, Preview, PhotoWithOverlay, Header, Icon
scripts/setup-assets.mjs copies WASM + downloads model to public/
```

## Adding poses

Add an entry to `POSES` in `src/data/poses.ts`. Start from `STAND` or `SIT`, override joints with `mk(...)`, and place figures with `place(...)`. Coordinates are in a 0..1 square as seen by the camera, so the person's left side is on the image right.

## Design notes

- **One idea:** *frame yourself.* Viewfinder corner marks (`src/components/Corners.tsx`) frame every pose illustration, the same way the camera frames you. The pose figure is the one bold element; everything else is flat colour and plain type.
- **Colour means something:** Solo is yellow-green, Couple is pink, Group is aqua; each place keeps its own colour. Cobalt is used only for the main action on a screen ("Try this pose"). No shadows.
- **Type:** system font (Roboto on Android), heavy weight for display, sentence case, no all-caps labels.
- **Navigation:** a thumb-reach bottom bar (Home, Camera, Make a pose, My photos) on every screen except the camera.
- **Camera:** four top controls (back, title, timer, guide settings). Ghost strength, ghost style, body-part lines and the live skeleton live in one "Guide settings" panel.
- **Pose art:** silhouettes with light limb lines so arms stay readable over the torso, and a white outline around each person in couple and group poses.
- **Shared controls:** `src/components/Controls.tsx` (switch, segmented control, row).
- **Not yet checked on a device:** the layout was written without a browser; only the pose illustrations were rendered and reviewed.
