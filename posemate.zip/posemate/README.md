# PoseMate

A free, mobile-first photo pose coach. Pick Solo, Couple or Group, choose a place, follow a reference pose with a live camera guide, and capture. Body detection runs on the phone with MediaPipe. There is no backend, login, database, analytics or upload.

**React + Vite + TypeScript, Tailwind CSS, `@mediapipe/tasks-vision`.** No router, state, UI or icon libraries.

## Status

> This code was written without being able to install packages or run a browser, so it has **not been compiled or tested yet**. Run the steps below and test on a real Android phone before publishing. Treat anything under "Needs device testing" as unverified.

### Completed (implemented in code)

| Feature | Notes |
| --- | --- |
| Home with Solo / Couple / Group | `src/screens/Home.tsx` |
| Scenes: College Campus, Cafe, Street, Stairs and steps, Bedroom, Beach, Tourist Places, Formal and events | 8 scenes per mode. Each pose lists the scenes it suits (`scenes` in `src/data/poses.ts`) |
| Solo / Couple / Group switch on the pose list | Changes who is in the photo without leaving the place (`#/poses/<mode>/<scene>`, using replace so Back still returns to the places list) |
| Mood filters on the pose list and in the camera's pose picker | Chips: All, Confident, Playful, Cozy, Elegant, Candid (only moods that list has), plus Yours for poses made from photos. Moods are tagged per built-in pose (`moods`) |
| 40 pose cards with illustrations and 3-step instructions | 19 solo, 12 couple, 9 group; every mode and place has at least 3. Illustrations are filled body silhouettes generated from the same joint data as the live guide |
| Hash routing (Android back button works, no server rewrites) | `src/lib/route.ts` |
| Camera opens and asks permission only on the camera screen | `src/screens/Camera.tsx` |
| Front / rear switching, self-timer (3s, 5s, 10s), flash feedback | Timer ticks and a shutter click are generated in the browser (`src/lib/device.ts`); Sounds can be switched off in Guide settings |
| Capture, preview, retake, save locally (IndexedDB), download, share, delete | Gallery at `#/gallery` |
| Highest practical resolution | Requests 4:3 at up to 4032×3024; uses `ImageCapture.takePhoto` for full-sensor stills where supported, otherwise the video frame. Real size is shown in the preview |
| Original photo kept separate from the overlay | Photo blob is never modified. Landmarks and pose id are stored as metadata; the overlay is a separate canvas you can toggle |
| Real MediaPipe Pose Landmarker | `src/lib/pose.ts`, GPU with CPU fallback, loaded on demand |
| Live skeleton from detected landmarks | Drawn from actual `PoseLandmarker` output, up to 5 people |
| Reference pose guide on the camera | Body-shaped outline with a soft tint (`src/lib/silhouette.ts`), toggleable. The live skeleton stays as lines so you can tell detected landmarks from the guide |
| Ghost figure | A translucent filled copy of the pose to line yourself up with. Tap "Ghost" on the camera to cycle Off / Light / Medium / Strong. In couple and group poses each person's ghost has its own tint. Works for built-in and custom poses (`GHOST_COLORS` in `src/lib/draw.ts`) |
| Photo ghost (opt-in) | When creating a pose you can switch on "Photo ghost". The person is cut out of the photo with the cleaned body mask (`src/lib/cutout.ts`) and saved as a small WebP (max 512px) with the pose, on this device only. On the camera it replaces the white shape ghost with a faded copy of the real photo, drawn mirrored if you flipped the pose; a "Ghost style: Photo / Shape" button switches between them, and the Ghost strength button still applies. Off by default. Deleting the pose deletes the cut-out |
| Make a pose from a photo (`#/create`) | Pick a photo; MediaPipe finds the joints and a body mask on-device, the mask is traced into a smoothed outline (`src/lib/outline.ts`), and the pose is saved on the device (IndexedDB). Handles 1 to 5 people (solo / couple / group), left/right flip, name, places, steps. The reference photo itself is never uploaded, and is not stored unless you turn on the optional photo ghost (see below). Custom poses appear in the pose lists and camera picker with a "Yours" badge and can be deleted |
| Layered guide from a photo | (1) Mask cleanup: blur, threshold, then morphological opening removes stray hair, flyaway fabric and spikes (`src/lib/outline.ts`). (2) Part-segmentation contours (`src/lib/parts.ts`): every pixel of the person mask is assigned to the nearest body part (head, torso, upper/lower arms, thighs/shins, with hands and feet) measured against the detected skeleton, and the lines are the boundaries between parts, so hands on hip and folded arms stay visible without doubling the outline. Skeleton-guided, not a trained part-segmentation network, so accuracy follows the joint detection. Off / Simple (6 regions) / Detailed (10 limb parts) / Hands & feet (14 parts) in the creator. (3) The detected skeleton is drawn over the silhouette as semi-transparent neon lines. A "Guide details" toggle on the camera hides (2) and (3). All in plain TypeScript (`src/lib/vision.ts`), no OpenCV, no extra download |
| Match score (solo poses) | Real calculation: limb directions compared with the reference |
| Favorites | Heart on every pose card, in the camera's pose picker and in the steps panel. Home has a Favorites button (`#/favorites`); the picker has a Favorites filter. Saved in this browser's localStorage (`src/lib/prefs.ts`) |
| Steadier skeleton | One Euro filter on every joint (`src/lib/smooth.ts`): less jitter when you stand still, little lag when you move. Each person keeps their own filter if the model reorders people. Applied to the live skeleton, the match score and the landmarks saved with a photo |
| Auto-snap (solo poses) | Off by default; switch on in Guide settings. When the match score reaches 80% and stays above 65% for 1.5 s, a rising chime plays and the photo is taken. It ignores the self-timer. After a snap you must move out of the pose before it can fire again. Thresholds are constants at the top of `Camera.tsx`, untuned |
| Keep screen on | Screen Wake Lock while the camera is open (setting in Guide settings, on by default). Not supported by every browser; where it is not, the screen follows the phone's normal timeout |
| Installable app (PWA) | `public/manifest.webmanifest` + icons from the PoseMate logo (`public/icons/`: 192, 512, maskable 512, Apple touch, favicon). Home shows an "Install PoseMate" button when the browser allows it (`src/lib/install.ts`); the browser menu's Install / Add to Home screen also works |
| Works offline after the first visit | `scripts/make-sw.mjs` runs after `vite build` and writes `dist/sw.js` from `scripts/sw-template.js`. It caches the app files plus the Lite pose model and MediaPipe WASM (about 20 MB, kept in a separate cache that is only re-downloaded when those files change). The Full and Heavy models are not downloaded on install; each is saved the first time it is chosen. Pages try the network for 4 s, then fall back to the saved copy. A new version waits until all PoseMate tabs are closed before taking over. Only registered in the production build |
| Adaptive frame rate | `src/lib/perf.ts`. Body tracking runs up to 20 times a second. If detection plus drawing takes more than 75% of the time between frames for 10 frames in a row, it steps down 20, 15, 10, 6 per second; it steps back up after 4 s with plenty of room (changes at least 3 s apart). This is also how it copes with a hot phone that has slowed itself down: the web cannot read the phone's temperature, so it reacts to the slowdown. With nobody in the frame for 3 s it only checks 6 times a second. The camera screen shows the measured rate, and "Slowed down to keep up" when it has eased off |
| Accuracy (Lite / Full / Heavy) | Guide settings. Picks the MediaPipe pose model: Lite (about 6 MB, fastest, default), Full (about 9 MB), Heavy (about 30 MB, most accurate, best on a fast phone). All three are downloaded at build time into `public/models/` (`POSEMATE_MODELS=lite npm run build` keeps a slimmer build). Only Lite is saved on install; Full and Heavy are saved by the service worker the first time they are chosen (separate `posemate-models-*` cache), so a visitor who never changes the setting never downloads them. While a new model loads the old one keeps tracking. If the chosen model cannot be loaded (not in the build, or offline before it was ever saved) the app uses Lite and says why. Battery saver always uses Lite. Also used when making a pose from a photo. Heavy models are freed when you leave the camera. Sizes are approximate |
| Level line | Guide settings, on by default. A horizon line across the camera view that stays on the real horizon while the phone tilts, with fixed ticks for the phone's own horizontal; both turn green within 1 degree. Shows only within 35 degrees of level and never for a flat phone. A small note appears when the camera points more than 5 degrees up or down. Works in portrait and landscape. Maths in `src/lib/tilt.ts`: tilt is computed from the direction of gravity, because with a phone held upright the browser's gamma angle is not the left-right roll. Needs the browser to share motion sensors (Chrome and Brave: Site settings, Motion sensors); if no readings arrive the setting says so |
| Before / after slider | "Compare" button on the photo preview and in My photos for photos taken with a pose. Reference pose on the left (on the place's colour), your photo on the right, drag the line (or use arrow keys, Home, End). The reference is scaled and shifted onto the person when they were found at capture, so the wipe compares poses, not positions; a match percentage shows for solo poses. If the pose has a photo ghost, that is shown instead of the shape. The photo is never changed |
| Candid burst | "Burst" pill on the camera view (also in Guide settings), off by default. A shutter press (or timer, or auto-snap) takes 6 frames about 0.2 s apart from the live video, then "Pick your best shot" shows them in a strip with a "Best" mark. Best = sharpest frame (Laplacian variance of a small copy), the usual number of people in view, and for solo poses the match score; you choose, and the chosen frame goes to the normal preview. Frames are live-view resolution, not full sensor. Frames are held in memory only until you choose. Logic in `src/lib/burst.ts` |
| Lighting readout (testing) | Guide settings, off by default. Shows the measured light numbers on the camera (frame brightness, person brightness, brightness behind, what the check says and what is shown), with buttons "Tip wrong", "Missed it", "Copy log" and "Clear". The last 240 readings (about 2 minutes) are kept in memory only and copy as CSV with the current thresholds on the first line, to paste into a chat for tuning. `LightLog` in `src/lib/light.ts`, panel in `src/camera/LightDebugPanel.tsx` |
| Performance (light mode) | Guide settings, Auto / Light / Full. Auto turns light mode on for phones that report 4 or fewer CPU cores or 2 GB of memory or less (`isLowEndDevice` in `src/lib/perf.ts`). Light mode: detection never above 15 per second (the automatic slowing down still applies on top), the model reads a 320 px copy instead of 480, burst takes 4 frames scaled to at most 1280 px, and the style sheet drops blur and entrance animations (`<html data-perf="light">`, set in `src/lib/useLightMode.ts`). Full removes these limits. Thresholds are guesses to tune on an old phone |
| Pick up where you left off | Home shows the last 6 poses opened on the camera (saved in this browser's localStorage), tap to open the camera with that pose |
| Remembered camera options | Ghost strength, live skeleton, body-part lines and self-timer are kept between visits (the pose guide on/off is not) |
| Small buzz | A 25 ms vibration with the shutter, under the Sounds switch (Android Chrome only; iPhones ignore it) |
| Tidier camera view | Match score (now with a thin progress bar), Hold it, Auto-snap on and the solo-poses note share one stack at the top left, so they no longer overlap; the stack moves down when an error notice shows |
| Guide fits you | Camera pill "Fit to me" (also in Guide settings). The guide scales and moves onto your detected body (full-body fit when head and a foot show, otherwise torso fit; `computeFit` in `src/lib/fit.ts`), eased so it glides, and held for 0.8 s if you step out. Off by default. The match score never depended on position, so it is unchanged |
| Move and resize the guide | One finger drags the guide, two fingers pinch it (scale 0.4 to 2.5). Works with Fit to me (your move is added on top). "Reset guide" pill appears when moved; a new pose resets it. Switch off in Guide settings ("Move guide with fingers"). `src/camera/useGuideGestures.ts`, maths in `src/lib/guideAdjust.ts`; front-camera mirroring handled |
| Customize (`#/customize`) | Home button "Customize look" and a link at the bottom of Guide settings. Colors: 5 presets and all 11 theme colors, with a warning when text and background are too close. Font: 7 built-in stacks (what shows depends on the phone) or your own .ttf/.otf/.woff file up to 2 MB, kept on this phone. Text size 85 to 140 percent, corner style Round / Soft / Square. Icons: every icon, including the camera screen buttons and the shutter, can be replaced by a picture or an emoji. "Your changes" lists everything renamed, recolored or hidden, each with Undo / Show again. Save my look to a file, load it back, reset everything. Settings in localStorage (`posemate-ui`), pictures shrunk to small data URLs; nothing uploaded. `src/lib/ui.ts`, `src/screens/Customize.tsx` |
| Tap anything to change it | Customize > "Start editing the screen". A bar at the top has Done and a Go-to menu to move between screens (taps do not trigger the app while editing). Tap any text, button or heading: rename it (all places with the same wording), set background and text color, add a picture, hide it, or swap its icon. Edits are applied to the page after React draws it by `src/ui/engine.ts` (no observer runs while nothing is changed). Elements are found by `data-ui` name, `aria-label` or text, so a label that changes (for example "Burst on" / "Burst off") is two separate items. Customize buttons cannot be hidden (`data-no-hide`), and Customize is also reachable at `#/customize` |
| Battery saver | Guide settings: Off / Auto / On (default Auto). On: tracking at most 10 per second and a smaller frame copy for the model (320 px instead of 480). Auto switches it on at 20% battery or less when unplugged, using the Battery Status API; browsers that do not share battery level keep Auto off. A web page cannot see Android's own Battery Saver switch or control screen brightness |
| Privacy and data (`#/privacy`) | Linked from Home. Shows what is stored on the device (photo count, poses made from photos and how many have a photo ghost, favorites) with a delete button for each, \"Reset favorites and settings\", and \"Delete everything\". Each asks for confirmation. The offline app copy and pose model are not personal data and are left alone; the screen says how to remove them in browser settings |
| Lighting tips | `src/lib/light.ts`. Twice a second the camera measures a 64 x 36 copy of the frame and shows a tip at the top right when the scene is too dark, too bright, or the person is lit from behind. When a person is in view it judges the person (head, shoulders, hips), not the whole frame, so a dim room around a well lit person, or a bright window behind one, does not trigger a tip unless the person is much darker than the background (backlit). A problem must last 1.5 s to show and be gone 1.5 s to hide; tapping the tip hides it until the problem goes away or changes. Switch in Guide settings (on by default). Brightness is measured after the phone's own auto-exposure |
| Pose tips on the camera | `matchHint` in `src/lib/match.ts`. For solo poses with the match under 85%, a pill near the bottom of the view names the limb furthest from the reference, for example \"Lift your left arm\", \"Lower your right forearm\", \"Move your left arm out\". Left and right are the person's own. The upper arm or thigh is mentioned before the forearm or lower leg. Only when a limb is at least 35 degrees off. A tip stays 1.2 s before it can change. Switch in Guide settings (on by default) |
| Error messages | Camera permission, no camera, camera busy, insecure context, missing model, unsupported browser, storage blocked |

### Needs device testing

- Full-resolution capture on your phone (some browsers reject `takePhoto` at max size; the code then falls back to the video frame).
- Overlay alignment in the preview. It is only shown when the photo has the same aspect ratio as the live view.
- Detection speed on low-end Android phones (the lite model is used and frames are downscaled to 480px).
- Privacy and data: save a photo and make a pose, then delete each kind and check My photos, the pose lists and Favorites update; try Delete everything and reopen the app.
- Pose tips: pick a solo pose such as Arms wide and check the pill names the right limb and side (left means your own left), does not flicker, and goes away when you match.
- Lighting tips: try a dark room, a bright window behind you, and direct sun on your face; check the tips are right, not nagging, and that tapping hides one. Tune the numbers at the top of `light.ts`.
- Adaptive frame rate and battery saver: watch the "fps" figure at the bottom right of the camera on a slow phone and after a few minutes of use; check Auto with the phone under 20% unplugged; check the model still tracks well in saver mode (320 px).
- Accuracy: pick Full, then Heavy, on the phone. Check the chip says "Loading Full model…", tracking carries on meanwhile, the fps readout, and that airplane mode falls back to Lite for a model that was never saved but keeps working for one that was. Compare joint steadiness and fps against Lite.
- Level line: hold the phone upright and tilt it both ways, then try landscape and the front camera; check green means level against a table edge or door frame. If nothing appears, check Motion sensors in the browser's site settings.
- Before / after slider: take a solo pose photo, tap Compare, drag; check the reference lines up with you and the match percentage looks sensible.
- Candid burst: switch Burst on, shoot while moving or laughing; check all 6 frames look right, "Best" is a sensible pick, the chosen frame opens in Preview and saves, and the Compare slider lines up.
- Lighting readout: switch it on, test a dark room, a bright window behind you, strong sun, and a normal room; for each, tap "Tip wrong" or "Missed it" when the tip is wrong, then "Copy log" and send it.
- Light mode: on an older phone (or set Performance to Light on a new one) compare the fps readout and heat against Full; check the camera still looks fine without blur, burst shows 4 frames, and Home has no entrance animation. If Auto picked wrongly for your phone, tell me its model, cores and RAM.
- Guide: with a solo pose, drag it with one finger and pinch with two (also on the front camera, where left/right are mirrored); check Reset guide brings it back; switch on Fit to me, step closer and further, and check the guide follows without jitter and the match score is unchanged.
- Customize: change a preset and a single color, a font (and a font file), text size and corners; check the camera and Home still look right. Rename a button, give one a picture, hide one and bring it back from Your changes. Replace the camera and shutter icons. Save the look to a file, reset, load it again. Restart the app and check everything stayed.
- Remembered options: change ghost strength and timer, close and reopen the camera, check they stayed. Open a few poses and check Home lists them.
- After the Camera.tsx split: do a full pass (camera opens, switch front/rear, pose picker, guide settings, Accuracy switch, level line, auto-snap, timer, burst, Preview). Nothing should behave differently; the pose picker now starts on the current pose's mode each time it opens and forgets its Favorites/mood filter when closed.
- PWA: install on Chrome and Brave, then switch on airplane mode and open the app, open the camera, and take a pose photo. The first visit must be online and the page must be open for a moment so the model finishes caching.
- Auto-snap: whether 80% / 65% / 1.5 s feels right, and whether the smoothed skeleton feels steady without lagging.
- Wake lock and sounds on your phone and browsers (Chrome, Brave).
- Front-camera photos are saved **un-mirrored** (as other people would see you). The live view is mirrored.

### Placeholders / not built

- The body outline is a generic mannequin shape built from the joints, not a real person's contour. Real traced outlines would need the pose-from-photo creator (not built).
- Match score is skipped for couple and group poses (it would need person-to-figure assignment).
- No installable PWA or offline mode (no service worker or icons yet).
- No "export with overlay baked in" (by design the original is kept clean).
- No joint-by-joint pose editor and no landscape-specific layout.

## Run it

Requires Node 18+.

```bash
npm install        # also copies the MediaPipe WASM and downloads the pose models (Lite ~6 MB, Full ~9 MB, Heavy ~30 MB) into public/
npm run dev
```

If the download fails (offline install), save the model yourself as `public/models/pose_landmarker_lite.task` (and `_full.task` / `_heavy.task` for the other accuracy levels, same URL pattern):
https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task
then run `npm run setup:assets`.

### Testing on a phone

Browsers only allow the camera on **HTTPS or localhost**, so `http://192.168.x.x:5173` will not work. Options:

1. USB debugging: on the phone enable Developer options → USB debugging, open `chrome://inspect/#devices` on your computer, add port forwarding `5173 → localhost:5173`, then open `http://localhost:5173` on the phone.
2. Deploy to any HTTPS host (below) and open that URL.

## Build and publish

```bash
npm run build      # type-checks, then writes the static site to dist/
npm run preview    # serve dist/ locally
```

`dist/` is plain static files with relative paths and hash routing, so it works at a domain root or in a sub-folder with no rewrite rules.

- **Netlify / Cloudflare Pages / Vercel:** connect the repo; build command `npm run build`, output directory `dist`. Or drag `dist/` onto Netlify Drop.
- **GitHub Pages:** push `dist/` to a `gh-pages` branch (or use a Pages workflow that runs `npm ci && npm run build`).
- **Any static host:** upload the contents of `dist/`. Make sure `.wasm` is served as `application/wasm` (all major hosts do this).

If you build in CI, the build needs internet access once to download the model. Alternatively commit `public/models/pose_landmarker_lite.task` and remove it from `.gitignore`.

## Privacy

> **Photo ghost is the one exception to "nothing but outlines is stored".** It is off by default. If you turn it on for a pose, a small cut-out image of each person in that photo is saved in this browser's storage (IndexedDB) next to the pose. It is never uploaded. Only use photos of yourself or people who agree, and delete the pose to remove the cut-out.

- Camera frames and photos are never uploaded. Detection runs in your browser using a WASM runtime and model served from your own site.
- The camera is requested only when the camera screen opens.
- Saved photos live in the browser's IndexedDB on that device. Clearing site data deletes them.
- No analytics, cookies, accounts or third-party requests at runtime.
- Optional hardening: add a Content-Security-Policy that restricts `connect-src` to `'self'`. Test it on a device first, because MediaPipe needs `'wasm-unsafe-eval'` in `script-src`.

## Project layout

```
src/
  data/poses.ts          pose library (joints, steps, scenes)
  lib/camera.ts          getUserMedia, errors, best-resolution capture
  lib/pose.ts            MediaPipe loader and detector
  lib/draw.ts            overlay drawing (guide + skeleton)
  lib/match.ts           pose match score
  lib/db.ts, files.ts    local storage, download, share
  lib/smooth.ts         One Euro smoothing of detected joints
  lib/install.ts         install button support
  lib/light.ts           lighting check (dark / too bright / backlit)
  lib/perf.ts            adaptive frame rate and battery saver limits
  lib/prefs.ts           favorites and camera settings (localStorage)
  lib/device.ts          sounds and screen wake lock
  screens/               Home, Scenes, Poses, Favorites, Privacy, Camera, Gallery
  components/            PoseArt, PoseCard, HeartButton, Preview, PhotoWithOverlay, Header, Icon
scripts/setup-assets.mjs copies WASM + downloads model to public/
scripts/make-sw.mjs      writes dist/sw.js after the build (offline support)
```

## Adding poses

Add an entry to `POSES` in `src/data/poses.ts`. Start from `STAND` or `SIT`, override joints with `mk(...)`, and place figures with `place(...)`. Coordinates are in a 0..1 square as seen by the camera, so the person's left side is on the image right.

## Design notes

- **One idea:** *frame yourself.* Viewfinder corner marks (`src/components/Corners.tsx`) frame every pose illustration, the same way the camera frames you. The pose figure is the one bold element; everything else is flat colour and plain type.
- **Colour means something:** Solo is yellow-green, Couple is pink, Group is aqua; each place keeps its own colour. Cobalt is used only for the main action on a screen ("Try this pose"). No shadows.
- **Type:** system font (Roboto on Android), heavy weight for display, sentence case, no all-caps labels.
- **Navigation:** a thumb-reach bottom bar (Home, Camera, Make a pose, My photos) on every screen except the camera.
- **Camera:** four top controls (back, title, timer, guide settings). Ghost strength, ghost style, body-part lines and the live skeleton live in one "Guide settings" panel.
- **Pose art:** silhouettes with light limb lines so arms stay readable over the torso, and a white outline around each person in couple and group poses.
- **Shared controls:** `src/components/Controls.tsx` (switch, segmented control, row).
- **Not yet checked on a device:** the layout was written without a browser; only the pose illustrations were rendered and reviewed.

## Deploying with offline support

Build with `npm run build` (not `vite build` alone): the last step writes `dist/sw.js`. If your GitHub Actions workflow runs `npx vite build` directly, change it to `npm run build`. Serve over HTTPS (GitHub Pages does). After you deploy an update, installed users get it the next time they close and reopen the app.
